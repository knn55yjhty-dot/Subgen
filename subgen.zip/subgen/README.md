# SubGen — offline subtitle generator for Android

Generates time-synced subtitles for English, Chinese, Korean and Japanese videos, fully offline,
with optional translation to English or Simplified Chinese. Plays the video with subtitles and exports `.srt`.

## Get the APK
Open the **Releases** page of this repository on your Android phone and download the latest `SubGen-*.apk`.

## How it works
- **Speech recognition:** whisper.cpp (Whisper *small* q5_1 for "Accurate", *base* q5_1 for "Fast"), bundled in the APK.
- **Speed:** only the extracted audio is processed (the video is never decoded), and silent stretches are cut out before speech recognition, then timings are mapped back to the original video.
- **Timing:** DTW word-level timestamps, then every line's start/end is snapped to real speech onsets/offsets
  found in the audio's loudness, so lines appear when speech starts instead of lagging. Lines over silence are dropped.
  The player also has ±0.1 s / ±0.5 s timing nudges.
- **Translation:** Whisper translates to English directly. Simplified Chinese uses OPUS-MT (en→zh, int8 ONNX);
  Japanese/Korean go via English. Chinese output is converted to Simplified.
- Runs as a foreground service so long videos keep processing in the background.

Built by GitHub Actions: the workflow unzips subgen.zip and runs `scripts/ci_build.sh`.
