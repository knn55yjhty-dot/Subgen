package com.subgen.app

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.io.File

/**
 * Test build only. Lets the robot tester queue a video by file path, exactly as if it had been
 * picked with "Choose video(s)" and "Generate subtitles" (same queue, same background service).
 *
 *   adb shell am start -n com.subgen.app/.SelfTestActivity \
 *       --es path /data/user/0/com.subgen.app/files/test/en.mp4 --es src en --es target zh --ez accurate false
 */
class SelfTestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val path = intent.getStringExtra("path")
        if (path != null) {
            val f = File(path)
            Queue.load(this)
            Queue.add(this, listOf(QueueItem(
                id = "t_${System.currentTimeMillis()}",
                uri = Uri.fromFile(f).toString(),
                name = f.name,
                src = intent.getStringExtra("src") ?: "auto",
                target = intent.getStringExtra("target") ?: "orig",
                accurate = intent.getBooleanExtra("accurate", false))))
        }
    }

    // Android only lets an app start its background job while one of its screens is visible,
    // so start it once this (see-through) screen is showing, then close it.
    override fun onResume() {
        super.onResume()
        if (intent.getStringExtra("path") != null) SubtitleService.start(this)
        Handler(Looper.getMainLooper()).postDelayed({ finish() }, 1500)
    }
}
