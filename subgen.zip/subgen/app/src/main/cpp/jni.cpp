// JNI bridge between the Kotlin app and whisper.cpp.
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include "whisper.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "subgen", __VA_ARGS__)

static std::atomic<bool> g_abort{false};

struct ProgressCtx {
    JNIEnv *env;
    jobject cb;
    jmethodID mid;
};

static void put_i32(std::vector<uint8_t> &b, int32_t v) {
    uint8_t t[4];
    memcpy(t, &v, 4);
    b.insert(b.end(), t, t + 4);
}

static void put_f32(std::vector<uint8_t> &b, float v) {
    uint8_t t[4];
    memcpy(t, &v, 4);
    b.insert(b.end(), t, t + 4);
}

static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" {

// Sends whisper/ggml messages (including fatal assertion messages) to a file the app can show.
JNIEXPORT void JNICALL
Java_com_subgen_app_WhisperLib_nSetLogFile(JNIEnv *env, jclass, jstring jpath) {
    std::string path = jstr(env, jpath);
    if (freopen(path.c_str(), "w", stderr) != nullptr) setvbuf(stderr, nullptr, _IONBF, 0);
}

JNIEXPORT jlong JNICALL
Java_com_subgen_app_WhisperLib_nInit(JNIEnv *env, jclass, jstring jpath, jint kind) {
    std::string path = jstr(env, jpath);
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    cp.flash_attn = false;
    // DTW word alignment is experimental in whisper.cpp and has known crash reports, so it stays
    // off. Plain token timestamps + the app's audio-based edge snapping are used instead.
    (void) kind;
    cp.dtw_token_timestamps = false;
    whisper_context *ctx = whisper_init_from_file_with_params(path.c_str(), cp);
    if (!ctx) LOGI("failed to load model %s", path.c_str());
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL
Java_com_subgen_app_WhisperLib_nFree(JNIEnv *, jclass, jlong p) {
    if (p) whisper_free(reinterpret_cast<whisper_context *>(p));
}

JNIEXPORT void JNICALL
Java_com_subgen_app_WhisperLib_nSetAbort(JNIEnv *, jclass, jboolean v) {
    g_abort.store(v == JNI_TRUE);
}

JNIEXPORT jstring JNICALL
Java_com_subgen_app_WhisperLib_nDetectLang(JNIEnv *env, jclass, jlong p, jfloatArray jsamples, jint threads) {
    auto *ctx = reinterpret_cast<whisper_context *>(p);
    jsize n = env->GetArrayLength(jsamples);
    jfloat *s = env->GetFloatArrayElements(jsamples, nullptr);
    int rc = whisper_pcm_to_mel(ctx, s, n, threads);
    env->ReleaseFloatArrayElements(jsamples, s, JNI_ABORT);
    if (rc != 0) return env->NewStringUTF("en");
    std::vector<float> probs(whisper_lang_max_id() + 1, 0.0f);
    if (whisper_lang_auto_detect(ctx, 0, threads, probs.data()) < 0) return env->NewStringUTF("en");
    // Restrict the decision to the four supported languages.
    const char *cands[] = {"en", "zh", "ja", "ko"};
    const char *best = "en";
    float bp = -1.0f;
    for (const char *c : cands) {
        int id = whisper_lang_id(c);
        if (id >= 0 && id < (int) probs.size() && probs[id] > bp) {
            bp = probs[id];
            best = c;
        }
    }
    LOGI("detected language %s (p=%.2f)", best, bp);
    return env->NewStringUTF(best);
}

// Output format (little endian):
//   segment record: i32 kind=0, i32 t0, i32 t1               (centiseconds)
//   token record:   i32 kind=1, i32 t0, i32 t1, i32 t_dtw, f32 p, i32 len, bytes[len]
JNIEXPORT jbyteArray JNICALL
Java_com_subgen_app_WhisperLib_nTranscribe(JNIEnv *env, jclass, jlong p, jfloatArray jsamples,
                                           jstring jlang, jboolean translate, jint threads,
                                           jstring jprompt, jobject cb) {
    auto *ctx = reinterpret_cast<whisper_context *>(p);
    std::string lang = jstr(env, jlang);
    std::string prompt = jstr(env, jprompt);

    whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.n_threads = threads;
    wp.language = lang.c_str();
    wp.translate = translate == JNI_TRUE;
    wp.no_context = true;
    wp.token_timestamps = true;
    wp.print_progress = false;
    wp.print_realtime = false;
    wp.print_timestamps = false;
    wp.print_special = false;
    wp.suppress_blank = true;
    wp.initial_prompt = prompt.empty() ? nullptr : prompt.c_str();

    ProgressCtx pc{env, cb, nullptr};
    if (cb) {
        jclass k = env->GetObjectClass(cb);
        pc.mid = env->GetMethodID(k, "onProgress", "(I)V");
        wp.progress_callback = [](whisper_context *, whisper_state *, int progress, void *ud) {
            auto *c = static_cast<ProgressCtx *>(ud);
            if (c->mid) c->env->CallVoidMethod(c->cb, c->mid, progress);
        };
        wp.progress_callback_user_data = &pc;
    }
    wp.abort_callback = [](void *) -> bool { return g_abort.load(); };
    wp.abort_callback_user_data = nullptr;

    jsize n = env->GetArrayLength(jsamples);
    jfloat *s = env->GetFloatArrayElements(jsamples, nullptr);
    int rc = whisper_full(ctx, wp, s, n);
    env->ReleaseFloatArrayElements(jsamples, s, JNI_ABORT);
    if (rc != 0 || g_abort.load()) return nullptr;

    std::vector<uint8_t> out;
    const int nseg = whisper_full_n_segments(ctx);
    const whisper_token eot = whisper_token_eot(ctx);
    for (int i = 0; i < nseg; ++i) {
        put_i32(out, 0);
        put_i32(out, (int32_t) whisper_full_get_segment_t0(ctx, i));
        put_i32(out, (int32_t) whisper_full_get_segment_t1(ctx, i));
        const int nt = whisper_full_n_tokens(ctx, i);
        for (int j = 0; j < nt; ++j) {
            whisper_token id = whisper_full_get_token_id(ctx, i, j);
            if (id >= eot) continue;  // special / timestamp tokens
            whisper_token_data td = whisper_full_get_token_data(ctx, i, j);
            const char *txt = whisper_full_get_token_text(ctx, i, j);
            int32_t len = txt ? (int32_t) strlen(txt) : 0;
            put_i32(out, 1);
            put_i32(out, (int32_t) td.t0);
            put_i32(out, (int32_t) td.t1);
            put_i32(out, (int32_t) td.t_dtw);
            put_f32(out, td.p);
            put_i32(out, len);
            if (len > 0) out.insert(out.end(), (const uint8_t *) txt, (const uint8_t *) txt + len);
        }
    }
    jbyteArray arr = env->NewByteArray((jsize) out.size());
    env->SetByteArrayRegion(arr, 0, (jsize) out.size(), reinterpret_cast<const jbyte *>(out.data()));
    return arr;
}

}  // extern "C"
