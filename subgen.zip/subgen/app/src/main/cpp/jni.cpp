// JNI bridge between the Kotlin app and whisper.cpp.
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include "whisper.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "subgen", __VA_ARGS__)

static std::atomic<bool> g_abort{false};

struct ProgressCtx {
    JNIEnv *env;
    jobject cb;
    jmethodID mid;
    jmethodID segMid;
};

static void put_i32(std::vector<uint8_t> &b, int32_t v) {
    uint8_t t[4];
    memcpy(t, &v, 4);
    b.insert(b.end(), t, t + 4);
}

static void put_f32(std::vector<uint8_t> &b, float v) {
    uint8_t t[4];
    memcpy(t, &v, 4);
    b.insert(b.end(), t, t + 4);
}

static std::string jstr(JNIEnv *env, jstring s) {
    if (!s) return "";
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string r(c);
    env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" {

// Sends whisper/ggml messages (including fatal assertion messages) to a file the app can show.
JNIEXPORT void JNICALL
Java_com_subgen_app_WhisperLib_nSetLogFile(JNIEnv *env, jclass, jstring jpath) {
    std::string path = jstr(env, jpath);
    if (freopen(path.c_str(), "w", stderr) != nullptr) setvbuf(stderr, nullptr, _IONBF, 0);
}

JNIEXPORT jlong JNICALL
Java_com_subgen_app_WhisperLib_nInit(JNIEnv *env, jclass, jstring jpath, jint kind) {
    std::string path = jstr(env, jpath);
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    // Flash attention: faster on CPU. (It is incompatible with DTW, which is off.)
    cp.flash_attn = true;
    // DTW word alignment is experimental in whisper.cpp and has known crash reports, so it stays
    // off. Plain token timestamps + the app's audio-based edge snapping are used instead.
    (void) kind;
    cp.dtw_token_timestamps = false;
    whisper_context *ctx = whisper_init_from_file_with_params(path.c_str(), cp);
    if (!ctx) LOGI("failed to load model %s", path.c_str());
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL
Java_com_subgen_app_WhisperLib_nFree(JNIEnv *, jclass, jlong p) {
    if (p) whisper_free(reinterpret_cast<whisper_context *>(p));
}

JNIEXPORT void JNICALL
Java_com_subgen_app_WhisperLib_nSetAbort(JNIEnv *, jclass, jboolean v) {
    g_abort.store(v == JNI_TRUE);
}

JNIEXPORT jstring JNICALL
Java_com_subgen_app_WhisperLib_nDetectLang(JNIEnv *env, jclass, jlong p, jfloatArray jsamples, jint threads) {
    auto *ctx = reinterpret_cast<whisper_context *>(p);
    jsize n = env->GetArrayLength(jsamples);
    jfloat *s = env->GetFloatArrayElements(jsamples, nullptr);
    int rc = whisper_pcm_to_mel(ctx, s, n, threads);
    env->ReleaseFloatArrayElements(jsamples, s, JNI_ABORT);
    if (rc != 0) return env->NewStringUTF("en");
    std::vector<float> probs(whisper_lang_max_id() + 1, 0.0f);
    if (whisper_lang_auto_detect(ctx, 0, threads, probs.data()) < 0) return env->NewStringUTF("en");
    // Restrict the decision to the four supported languages.
    const char *cands[] = {"en", "zh", "ja", "ko"};
    const char *best = "en";
    float bp = -1.0f;
    for (const char *c : cands) {
        int id = whisper_lang_id(c);
        if (id >= 0 && id < (int) probs.size() && probs[id] > bp) {
            bp = probs[id];
            best = c;
        }
    }
    LOGI("detected language %s (p=%.2f)", best, bp);
    return env->NewStringUTF(best);
}

// Speed test: times the speech model's encoder (the slow part) with each thread count.
// Returns milliseconds per thread count, or -1 on error.
JNIEXPORT jlongArray JNICALL
Java_com_subgen_app_WhisperLib_nBenchEncode(JNIEnv *env, jclass, jlong p, jfloatArray jsamples, jintArray jthreads) {
    auto *ctx = reinterpret_cast<whisper_context *>(p);
    jsize nt = env->GetArrayLength(jthreads);
    std::vector<jint> th(nt);
    env->GetIntArrayRegion(jthreads, 0, nt, th.data());
    std::vector<jlong> res(nt, -1);
    jsize n = env->GetArrayLength(jsamples);
    jfloat *s = env->GetFloatArrayElements(jsamples, nullptr);
    int rc = whisper_pcm_to_mel(ctx, s, n, 4);
    env->ReleaseFloatArrayElements(jsamples, s, JNI_ABORT);
    if (rc == 0) {
        whisper_encode(ctx, 0, 4);  // warm-up (first run includes one-time setup)
        for (jsize i = 0; i < nt; ++i) {
            auto t0 = std::chrono::steady_clock::now();
            if (whisper_encode(ctx, 0, th[i]) != 0) continue;
            res[i] = (jlong) std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now() - t0).count();
        }
    }
    jlongArray out = env->NewLongArray(nt);
    env->SetLongArrayRegion(out, 0, nt, res.data());
    return out;
}

// Output format (little endian):
//   segment record: i32 kind=0, i32 t0, i32 t1               (centiseconds)
//   token record:   i32 kind=1, i32 t0, i32 t1, i32 t_dtw, f32 p, i32 len, bytes[len]
JNIEXPORT jbyteArray JNICALL
Java_com_subgen_app_WhisperLib_nTranscribe(JNIEnv *env, jclass, jlong p, jfloatArray jsamples,
                                           jstring jlang, jboolean translate, jint threads,
                                           jstring jprompt, jobject cb, jint careful) {
    auto *ctx = reinterpret_cast<whisper_context *>(p);
    std::string lang = jstr(env, jlang);
    std::string prompt = jstr(env, jprompt);

    // careful = 1: re-decoding a short stretch where the model got stuck repeating itself.
    // Beam search weighs 5 candidate wordings instead of taking the first, and a stricter loop
    // check (entropy 2.8 instead of 2.4) retries at higher temperature sooner.
    whisper_full_params wp = whisper_full_default_params(careful ? WHISPER_SAMPLING_BEAM_SEARCH : WHISPER_SAMPLING_GREEDY);
    if (careful) {
        wp.beam_search.beam_size = 5;
        wp.beam_search.patience = -1.0f;
    }
    wp.n_threads = threads;
    wp.language = lang.c_str();
    wp.translate = translate == JNI_TRUE;
    wp.no_context = true;
    // Don't feed the text of the previous 30 s window back in as a hint for the next one. That
    // hint is what makes the model "stick": after a pause or slow speech it repeats the last line
    // ("I know, right?" x4). Each window is decoded on its own sound only (Whisper's
    // condition_on_previous_text=False). Simplified Chinese is ensured afterwards by conversion.
    wp.n_max_text_ctx = 0;
    wp.token_timestamps = true;
    wp.print_progress = false;
    wp.print_realtime = false;
    wp.print_timestamps = false;
    wp.print_special = false;
    wp.suppress_blank = true;
    // When a window decodes badly (e.g. stuck repeating itself), whisper retries at higher
    // temperatures. Keep the standard 0.2 steps (up to 5 retries): fewer retries made repetition
    // loops more likely, especially with the Fast model.
    wp.temperature_inc = 0.2f;
    wp.entropy_thold = careful ? 2.8f : 2.4f;    // output this repetitive triggers a retry
    wp.logprob_thold = -1.0f;
    wp.initial_prompt = prompt.empty() ? nullptr : prompt.c_str();

    ProgressCtx pc{env, cb, nullptr, nullptr};
    if (cb) {
        jclass k = env->GetObjectClass(cb);
        pc.mid = env->GetMethodID(k, "onProgress", "(I)V");
        pc.segMid = env->GetMethodID(k, "onSegment", "(JJ[B)V");
        // Live preview: hand each newly finished segment to the app (as raw bytes; decoded in Kotlin).
        wp.new_segment_callback = [](whisper_context *c, whisper_state *, int n_new, void *ud) {
            auto *pcx = static_cast<ProgressCtx *>(ud);
            if (!pcx->segMid) return;
            const int n = whisper_full_n_segments(c);
            for (int i = n - n_new; i < n; ++i) {
                if (i < 0) continue;
                const char *txt = whisper_full_get_segment_text(c, i);
                jsize len = txt ? (jsize) strlen(txt) : 0;
                jbyteArray arr = pcx->env->NewByteArray(len);
                if (len > 0) pcx->env->SetByteArrayRegion(arr, 0, len, reinterpret_cast<const jbyte *>(txt));
                pcx->env->CallVoidMethod(pcx->cb, pcx->segMid,
                    (jlong) whisper_full_get_segment_t0(c, i), (jlong) whisper_full_get_segment_t1(c, i), arr);
                pcx->env->DeleteLocalRef(arr);
                if (pcx->env->ExceptionCheck()) pcx->env->ExceptionClear();
            }
        };
        wp.new_segment_callback_user_data = &pc;
        wp.progress_callback = [](whisper_context *, whisper_state *, int progress, void *ud) {
            auto *c = static_cast<ProgressCtx *>(ud);
            if (c->mid) c->env->CallVoidMethod(c->cb, c->mid, progress);
            if (c->env->ExceptionCheck()) c->env->ExceptionClear();
        };
        wp.progress_callback_user_data = &pc;
    }
    wp.abort_callback = [](void *) -> bool { return g_abort.load(); };
    wp.abort_callback_user_data = nullptr;

    jsize n = env->GetArrayLength(jsamples);
    jfloat *s = env->GetFloatArrayElements(jsamples, nullptr);
    int rc = whisper_full(ctx, wp, s, n);
    env->ReleaseFloatArrayElements(jsamples, s, JNI_ABORT);
    if (rc != 0 || g_abort.load()) return nullptr;

    std::vector<uint8_t> out;
    const int nseg = whisper_full_n_segments(ctx);
    const whisper_token eot = whisper_token_eot(ctx);
    for (int i = 0; i < nseg; ++i) {
        put_i32(out, 0);
        put_i32(out, (int32_t) whisper_full_get_segment_t0(ctx, i));
        put_i32(out, (int32_t) whisper_full_get_segment_t1(ctx, i));
        const int nt = whisper_full_n_tokens(ctx, i);
        for (int j = 0; j < nt; ++j) {
            whisper_token id = whisper_full_get_token_id(ctx, i, j);
            if (id >= eot) continue;  // special / timestamp tokens
            whisper_token_data td = whisper_full_get_token_data(ctx, i, j);
            const char *txt = whisper_full_get_token_text(ctx, i, j);
            int32_t len = txt ? (int32_t) strlen(txt) : 0;
            put_i32(out, 1);
            put_i32(out, (int32_t) td.t0);
            put_i32(out, (int32_t) td.t1);
            put_i32(out, (int32_t) td.t_dtw);
            put_f32(out, td.p);
            put_i32(out, len);
            if (len > 0) out.insert(out.end(), (const uint8_t *) txt, (const uint8_t *) txt + len);
        }
    }
    jbyteArray arr = env->NewByteArray((jsize) out.size());
    env->SetByteArrayRegion(arr, 0, (jsize) out.size(), reinterpret_cast<const jbyte *>(out.data()));
    return arr;
}

}  // extern "C"
