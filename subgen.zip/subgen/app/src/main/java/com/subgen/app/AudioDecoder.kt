package com.subgen.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Streaming low-pass + linear-interpolation resampler to 16 kHz mono. */
class Resampler(inRate: Int, outRate: Int = 16000) {
    private val step = inRate.toDouble() / outRate
    private val taps: FloatArray
    private val hist: FloatArray
    private var hpos = 0
    private var n = 0L
    private var prev = 0f
    private var cur = 0f
    private var nextOut = 0.0

    init {
        if (inRate > outRate) {
            val len = 47
            val fc = 0.5 * outRate / inRate * 0.92
            val m = (len - 1) / 2.0
            val t = FloatArray(len)
            var sum = 0.0
            for (i in 0 until len) {
                val x = i - m
                val sinc = if (x == 0.0) 2 * fc else sin(2 * PI * fc * x) / (PI * x)
                val w = 0.54 - 0.46 * cos(2 * PI * i / (len - 1))
                t[i] = (sinc * w).toFloat()
                sum += t[i]
            }
            for (i in 0 until len) t[i] = (t[i] / sum).toFloat()
            taps = t
        } else {
            taps = floatArrayOf(1f)
        }
        hist = FloatArray(taps.size)
    }

    fun process(x: Float, emit: (Float) -> Unit) {
        val l = taps.size
        hist[hpos] = x
        var y = 0f
        var idx = hpos
        for (k in 0 until l) {
            y += taps[k] * hist[idx]
            idx = if (idx == 0) l - 1 else idx - 1
        }
        hpos = (hpos + 1) % l
        prev = cur
        cur = y
        n++
        // cur is filtered sample index n-1, prev is n-2
        while (nextOut <= n - 1) {
            val frac = (nextOut - (n - 2)).toFloat().coerceIn(0f, 1f)
            emit(prev + (cur - prev) * frac)
            nextOut += step
        }
    }
}

/** Decodes the audio track of a video into 16 kHz mono signed 16-bit PCM. */
object AudioDecoder {

    private class PcmWriter(file: File) {
        private val os = FileOutputStream(file)
        private val buf = ByteArray(1 shl 16)
        private var pos = 0
        var count = 0L

        fun write(v: Float) {
            val s = (v.coerceIn(-1f, 1f) * 32767f).toInt()
            buf[pos++] = (s and 0xFF).toByte()
            buf[pos++] = ((s shr 8) and 0xFF).toByte()
            count++
            if (pos >= buf.size) flush()
        }

        fun flush() {
            os.write(buf, 0, pos)
            pos = 0
        }

        fun close() {
            flush()
            os.close()
        }
    }

    fun decode(
        ctx: Context, uri: Uri, out: File,
        cancelled: () -> Boolean, progress: (Float) -> Unit
    ): Long {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var track = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val m = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (m.startsWith("audio/")) {
                track = i; fmt = f; break
            }
        }
        if (track < 0 || fmt == null) {
            ex.release()
            throw IllegalStateException("This video has no audio track.")
        }
        ex.selectTrack(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var sampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var pcmFloat = false
        var resampler: Resampler? = null
        val writer = PcmWriter(out)
        val emit: (Float) -> Unit = { writer.write(it) }
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var firstPts = -1L
        try {
            while (!outputDone) {
                if (cancelled()) throw CancelledException()
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    resampler = null
                } else if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        val r = resampler ?: Resampler(sampleRate).also { resampler = it }
                        if (firstPts < 0) {
                            firstPts = info.presentationTimeUs
                            // Audio that starts after the video: pad with silence so timings stay in sync.
                            if (firstPts in 1..10_000_000) {
                                val pad = firstPts * 16000 / 1_000_000
                                for (k in 0 until pad) writer.write(0f)
                            }
                        }
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.nativeOrder())
                        val ch = channels.coerceAtLeast(1)
                        if (pcmFloat) {
                            val fb = ob.asFloatBuffer()
                            val frames = fb.remaining() / ch
                            for (i in 0 until frames) {
                                var s = 0f
                                for (c in 0 until ch) s += fb.get()
                                r.process(s / ch, emit)
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            val frames = sb.remaining() / ch
                            for (i in 0 until frames) {
                                var s = 0f
                                for (c in 0 until ch) s += sb.get() / 32768f
                                r.process(s / ch, emit)
                            }
                        }
                        if (durUs > 0) progress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
        } finally {
            writer.close()
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            ex.release()
        }
        return writer.count
    }
}

class CancelledException : Exception("Cancelled")
