package com.subgen.app

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Low-pass + linear-interpolation resampler to 16 kHz mono, working on blocks of samples.
 * The filter is only evaluated where an output sample is needed (3x less work for 48 kHz audio).
 */
class Resampler(inRate: Int, outRate: Int = 16000) {
    private val step = inRate.toDouble() / outRate
    private val taps: FloatArray
    private val l: Int
    private var hist = FloatArray(0)
    private var consumed = 0L      // global index of the next input sample
    private var nextOut = 0.0      // global input position of the next output sample
    private val outBuf = FloatArray(8192)

    init {
        if (inRate > outRate) {
            val len = 47
            val fc = 0.5 * outRate / inRate * 0.92
            val m = (len - 1) / 2.0
            val t = FloatArray(len)
            var sum = 0.0
            for (i in 0 until len) {
                val x = i - m
                val sinc = if (x == 0.0) 2 * fc else sin(2 * PI * fc * x) / (PI * x)
                val w = 0.54 - 0.46 * cos(2 * PI * i / (len - 1))
                t[i] = (sinc * w).toFloat()
                sum += t[i]
            }
            for (i in 0 until len) t[i] = (t[i] / sum).toFloat()
            taps = t
        } else {
            taps = floatArrayOf(1f)
        }
        l = taps.size
    }

    private fun fir(w: FloatArray, idx: Int): Float {
        var s = 0f
        var j = 0
        while (j < l) {
            val i = idx - j
            if (i < 0) break
            s += taps[j] * w[i]
            j++
        }
        return s
    }

    /** Feeds n input samples; resampled output is passed to [sink] in blocks. */
    fun process(input: FloatArray, n: Int, sink: (FloatArray, Int) -> Unit) {
        if (n <= 0) return
        val h = hist.size
        val w = FloatArray(h + n)
        hist.copyInto(w)
        input.copyInto(w, h, 0, n)
        val base = consumed - h
        val lastGlobal = consumed + n - 1
        var o = 0
        while (true) {
            val k = Math.floor(nextOut).toLong()
            val frac = (nextOut - k).toFloat()
            if (k > lastGlobal || (frac > 1e-6f && k + 1 > lastGlobal)) break
            val y0 = fir(w, (k - base).toInt())
            val y1 = if (frac > 1e-6f) fir(w, (k + 1 - base).toInt()) else y0
            outBuf[o++] = y0 + (y1 - y0) * frac
            if (o == outBuf.size) { sink(outBuf, o); o = 0 }
            nextOut += step
        }
        if (o > 0) sink(outBuf, o)
        consumed += n
        val keep = minOf(w.size, l + 1)
        hist = w.copyOfRange(w.size - keep, w.size)
    }

    /** Single-sample convenience (used by tests). */
    fun process(x: Float, emit: (Float) -> Unit) {
        process(floatArrayOf(x), 1) { a, n -> for (i in 0 until n) emit(a[i]) }
    }
}

/** Decodes the audio track of a video into 16 kHz mono signed 16-bit PCM. */
object AudioDecoder {

    private class PcmWriter(file: File) {
        private val os = FileOutputStream(file)
        private val buf = ByteArray(1 shl 16)
        private var pos = 0
        var count = 0L

        fun writeBlock(a: FloatArray, n: Int) {
            for (i in 0 until n) write(a[i])
        }

        fun write(v: Float) {
            val s = (v.coerceIn(-1f, 1f) * 32767f).toInt()
            buf[pos++] = (s and 0xFF).toByte()
            buf[pos++] = ((s shr 8) and 0xFF).toByte()
            count++
            if (pos >= buf.size) flush()
        }

        fun flush() {
            os.write(buf, 0, pos)
            pos = 0
        }

        fun close() {
            flush()
            os.close()
        }
    }

    fun fmtTime(us: Long): String {
        val s = us / 1_000_000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }

    /** progress: (fraction 0..1 or -1 if unknown, position µs, total length µs or 0) */
    fun decode(
        ctx: Context, uri: Uri, out: File,
        cancelled: () -> Boolean, log: (String) -> Unit, progress: (Float, Long, Long) -> Unit
    ): Long {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
        } catch (e: SecurityException) {
            ex.release()
            throw IllegalStateException("The app is no longer allowed to open this video (this happens with some file " +
                "pickers after a restart). Remove it from the queue and choose it again.")
        } catch (e: java.io.IOException) {
            ex.release()
            throw IllegalStateException("Couldn't open this video. It may have been moved or deleted, or its format isn't supported. ($e)")
        }
        var track = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val m = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (m.startsWith("audio/")) {
                track = i; fmt = f; break
            }
        }
        if (track < 0 || fmt == null) {
            ex.release()
            throw IllegalStateException("This video has no audio track.")
        }
        ex.selectTrack(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        var durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        if (durUs <= 0) {
            // Some files don't store the length in the audio track; ask the container instead.
            try {
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(ctx, uri)
                durUs = (mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000
                mmr.release()
            } catch (_: Exception) {}
        }
        log("audio track: $mime, ${fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)} Hz, " +
            "${fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)} ch, length ${if (durUs > 0) fmtTime(durUs) else "unknown"}")
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var sampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var pcmFloat = false
        var resampler: Resampler? = null
        val writer = PcmWriter(out)
        val sink: (FloatArray, Int) -> Unit = { a, n -> writer.writeBlock(a, n) }
        var mono = FloatArray(16384)
        var lastActivity = System.currentTimeMillis()
        var lastReport = 0L
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var firstPts = -1L
        try {
            while (!outputDone) {
                if (cancelled()) throw CancelledException()
                val idle = System.currentTimeMillis() - lastActivity
                // Some decoders never send the final end-of-stream signal: if all input is in and
                // nothing more comes out for 5 s, treat the audio as finished.
                if (inputDone && idle > 5_000) {
                    log("decoder sent no end-of-stream signal; treating audio as complete")
                    break
                }
                if (idle > 30_000)
                    throw IllegalStateException("Reading the audio stalled (no progress for 30 s). " +
                        "If the video is stored in the cloud, download it to the phone first.")
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                            lastActivity = System.currentTimeMillis()
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                            lastActivity = System.currentTimeMillis()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    resampler = null
                } else if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        val r = resampler ?: Resampler(sampleRate).also { resampler = it }
                        if (firstPts < 0) {
                            firstPts = info.presentationTimeUs
                            // Audio that starts after the video: pad with silence so timings stay in sync.
                            if (firstPts in 1..10_000_000) {
                                val pad = firstPts * 16000 / 1_000_000
                                for (k in 0 until pad) writer.write(0f)
                            }
                        }
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.nativeOrder())
                        val ch = channels.coerceAtLeast(1)
                        val inv = 1f / ch
                        val frames: Int
                        if (pcmFloat) {
                            val fb = ob.asFloatBuffer()
                            frames = fb.remaining() / ch
                            if (mono.size < frames) mono = FloatArray(frames)
                            for (i in 0 until frames) {
                                var s = 0f
                                for (c in 0 until ch) s += fb.get()
                                mono[i] = s * inv
                            }
                        } else {
                            val sb = ob.asShortBuffer()
                            frames = sb.remaining() / ch
                            if (mono.size < frames) mono = FloatArray(frames)
                            for (i in 0 until frames) {
                                var s = 0
                                for (c in 0 until ch) s += sb.get()
                                mono[i] = s * inv / 32768f
                            }
                        }
                        r.process(mono, frames, sink)
                        lastActivity = System.currentTimeMillis()
                        if (lastActivity - lastReport > 500) {
                            lastReport = lastActivity
                            val pos = info.presentationTimeUs
                            progress(if (durUs > 0) (pos.toFloat() / durUs).coerceIn(0f, 1f) else -1f, pos, durUs)
                        }
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
        } finally {
            // release the decoder first: writer.close() can throw (e.g. storage full) and must not leak it
            try {
                try { codec.stop() } catch (_: Exception) {}
                try { codec.release() } catch (_: Exception) {}
                try { ex.release() } catch (_: Exception) {}
            } finally {
                writer.close()
            }
        }
        return writer.count
    }
}

class CancelledException : Exception("Cancelled")
