package com.subgen.app

import java.io.Closeable
import java.io.File
import java.util.concurrent.LinkedBlockingQueue
import kotlin.concurrent.thread

/**
 * Translates finished sentences to Chinese on a separate thread while the speech model keeps
 * transcribing the next part. If translation fails at any point, every line falls back to English.
 */
class BgTranslator(
    private val mtDir: File,
    private val threads: Int,
    private val cancelled: () -> Boolean,
    private val log: (String) -> Unit,
    private val split: (Cue) -> List<Cue> = { CueBuilder.splitCue(it) },
    private val onTranslated: (Cue) -> Unit = {}
) : Closeable {
    private val queue = LinkedBlockingQueue<List<Cue>>()
    private val end = emptyList<Cue>()
    private val english = ArrayList<Cue>()          // untouched English copies, in order
    private val translated = ArrayList<Cue>()       // translated + split lines
    private val lock = Any()
    @Volatile var error: Throwable? = null; private set
    @Volatile var done = 0; private set
    @Volatile var submitted = 0; private set
    @Volatile var busySec = 0.0; private set        // time spent translating so far
    @Volatile var fastErr: String? = null; private set
    @Volatile private var stopped = false

    private val worker = thread(name = "subgen-mt") { loop() }

    fun submit(batch: List<Cue>) {
        if (batch.isEmpty()) return
        synchronized(lock) { for (c in batch) english.add(c.copy()) }
        submitted += batch.size
        queue.put(batch.map { it.copy() })
    }

    /** Seconds per sentence measured so far, or null if not enough data yet. */
    fun secPerSentence(): Double? = if (done >= 3) busySec / done else null

    private fun loop() {
        var tr: MarianTranslator? = null
        try {
            tr = MarianTranslator(mtDir, threads)
            while (true) {
                val batch = queue.take()
                if (batch === end) break
                for (c in batch) {
                    if (cancelled() || stopped) return
                    val t0 = System.nanoTime()
                    if (!CueBuilder.isAnnotation(c.text)) c.text = tr.translate(c.text)
                    busySec += (System.nanoTime() - t0) / 1e9
                    // add the line and count it together, so a preview never shows it twice
                    synchronized(lock) { translated += split(c); done++ }
                    try { onTranslated(c) } catch (_: Throwable) {}
                }
            }
            fastErr = tr.fastPathError
        } catch (e: Throwable) {
            if (!cancelled()) {
                error = e
                log("CHINESE TRANSLATION FAILED, keeping English: $e")
            }
            // drain so finish() doesn't wait forever
            while (true) { val b = queue.poll() ?: break; if (b === end) break; synchronized(lock) { done += b.size } }
        } finally {
            try { tr?.close() } catch (_: Throwable) {}
        }
    }

    /** Waits for the remaining sentences. Returns translated lines, or English lines if it failed. */
    fun finish(onWait: (done: Int, total: Int) -> Unit): List<Cue> {
        queue.put(end)
        while (worker.isAlive) {
            onWait(done, submitted)
            worker.join(500)
        }
        synchronized(lock) {
            if (error != null || done < submitted) return english.flatMap { split(it.copy()) }
            return ArrayList(translated)
        }
    }

    val failed get() = error != null

    /**
     * For "Watch so far": lines translated so far, followed by the not-yet-translated source lines,
     * so timing can be checked even before the translator has caught up.
     */
    fun snapshot(): List<Cue> = synchronized(lock) {
        val n = done.coerceIn(0, english.size)
        translated.map { it.copy() } + english.subList(n, english.size).flatMap { split(it.copy()) }
    }

    /** Stops early (used when the job fails); finish() is the normal way to end. */
    override fun close() {
        stopped = true
        queue.put(end)
    }
}
