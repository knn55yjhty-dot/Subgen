package com.subgen.app

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

data class Cue(var start: Double, var end: Double, var text: String)

class Tok(val t0: Int, val t1: Int, val tdtw: Int, val p: Float, val bytes: ByteArray)
class Seg(val t0: Int, val t1: Int) { val toks = mutableListOf<Tok>() }
class Piece(var text: String, var start: Double, var end: Double)

object CueBuilder {
    private const val MAX_WIDTH = 42 // CJK chars count double, so ~21 CJK chars per line
    private const val MAX_DUR = 6.0

    fun parse(buf: ByteArray): List<Seg> {
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        val segs = mutableListOf<Seg>()
        while (bb.remaining() >= 12) {
            when (bb.int) {
                0 -> segs.add(Seg(bb.int, bb.int))
                1 -> {
                    val t0 = bb.int; val t1 = bb.int; val td = bb.int; val p = bb.float
                    val len = bb.int
                    val b = ByteArray(len); bb.get(b)
                    segs.lastOrNull()?.toks?.add(Tok(t0, t1, td, p, b))
                }
                else -> return segs
            }
        }
        return segs
    }

    private fun completeUtf8(b: ByteArray): Boolean {
        var i = b.size - 1
        var cont = 0
        while (i >= 0 && (b[i].toInt() and 0xC0) == 0x80) {
            cont++; i--
            if (cont > 3) return true
        }
        if (i < 0) return false
        val lead = b[i].toInt() and 0xFF
        val need = when {
            lead < 0x80 -> 0
            lead >= 0xF0 -> 3
            lead >= 0xE0 -> 2
            lead >= 0xC0 -> 1
            else -> 0
        }
        return cont >= need
    }

    /** Merges byte-level tokens into whole characters with timings. */
    private fun pieces(seg: Seg): List<Piece> {
        val out = mutableListOf<Piece>()
        val buf = ByteArrayOutputStream()
        var st = 0.0
        var en = 0.0
        for (t in seg.toks) {
            if (buf.size() == 0) {
                val d = if (t.tdtw >= 0 && t.tdtw >= t.t0 - 50 && t.tdtw <= t.t1 + 50) t.tdtw else t.t0
                st = d / 100.0
            }
            buf.write(t.bytes)
            en = t.t1 / 100.0
            val b = buf.toByteArray()
            if (completeUtf8(b)) {
                val s = String(b, Charsets.UTF_8)
                if (s.isNotEmpty()) out.add(Piece(s, st, max(en, st)))
                buf.reset()
            }
        }
        if (buf.size() > 0) out.add(Piece(String(buf.toByteArray(), Charsets.UTF_8), st, max(en, st)))
        return out
    }

    fun isCjk(c: Char): Boolean {
        val sc = Character.UnicodeScript.of(c.code)
        return sc == Character.UnicodeScript.HAN || sc == Character.UnicodeScript.HIRAGANA ||
            sc == Character.UnicodeScript.KATAKANA
    }

    private fun isPunct(c: Char) = !Character.isLetterOrDigit(c) && !Character.isWhitespace(c)

    private fun isSentenceEnd(s: String): Boolean {
        val t = s.trimEnd()
        if (t.isEmpty()) return false
        return t.last() in ".?!。？！…"
    }

    fun displayLen(s: String): Int = s.sumOf { c -> (if (isCjk(c) || Character.UnicodeScript.of(c.code) == Character.UnicodeScript.HANGUL) 2 else 1).toInt() }

    private fun words(ps: List<Piece>): List<Piece> {
        val out = mutableListOf<Piece>()
        for (p in ps) {
            val txt = p.text
            if (txt.isEmpty()) continue
            val cur = out.lastOrNull()
            val first = txt.trimStart().firstOrNull() ?: continue
            val joinAsPunct = cur != null && txt.isNotBlank() && txt.trim().all { isPunct(it) } && !txt.startsWith(" ")
            val startNew = cur == null || (!joinAsPunct && (txt.startsWith(" ") || isCjk(first) ||
                (cur.text.isNotEmpty() && isCjk(cur.text.last()) && !isPunct(first))))
            if (startNew) out.add(Piece(txt, p.start, p.end))
            else {
                cur!!.text += txt
                cur.end = max(cur.end, p.end)
            }
        }
        // A word ends no later than the next word starts.
        for (i in 0 until out.size - 1) {
            val nx = out[i + 1].start
            if (nx > out[i].start) out[i].end = min(out[i].end, nx)
        }
        return out
    }

    /** Builds short subtitle lines from word timings (transcription mode). */
    fun wordCues(segs: List<Seg>, offset: Double): List<Cue> {
        val cues = mutableListOf<Cue>()
        for (seg in segs) {
            val ws = words(pieces(seg))
            if (ws.isEmpty()) continue
            var text = StringBuilder()
            var start = 0.0
            var end = 0.0
            fun flush() {
                val t = text.toString().trim()
                if (t.isNotEmpty()) cues.add(Cue(start + offset, end + offset, t))
                text = StringBuilder()
            }
            for (w in ws) {
                if (text.isNotEmpty()) {
                    val cur = text.toString()
                    val gap = w.start - end
                    val tooWide = displayLen(cur + w.text) > MAX_WIDTH
                    val tooLong = w.end - start > MAX_DUR
                    val sentence = isSentenceEnd(cur) && displayLen(cur) >= 12
                    if (gap > 0.7 || tooWide || tooLong || sentence) flush()
                }
                if (text.isEmpty()) start = w.start
                text.append(w.text)
                end = max(end, w.end)
            }
            flush()
        }
        return cues
    }

    /** Segment-level lines (translation mode: word timings don't map onto translated words). */
    fun segmentCues(segs: List<Seg>, offset: Double, split: Boolean = true): List<Cue> {
        val cues = mutableListOf<Cue>()
        for (seg in segs) {
            val text = clean(pieces(seg).joinToString("") { it.text })
            if (text.isEmpty()) continue
            val s = seg.t0 / 100.0 + offset
            val e = max(seg.t1 / 100.0 + offset, s + 0.3)
            val c = Cue(s, e, text)
            if (split) cues += splitCue(c) else cues += c
        }
        return cues
    }

    /** Splits a long line into readable pieces, sharing its time in proportion to text length. */
    fun splitCue(c: Cue): List<Cue> {
        val parts = splitText(c.text, c.end - c.start)
        if (parts.size <= 1) return listOf(c)
        val total = parts.sumOf { displayLen(it) }.coerceAtLeast(1)
        val out = mutableListOf<Cue>()
        var t = c.start
        for (p in parts) {
            val d = (c.end - c.start) * displayLen(p) / total
            out.add(Cue(t, t + d, p))
            t += d
        }
        out.last().end = c.end
        return out
    }

    private fun splitText(text: String, dur: Double): List<String> {
        val width = displayLen(text)
        val n = max(
            Math.ceil(width / (MAX_WIDTH * 1.0)).toInt(),
            Math.ceil(dur / 7.0).toInt()
        ).coerceAtLeast(1)
        if (n == 1) return listOf(text)
        val target = width.toDouble() / n
        val spaced = text.count { it == ' ' } >= n - 1 && text.none { isCjk(it) }
        // Break opportunities: after spaces for spaced languages, else after any character,
        // preferring punctuation.
        val out = mutableListOf<String>()
        var start = 0
        var acc = 0
        var lastGood = -1
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            acc += if (isCjk(ch) || Character.UnicodeScript.of(ch.code) == Character.UnicodeScript.HANGUL) 2 else 1
            val canBreak = if (spaced) ch == ' ' else true
            if (canBreak && (ch in "，。！？、；：,.!?;: " || !spaced)) {
                if (ch in "，。！？、；：,.!?;: ") lastGood = i
                if (acc >= target && out.size < n - 1) {
                    val cut = if (lastGood > start && displayLen(text.substring(start, lastGood + 1)) >= target * 0.6) lastGood else i
                    out.add(text.substring(start, cut + 1).trim())
                    start = cut + 1
                    acc = displayLen(text.substring(start, i + 1))
                    lastGood = -1
                }
            }
            i++
        }
        if (start < text.length) out.add(text.substring(start).trim())
        return out.filter { it.isNotEmpty() }
    }

    fun clean(s: String): String = s.replace(Regex("\\s+"), " ").trim()

    fun isAnnotation(s: String): Boolean {
        val t = s.trim()
        if (t.all { !Character.isLetterOrDigit(it) }) return true
        return Regex("^[\\[(（【♪*].*[\\])）】♪*]$").matches(t)
    }
}
