package com.subgen.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Crash recorder. Each job writes its progress to a small file; if the app dies, the next launch
 * finds a run that never finished and shows what it was doing, plus any error text.
 */
object Diag {
    private fun runFile(ctx: Context) = File(ctx.filesDir, "last_run.txt")
    fun nativeLog(ctx: Context) = File(ctx.filesDir, "native_log.txt")
    private fun crashFile(ctx: Context) = File(ctx.filesDir, "crash.txt")
    private fun historyFile(ctx: Context) = File(ctx.filesDir, "history_log.txt")
    fun currentRunLog(ctx: Context): String = runFile(ctx).let { if (it.exists()) it.readText() else "" }
    @Volatile private var lastStage = ""
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun begin(ctx: Context, info: String) {
        lastStage = ""
        crashFile(ctx).delete()
        runFile(ctx).writeText("Started ${fmt.format(Date())}: $info\n")
        try { WhisperLib.nSetLogFile(nativeLog(ctx).absolutePath) } catch (_: Throwable) {}
    }

    @Synchronized
    fun stage(ctx: Context, stage: String) {
        if (stage == lastStage) return
        lastStage = stage
        try { runFile(ctx).appendText("${fmt.format(Date())} $stage\n") } catch (_: Exception) {}
    }

    /** Extra detail lines (audio length, language, speed, line counts...). */
    @Synchronized
    fun info(ctx: Context, msg: String) {
        try { runFile(ctx).appendText("${fmt.format(Date())}   · $msg\n") } catch (_: Exception) {}
    }

    @Synchronized
    fun end(ctx: Context, outcome: String) {
        try {
            runFile(ctx).appendText("${fmt.format(Date())} ENDED: $outcome\n")
            // keep the last runs (about 30 KB) for later reports
            val h = historyFile(ctx)
            val old = if (h.exists()) h.readText() else ""
            h.writeText((old + "\n===== run =====\n" + runFile(ctx).readText()).takeLast(30000))
        } catch (_: Exception) {}
    }

    fun installCrashHandler(ctx: Context) {
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        if (prev is Handler) return
        Thread.setDefaultUncaughtExceptionHandler(Handler(app, prev))
    }

    private class Handler(val ctx: Context, val prev: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                crashFile(ctx).writeText("Thread ${t.name}:\n" + sw.toString().take(4000))
            } catch (_: Exception) {}
            prev?.uncaughtException(t, e)
        }
    }

    /** Returns a report if the last run didn't finish normally or the app crashed, else null. */
    fun pendingReport(ctx: Context): String? {
        val run = runFile(ctx)
        val crash = crashFile(ctx)
        val unfinished = run.exists() && !run.readText().contains("ENDED:")
        if (!unfinished && !crash.exists()) return null
        val sb = StringBuilder()
        sb.append("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}, Android ${android.os.Build.VERSION.SDK_INT}\n")
        if (run.exists()) sb.append(run.readText().takeLast(1500)).append('\n')
        if (crash.exists()) sb.append("--- error ---\n").append(crash.readText()).append('\n')
        val nl = nativeLog(ctx)
        if (nl.exists()) sb.append("--- engine log ---\n").append(nl.readText().takeLast(1500))
        return sb.toString()
    }

    /** Full report for feedback: user text + app/device info + logs (+ optional video/player details). */
    fun fullReport(ctx: Context, feedback: String, project: Project?, extra: String?): String {
        val sb = StringBuilder()
        sb.append("=== SubGen feedback ===\n")
        if (feedback.isNotBlank()) sb.append("User says: ").append(feedback.trim()).append("\n")
        sb.append("App: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\n")
        sb.append("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}, Android ${android.os.Build.VERSION.SDK_INT}, ")
        sb.append("${Runtime.getRuntime().availableProcessors()} cores, models ready=${Models.ready(ctx)}\n")
        if (project != null) {
            sb.append("\n--- video ---\n")
            sb.append("${project.name} | spoken=${project.srcLang} subs=${project.outLang} offset=${project.offsetMs}ms\n")
            val cues = try { Srt.parse(project.srtFile.readText()) } catch (_: Exception) { emptyList() }
            sb.append("${cues.size} lines")
            if (cues.isNotEmpty()) sb.append(", ${"%.1f".format(cues.first().start)}s – ${"%.1f".format(cues.last().end)}s")
            sb.append("\n")
            val log = File(project.dir, "run_log.txt")
            if (log.exists()) sb.append("--- processing log ---\n").append(log.readText().takeLast(4000)).append("\n")
        }
        if (extra != null) sb.append("\n").append(extra).append("\n")
        val run = runFile(ctx)
        if (project == null && run.exists() && !run.readText().contains("ENDED:")) sb.append("\n--- current/unfinished run ---\n").append(run.readText().takeLast(4000)).append("\n")
        val crash = crashFile(ctx)
        if (crash.exists()) sb.append("\n--- error ---\n").append(crash.readText()).append("\n")
        val nl = nativeLog(ctx)
        if (nl.exists() && nl.length() > 0) sb.append("\n--- engine log ---\n").append(nl.readText().takeLast(2500)).append("\n")
        if (project == null) {
            val h = historyFile(ctx)
            if (h.exists()) sb.append("\n--- earlier runs ---\n").append(h.readText().takeLast(6000)).append("\n")
        }
        return sb.toString()
    }

    fun clear(ctx: Context) {
        val run = runFile(ctx)
        if (run.exists() && !run.readText().contains("ENDED:")) end(ctx, "reported")
        crashFile(ctx).delete()
    }
}
