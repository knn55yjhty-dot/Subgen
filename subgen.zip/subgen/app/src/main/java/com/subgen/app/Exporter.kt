package com.subgen.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore

/**
 * Saves finished subtitles as .srt files into a folder the user can see in the Files app:
 * Downloads/SubGen by default, or a folder the user picked. Re-saving (e.g. after a timing
 * change in the player) overwrites the same file.
 */
object Exporter {
    private const val MIME = "application/x-subrip"
    const val DEFAULT_LABEL = "Downloads/SubGen"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("export", Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = prefs(ctx).getBoolean("enabled", true)
    fun setEnabled(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("enabled", on).apply()

    /** Folder picked by the user (a document-tree URI), or null for Downloads/SubGen. */
    fun customFolder(ctx: Context): Uri? = prefs(ctx).getString("tree", null)?.let { Uri.parse(it) }
    fun setCustomFolder(ctx: Context, tree: Uri?, label: String?) {
        prefs(ctx).edit().putString("tree", tree?.toString()).putString("treeLabel", label).apply()
    }

    fun folderLabel(ctx: Context): String =
        if (!enabled(ctx)) "off"
        else if (customFolder(ctx) != null) prefs(ctx).getString("treeLabel", null) ?: "chosen folder"
        else DEFAULT_LABEL

    /** "movie.mp4" + zh -> "movie.zh.srt" (the naming VLC / MX Player pick up automatically). */
    fun fileName(p: Project): String {
        val base = p.name.substringBeforeLast('.').ifBlank { "subtitles" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
        val lang = p.outLang.ifBlank { "und" }
        return "$base.$lang.srt"
    }

    /**
     * Deletes the .srt this app saved to the folder for [p] (the user's video is never touched).
     * Returns true if the file is gone (deleted now, or already removed by the user).
     */
    fun deleteSaved(ctx: Context, p: Project): Boolean {
        val s = p.props.getProperty("savedUri") ?: return true
        val uri = Uri.parse(s)
        val gone = try {
            if (uri.authority == MediaStore.AUTHORITY) { ctx.contentResolver.delete(uri, null, null); true }
            else DocumentsContract.deleteDocument(ctx.contentResolver, uri)
        } catch (_: java.io.FileNotFoundException) {
            true // already deleted in the Files app
        } catch (_: Exception) {
            false // e.g. the file now belongs to an older install of the app
        }
        if (gone) {
            p.props.remove("savedUri"); p.props.remove("savedWhere")
            try { Projects.save(p) } catch (_: Exception) {}
        }
        return gone
    }

    /**
     * Writes the project's subtitles (with its timing adjustment) to the save folder.
     * Returns a human-readable location, or null if saving is off or failed (error goes to the log).
     */
    fun autoSave(ctx: Context, p: Project, log: (String) -> Unit = {}): String? {
        if (!enabled(ctx) || p.id == Projects.PREVIEW_ID) return null
        val text = Srt.format(Srt.parse(p.srtFile.readText()), p.offsetMs / 1000.0)
        val name = fileName(p)
        val cr = ctx.contentResolver

        // 1) overwrite the file saved earlier, if it still exists
        p.props.getProperty("savedUri")?.let { old ->
            try {
                cr.openOutputStream(Uri.parse(old), "wt")?.use { it.write(text.toByteArray()) } ?: throw IllegalStateException()
                return p.props.getProperty("savedWhere") ?: name
            } catch (_: Exception) { /* deleted or moved by the user: save a new one below */ }
        }

        return try {
            val tree = customFolder(ctx)
            val uri: Uri
            val where: String
            if (tree != null) {
                val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                uri = DocumentsContract.createDocument(cr, parent, MIME, name) ?: throw IllegalStateException("could not create file")
                where = "${folderLabel(ctx)}/$name"
            } else {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, MIME)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SubGen")
                }
                uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("could not create file")
                where = "$DEFAULT_LABEL/$name"
            }
            cr.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) } ?: throw IllegalStateException("could not write file")
            p.props.setProperty("savedUri", uri.toString())
            p.props.setProperty("savedWhere", where)
            Projects.save(p)
            where
        } catch (e: Exception) {
            log("saving .srt to ${folderLabel(ctx)} failed: $e")
            null
        }
    }
}
