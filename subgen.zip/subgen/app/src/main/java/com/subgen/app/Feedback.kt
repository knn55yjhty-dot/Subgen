package com.subgen.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

/** "Send feedback / copy log": a box for describing the problem, then copy or share the report. */
object Feedback {
    fun show(act: Activity, project: Project? = null, extra: String? = null, title: String = "Send feedback") {
        val input = EditText(act).apply {
            hint = "What happened? (e.g. line at 1:23 is late, wrong words, crashed at 40%)"
            minLines = 3
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(act)
            .setTitle(title)
            .setMessage("The report includes your note, the app's processing log and device info. No video or audio is included.")
            .setView(input)
            .setPositiveButton("Copy") { _, _ ->
                val report = Diag.fullReport(act, input.text.toString(), project, extra)
                act.getSystemService(ClipboardManager::class.java)
                    ?.setPrimaryClip(ClipData.newPlainText("SubGen report", report))
                Toast.makeText(act, "Report copied. Paste it to Claude.", Toast.LENGTH_LONG).show()
            }
            .setNeutralButton("Share…") { _, _ ->
                val report = Diag.fullReport(act, input.text.toString(), project, extra)
                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report)
                act.startActivity(Intent.createChooser(send, "Send SubGen report"))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
