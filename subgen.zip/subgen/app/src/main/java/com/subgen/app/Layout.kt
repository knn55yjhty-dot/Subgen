package com.subgen.app

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * How a subtitle looks on screen, following the Netflix Timed Text Style Guide:
 *  - English (and other spaced languages): at most 42 characters per line, 20 characters/s
 *  - Chinese / Japanese / Korean: at most 16 characters per line, 9 characters/s
 *  - at most 2 lines; when two are needed the break goes at punctuation or a space near the
 *    middle, with the top line not longer than the bottom one ("pyramid"), and a line never
 *    starts with punctuation
 */
object Layout {
    const val LINE_LATIN = 42
    const val LINE_CJK = 16
    private const val CPS_LATIN = 20.0
    private const val CPS_CJK = 9.0
    private const val MIN_DUR = 0.9   // Netflix minimum is 5/6 s

    private const val PUNCT = "，。！？、；：,.!?;:…"
    private val NO_LINE_START = "，。！？、；：,.!?;:…）」』】》)\\]"

    fun cjkText(t: String): Boolean {
        val letters = t.filter { Character.isLetter(it) }
        if (letters.isEmpty()) return false
        return letters.count { CueBuilder.isCjk(it) || Character.UnicodeScript.of(it.code) == Character.UnicodeScript.HANGUL } * 2 > letters.length
    }

    /** Characters counted for reading speed (Chinese: no spaces; English: including spaces). */
    private fun count(t: String, cjk: Boolean): Int = if (cjk) t.count { !it.isWhitespace() } else t.replace("\n", " ").length

    /** Shortest comfortable time on screen for this text. */
    fun readTime(text: String): Double {
        val cjk = cjkText(text)
        return max(MIN_DUR, count(text, cjk) / (if (cjk) CPS_CJK else CPS_LATIN))
    }

    private fun width(t: String, cjk: Boolean) = if (cjk) t.count { !it.isWhitespace() } else t.length
    private fun limit(cjk: Boolean) = if (cjk) LINE_CJK else LINE_LATIN

    /** Wraps one subtitle onto 2 lines if needed; splits it in time if even 2 lines aren't enough. */
    fun lay(c: Cue): List<Cue> {
        val text = c.text.replace(Regex("\\s*\\n\\s*"), " ").trim()
        val cjk = cjkText(text)
        val lim = limit(cjk)
        if (width(text, cjk) <= lim) return listOf(c.copy(text = text))
        if (width(text, cjk) <= 2 * lim) {
            val two = wrap(text, cjk, lim)
            if (two != null) return listOf(c.copy(text = two))
        }
        // too long for one subtitle: split into parts that each fit, time shared by length
        val parts = splitToFit(text, cjk, lim)
        val total = parts.sumOf { width(it, cjk) }.coerceAtLeast(1)
        val out = mutableListOf<Cue>()
        var t = c.start
        for ((i, p) in parts.withIndex()) {
            val d = (c.end - c.start) * width(p, cjk) / total
            val e = if (i == parts.size - 1) c.end else t + d - Timing.GAP
            out += Cue(t, max(e, t + 0.2), wrap(p, cjk, lim) ?: p)
            t += d
        }
        return out
    }

    /** A few words only: "Hey.", "Okay", "好的" (at most a third of a line). */
    fun isFragment(text: String): Boolean {
        val cjk = cjkText(text)
        return width(text.trim(), cjk) <= limit(cjk) / 3
    }

    /** True if [text] fits on at most two lines. */
    fun fits(text: String): Boolean {
        val t = text.replace('\n', ' ')
        val cjk = cjkText(t)
        val lim = limit(cjk)
        return width(t, cjk) <= lim || (width(t, cjk) <= 2 * lim && wrap(t, cjk, lim) != null)
    }

    /** Best place to break [text] into two lines that each fit, or null if impossible. */
    fun wrap(text: String, cjk: Boolean, lim: Int): String? {
        var best: Pair<Int, Double>? = null
        for (i in 1 until text.length) {
            val top = text.substring(0, i).trimEnd()
            val bottom = text.substring(i).trimStart()
            if (top.isEmpty() || bottom.isEmpty()) continue
            if (width(top, cjk) > lim || width(bottom, cjk) > lim) continue
            if (bottom[0] in NO_LINE_START) continue
            if (!cjk && text[i - 1] != ' ' && text[i] != ' ') continue           // only between words
            val prev = text.substring(0, i).trimEnd().lastOrNull() ?: continue
            var cost = abs(width(top, cjk) - width(bottom, cjk)).toDouble()   // balanced lines
            if (width(top, cjk) > width(bottom, cjk)) cost += 2.0              // prefer shorter top line
            if (prev in PUNCT) cost -= 12.0                                    // break at a natural pause
            if (!cjk && top.substringAfterLast(' ').lowercase() in WEAK_END) cost += 8.0  // not after "the", "a"…
            if (best == null || cost < best.second) best = i to cost
        }
        val i = best?.first ?: return null
        return text.substring(0, i).trimEnd() + "\n" + text.substring(i).trimStart()
    }

    private val WEAK_END = setOf("a", "an", "the", "of", "to", "and", "or", "but", "in", "on", "at", "for", "with", "my", "your", "his", "her", "our", "their", "i")

    /** Splits text into the fewest parts that each fit on two lines, preferring punctuation. */
    private fun splitToFit(text: String, cjk: Boolean, lim: Int): List<String> {
        val parts = mutableListOf<String>()
        var rest = text
        while (width(rest, cjk) > 2 * lim) {
            val n = Math.ceil(width(rest, cjk) / (2.0 * lim)).toInt()
            val target = width(rest, cjk) / n
            var cut = -1; var bestCost = Double.MAX_VALUE
            var w = 0
            for (i in rest.indices) {
                if (!rest[i].isWhitespace() || !cjk) w = width(rest.substring(0, i + 1), cjk)
                if (w > 2 * lim) break
                val boundary = if (cjk) true else (i + 1 < rest.length && rest[i + 1] == ' ')
                if (!boundary || i + 1 >= rest.length || rest.substring(i + 1).trimStart().firstOrNull()?.let { it in NO_LINE_START } == true) continue
                var cost = abs(w - target).toDouble()
                if (rest[i] in PUNCT) cost -= lim / 2.0
                if (cost < bestCost) { bestCost = cost; cut = i }
            }
            if (cut < 0) cut = min(rest.length - 1, 2 * lim - 1)
            parts += rest.substring(0, cut + 1).trim()
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) parts += rest
        return parts
    }
}
