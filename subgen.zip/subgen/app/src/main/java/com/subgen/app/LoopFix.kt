package com.subgen.app

import kotlin.math.max
import kotlin.math.min

/**
 * Finds and repairs places where the speech model got stuck repeating itself, e.g.
 *   0:33 "I know, right?"  0:36 "I know, right?"  0:38 "I know, right?"  0:40 "I know, right?"
 *
 * whisper.cpp has its own loop check (entropy of the last tokens), but the timestamp tokens between
 * the repeats raise that number enough that short repeated phrases slip through. This check looks
 * at the text only. Each stuck stretch is decoded again in a careful mode (beam search, stricter
 * loop check) and the result is kept if it repeats itself less.
 *
 * Times are whisper centiseconds within one batch of audio.
 */
object LoopFix {

    fun segText(s: Seg): String {
        val n = s.toks.sumOf { it.bytes.size }
        val b = ByteArray(n)
        var o = 0
        for (t in s.toks) { t.bytes.copyInto(b, o); o += t.bytes.size }
        return String(b, Charsets.UTF_8).trim()
    }

    private fun key(t: String) = CueBuilder.sameKey(t)

    /** A long phrase said twice in a row inside one line ("give you a pink color, so give you a pink color"). */
    fun innerRepeat(text: String): Boolean {
        val cjk = text.any { CueBuilder.isCjk(it) }
        val units: List<String> = if (cjk) text.filter { Character.isLetterOrDigit(it) }.map { it.toString() }
                                  else text.lowercase().split(Regex("[^\\p{L}\\p{N}']+")).filter { it.isNotEmpty() }
        val minLen = if (cjk) 6 else 5
        // the second copy may follow straight on, or after up to 2 filler words ("..., so ...")
        for (n in minLen..units.size / 2) {
            for (gap in 0..2) {
                for (i in 0..units.size - 2 * n - gap) {
                    if (units.subList(i, i + n) == units.subList(i + n + gap, i + 2 * n + gap)) return true
                }
            }
        }
        return false
    }

    /** How stuck a list of segments looks: extra copies of repeated lines + lines with an inner repeat. */
    fun score(segs: List<Seg>): Int {
        val keys = segs.map { key(segText(it)) }
        var s = 0
        for (i in keys.indices) {
            val k = keys[i]
            if (k.isEmpty()) continue
            // the same line again among the previous 3 lines, within 12 s
            if ((max(0, i - 3) until i).any { keys[it] == k && segs[i].t0 - segs[it].t0 < 1200 }) s++
            if (innerRepeat(segText(segs[i]))) s++
        }
        return s
    }

    /** Stretches (centiseconds) that look stuck. */
    fun find(segs: List<Seg>): List<IntRange> {
        val keys = segs.map { key(segText(it)) }
        val out = mutableListOf<IntRange>()
        var i = 0
        while (i < segs.size) {
            val k = keys[i]
            if (k.isNotEmpty()) {
                // 3+ copies of the same line close together (other lines may sit in between)
                var j = i
                var copies = 1
                var last = i
                while (j + 1 < segs.size && segs[j + 1].t0 - segs[last].t1 < 600 && j + 1 - last <= 2) {
                    j++
                    if (keys[j] == k) { copies++; last = j }
                }
                if (copies >= 3) {
                    out += segs[i].t0..segs[last].t1
                    i = last + 1
                    continue
                }
                if (innerRepeat(segText(segs[i]))) out += segs[i].t0..segs[i].t1
            }
            i++
        }
        // join stretches that touch, pad 1 s each side
        val merged = mutableListOf<IntRange>()
        for (r in out.sortedBy { it.first }) {
            val a = max(0, r.first - 100); val b = r.last + 100
            val l = merged.lastOrNull()
            if (l != null && a <= l.last) merged[merged.size - 1] = l.first..max(l.last, b) else merged += a..b
        }
        return merged
    }

    /**
     * Repairs stuck stretches. [retranscribe] decodes the samples [fromCs, toCs) carefully and returns
     * its segments with times relative to fromCs (or null on failure). Returns the new segment list
     * and how many stretches were found / improved.
     */
    fun repair(segs: List<Seg>, totalCs: Int, retranscribe: (Int, Int) -> List<Seg>?): Triple<List<Seg>, Int, Int> {
        val regions = find(segs).map { it.first..min(it.last, totalCs) }.filter { it.last - it.first >= 50 }
        if (regions.isEmpty()) return Triple(segs, 0, 0)
        var cur = segs
        var fixed = 0
        // Careful decoding is ~3x slower: spend at most a quarter of the batch's length on it,
        // so a badly stuck batch can't double the total time.
        var budget = totalCs / 4
        for (r in regions) {
            if (budget <= 0) break
            // cap the work: at most 60 s per stretch
            val a = r.first; val b = min(min(r.last, a + 6000), a + budget)
            budget -= b - a
            val inside = cur.filter { (it.t0 + it.t1) / 2 in a until b }
            val again = try { retranscribe(a, b) } catch (e: CancelledException) { throw e } catch (_: Throwable) { null } ?: continue
            val shifted = again.map { s -> shift(s, a) }.filter { (it.t0 + it.t1) / 2 in a until b }
            if (score(shifted) < score(inside)) {
                cur = (cur.filter { (it.t0 + it.t1) / 2 !in a until b } + shifted).sortedBy { it.t0 }
                fixed++
            }
        }
        return Triple(cur, regions.size, fixed)
    }

    private fun shift(s: Seg, cs: Int): Seg {
        val n = Seg(s.t0 + cs, s.t1 + cs)
        for (t in s.toks) n.toks += Tok(t.t0 + cs, t.t1 + cs, if (t.tdtw >= 0) t.tdtw + cs else t.tdtw, t.p, t.bytes)
        return n
    }
}
