package com.subgen.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private val srcCodes = listOf("auto", "en", "zh", "ko", "ja")
    private val srcLabels = listOf("Auto-detect", "English", "Chinese", "Korean", "Japanese")
    private val tgtCodes = listOf("orig", "en", "zh")
    private val tgtLabels = listOf("Same as spoken language", "English", "Simplified Chinese (简体中文)")

    private var picked: List<Pair<Uri, String>> = emptyList()
    private var exportTarget: Project? = null

    private lateinit var tvFile: TextView
    private lateinit var spSrc: Spinner
    private lateinit var spTgt: Spinner
    private lateinit var rbAccurate: RadioButton
    private lateinit var rbFast: RadioButton
    private lateinit var btnGo: Button
    private lateinit var btnCancel: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var list: LinearLayout
    private lateinit var tvPreview: TextView
    private lateinit var btnWatch: Button
    private lateinit var queueBox: LinearLayout
    private lateinit var queueList: LinearLayout
    private lateinit var btnStartQueue: Button
    private lateinit var btnStopQueue: Button

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            picked = uris.map { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                uri to displayName(uri)
            }
            tvFile.text = if (picked.size == 1) picked[0].second
                else "${picked.size} videos selected:\n" + picked.joinToString("\n") { "• " + it.second }
        }
    }

    private val exportSrt = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        val p = exportTarget ?: return@registerForActivityResult
        if (uri != null) {
            try {
                val cues = Srt.parse(p.srtFile.readText())
                contentResolver.openOutputStream(uri)?.use {
                    it.write(Srt.format(cues, p.offsetMs / 1000.0).toByteArray())
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvFile = findViewById(R.id.tvFile)
        spSrc = findViewById(R.id.spSrc)
        spTgt = findViewById(R.id.spTgt)
        rbAccurate = findViewById(R.id.rbAccurate)
        rbFast = findViewById(R.id.rbFast)
        btnGo = findViewById(R.id.btnGo)
        btnCancel = findViewById(R.id.btnCancel)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        list = findViewById(R.id.list)
        tvPreview = findViewById(R.id.tvPreview)
        btnWatch = findViewById(R.id.btnWatch)
        btnWatch.setOnClickListener { watchSoFar() }
        queueBox = findViewById(R.id.queueBox)
        queueList = findViewById(R.id.queueList)
        btnStartQueue = findViewById(R.id.btnStartQueue)
        btnStopQueue = findViewById(R.id.btnStopQueue)
        btnStartQueue.setOnClickListener { SubtitleService.start(this) }
        btnStopQueue.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Stop the queue? The current video is cancelled and goes back into the list; waiting videos stay.")
                .setPositiveButton("Stop") { _, _ -> SubtitleService.stopQueue() }
                .setNegativeButton("Keep going", null)
                .show()
        }
        findViewById<Button>(R.id.btnClearQueue).setOnClickListener { Queue.clearFinished(this) }
        Queue.load(this)
        if (!JobState.serviceActive.value) Queue.resetStale(this)

        spSrc.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, srcLabels)
        spTgt.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tgtLabels)
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)
        spSrc.setSelection(prefs.getInt("src", 0))
        spTgt.setSelection(prefs.getInt("tgt", 0))
        if (prefs.getBoolean("accurate", true)) rbAccurate.isChecked = true else rbFast.isChecked = true

        findViewById<Button>(R.id.btnPick).setOnClickListener { pickVideo.launch(arrayOf("video/*", "audio/*")) }
        btnGo.setOnClickListener { startJob() }
        btnCancel.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Cancel this video? The queue continues with the next one.")
                .setPositiveButton("Cancel video") { _, _ -> SubtitleService.cancel() }
                .setNegativeButton("Keep going", null)
                .show()
        }
        findViewById<Button>(R.id.btnFeedback).setOnClickListener { Feedback.show(this) }

        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        Diag.installCrashHandler(this)
        if (!JobState.serviceActive.value) showCrashReport()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JobState.state.collect { render(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JobState.preview.collect { renderPreview(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Queue.items.collect { renderQueue(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JobState.serviceActive.collect { renderQueue(Queue.items.value) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun showCrashReport() {
        val report = Diag.pendingReport(this) ?: return
        AlertDialog.Builder(this)
            .setTitle("The last run stopped unexpectedly")
            .setMessage(report)
            .setPositiveButton("Copy report") { _, _ ->
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("SubGen report", report))
                Toast.makeText(this, "Copied. Paste it to Claude.", Toast.LENGTH_LONG).show()
                Diag.clear(this)
            }
            .setNegativeButton("Dismiss") { _, _ -> Diag.clear(this) }
            .show()
    }

    /** Adds the chosen video(s) to the queue with the current settings and starts processing. */
    private fun startJob() {
        if (picked.isEmpty()) {
            Toast.makeText(this, "Choose a video first", Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences("ui", MODE_PRIVATE).edit()
            .putInt("src", spSrc.selectedItemPosition)
            .putInt("tgt", spTgt.selectedItemPosition)
            .putBoolean("accurate", rbAccurate.isChecked)
            .apply()
        val now = System.currentTimeMillis()
        val items = picked.mapIndexed { i, (uri, name) ->
            QueueItem("${now}_$i", uri.toString(), name,
                srcCodes[spSrc.selectedItemPosition], tgtCodes[spTgt.selectedItemPosition], rbAccurate.isChecked)
        }
        Queue.add(this, items)
        picked = emptyList()
        tvFile.text = "No video selected"
        Toast.makeText(this, if (items.size == 1) "Added to the queue" else "${items.size} videos added to the queue", Toast.LENGTH_SHORT).show()
        SubtitleService.start(this)
    }

    private fun renderQueue(items: List<QueueItem>) {
        queueList.removeAllViews()
        queueBox.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        val running = JobState.serviceActive.value
        val waiting = items.count { it.status == QueueItem.WAITING }
        btnStartQueue.visibility = if (!running && waiting > 0) View.VISIBLE else View.GONE
        btnStartQueue.text = "Start queue ($waiting waiting)"
        btnStopQueue.visibility = if (running && waiting > 0) View.VISIBLE else View.GONE
        for (it in items) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
            val label = when (it.status) {
                QueueItem.WAITING -> "⏳ waiting"
                QueueItem.RUNNING -> "▶ working"
                QueueItem.DONE -> if (it.error.isNotEmpty()) "✓ done (see note)" else "✓ done"
                QueueItem.FAILED -> "✗ failed"
                else -> "– cancelled"
            }
            val tgt = when (it.target) { "en" -> "English"; "zh" -> "简体中文"; else -> "original" }
            row.addView(TextView(this).apply {
                text = "${it.name}\n$label · ${if (it.accurate) "Accurate" else "Fast"} · $tgt" +
                    (if (it.status == QueueItem.FAILED && it.error.isNotEmpty()) "\n" + it.error.take(120) else "")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            when (it.status) {
                QueueItem.WAITING -> row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                    text = "Remove"
                    setOnClickListener { _ -> Queue.remove(this@MainActivity, it.id) }
                })
                QueueItem.FAILED, QueueItem.CANCELLED -> row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                    text = "Retry"
                    setOnClickListener { _ -> Queue.retry(this@MainActivity, it.id); SubtitleService.start(this@MainActivity) }
                })
                QueueItem.DONE -> if (it.resultId.isNotEmpty()) row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                    text = "Play"
                    setOnClickListener { _ -> openPlayer(it.resultId) }
                })
            }
            queueList.addView(row)
        }
    }

    private fun render(s: JobState.S) {
        if (!s.running) { tvPreview.visibility = View.GONE; btnWatch.visibility = View.GONE }
        else renderPreview(JobState.preview.value)
        btnGo.text = if (s.running || JobState.serviceActive.value) "Add to queue" else "Generate subtitles"
        btnCancel.visibility = if (s.running) View.VISIBLE else View.GONE
        progress.visibility = if (s.running) View.VISIBLE else View.GONE
        progress.progress = (s.progress * 1000).toInt()
        tvStatus.text = when {
            s.running -> "${s.stage}\nOverall ${(s.progress * 100).toInt()}%" +
                (s.etaSec?.let { " · ${Eta.format(it).replaceFirstChar { c -> c.uppercase() }}" } ?: " · Estimating time…") +
                "\nYou can leave the app; it keeps working in the background."
            s.error != null -> "Failed: ${s.error}"
            else -> s.stage
        }
        renderQueue(Queue.items.value)
        if (!s.running) refreshList()
        if (!s.running && s.doneId != null && s.doneId != JobState.shownDoneId) {
            JobState.shownDoneId = s.doneId
            refreshList()
            openPlayer(s.doneId)
        }
    }

    private fun renderPreview(lines: List<JobState.PreviewLine>) {
        val running = JobState.state.value.running
        tvPreview.visibility = if (running && lines.isNotEmpty()) View.VISIBLE else View.GONE
        btnWatch.visibility = if (running && lines.isNotEmpty()) View.VISIBLE else View.GONE
        tvPreview.text = "Latest lines (live):\n" + lines.joinToString("\n") { l ->
            val t = l.time.toInt()
            val stamp = if (t >= 3600) "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60) else "%d:%02d".format(t / 60, t % 60)
            (if (l.translated) "  → " else "$stamp  ") + l.text
        }
    }

    /** Opens the video with the subtitles made so far, a little before the newest line. */
    private fun watchSoFar() {
        val p = JobState.pipeline ?: return
        val res = try { p.savePreview() } catch (e: Exception) { null }
        if (res == null) {
            Toast.makeText(this, "No subtitles ready yet, try again in a moment", Toast.LENGTH_SHORT).show()
            return
        }
        val startMs = ((res.second - 20).coerceAtLeast(0.0) * 1000).toLong()
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", res.first).putExtra("startMs", startMs))
    }

    private fun openPlayer(id: String) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", id))
    }

    private fun refreshList() {
        list.removeAllViews()
        val projects = Projects.list(this)
        if (projects.isEmpty()) {
            list.addView(TextView(this).apply { text = "Nothing yet."; setPadding(0, 16, 0, 16) })
            return
        }
        val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        for (p in projects) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 24, 0, 8)
            }
            box.addView(TextView(this).apply {
                text = p.name
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            box.addView(TextView(this).apply {
                text = "${Projects.langLabel(p.srcLang)} → ${Projects.langLabel(p.outLang)} · ${df.format(Date(p.created))}"
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(MaterialButton(this).apply {
                text = "Play"
                setOnClickListener { openPlayer(p.id) }
            })
            row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Save .srt"
                setOnClickListener {
                    exportTarget = p
                    exportSrt.launch(p.name.substringBeforeLast('.') + ".srt")
                }
            })
            row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = "Report"
                setOnClickListener { Feedback.show(this@MainActivity, p, title = "Report a problem with this video") }
            })
            row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = "Delete"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("Delete these subtitles?")
                        .setPositiveButton("Delete") { _, _ -> Projects.delete(p); refreshList() }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            })
            box.addView(row)
            list.addView(box)
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "Video"
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "Video"
    }
}
