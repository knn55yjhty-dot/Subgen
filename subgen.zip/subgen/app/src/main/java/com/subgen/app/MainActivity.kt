package com.subgen.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.Menu
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import kotlin.math.max
import android.widget.HorizontalScrollView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import androidx.core.widget.doAfterTextChanged
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private val srcCodes = listOf("auto", "en", "zh", "ko", "ja")
    private val srcLabels = listOf("Auto-detect", "English", "Chinese", "Korean", "Japanese")
    private val tgtCodes = listOf("orig", "en", "zh")
    private val tgtLabels = listOf("Same as spoken language", "English", "Simplified Chinese (简体中文)")

    private var picked: List<Pair<Uri, String>> = emptyList()
    private var exportTarget: Project? = null

    private lateinit var tvFile: TextView
    private lateinit var spSrc: Spinner
    private lateinit var spTgt: Spinner
    private lateinit var rbAccurate: RadioButton
    private lateinit var rbFast: RadioButton
    private lateinit var btnGo: Button
    private lateinit var btnCancel: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var list: LinearLayout
    private lateinit var tvPreview: TextView
    private lateinit var btnWatch: Button
    private lateinit var queueBox: LinearLayout
    private lateinit var queueList: LinearLayout
    private lateinit var btnStartQueue: Button
    private lateinit var btnStopQueue: Button
    private lateinit var pageGenerate: View
    private lateinit var pageLibrary: View
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var etSearch: EditText
    private lateinit var spSort: Spinner
    private lateinit var tvLibCount: TextView
    private val sortLabels = listOf("Newest first", "Oldest first", "Name A–Z")

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            picked = uris.map { uri ->
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
                uri to displayName(uri)
            }
            tvFile.text = if (picked.size == 1) picked[0].second
                else "${picked.size} videos selected:\n" + picked.joinToString("\n") { "• " + it.second }
        }
    }

    private val exportSrt = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        val p = exportTarget ?: return@registerForActivityResult
        if (uri != null) {
            try {
                val cues = Srt.parse(p.srtFile.readText())
                contentResolver.openOutputStream(uri)?.use {
                    it.write(Srt.format(cues, p.offsetMs / 1000.0).toByteArray())
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvFile = findViewById(R.id.tvFile)
        spSrc = findViewById(R.id.spSrc)
        spTgt = findViewById(R.id.spTgt)
        rbAccurate = findViewById(R.id.rbAccurate)
        rbFast = findViewById(R.id.rbFast)
        btnGo = findViewById(R.id.btnGo)
        btnCancel = findViewById(R.id.btnCancel)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        list = findViewById(R.id.list)
        tvPreview = findViewById(R.id.tvPreview)
        btnWatch = findViewById(R.id.btnWatch)
        btnWatch.setOnClickListener { watchSoFar() }
        queueBox = findViewById(R.id.queueBox)
        queueList = findViewById(R.id.queueList)
        btnStartQueue = findViewById(R.id.btnStartQueue)
        btnStopQueue = findViewById(R.id.btnStopQueue)
        btnStartQueue.setOnClickListener { SubtitleService.start(this) }
        btnStopQueue.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Stop the queue? The current video is cancelled and goes back into the list; waiting videos stay.")
                .setPositiveButton("Stop") { _, _ -> SubtitleService.stopQueue() }
                .setNegativeButton("Keep going", null)
                .show()
        }
        findViewById<Button>(R.id.btnClearQueue).setOnClickListener { Queue.clearFinished(this) }
        Queue.load(this)
        if (!JobState.serviceActive.value) Queue.resetStale(this)

        spSrc.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, srcLabels)
        spTgt.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tgtLabels)
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)
        spSrc.setSelection(prefs.getInt("src", 0))
        spTgt.setSelection(prefs.getInt("tgt", 0))
        if (prefs.getBoolean("accurate", true)) rbAccurate.isChecked = true else rbFast.isChecked = true

        findViewById<Button>(R.id.btnPick).setOnClickListener { pickVideo.launch(arrayOf("video/*", "audio/*")) }
        btnGo.setOnClickListener { startJob() }
        btnCancel.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Cancel this video? The queue continues with the next one.")
                .setPositiveButton("Cancel video") { _, _ -> SubtitleService.cancel() }
                .setNegativeButton("Keep going", null)
                .show()
        }
        pageGenerate = findViewById(R.id.pageGenerate)
        pageLibrary = findViewById(R.id.pageLibrary)
        bottomNav = findViewById(R.id.bottomNav)
        etSearch = findViewById(R.id.etSearch)
        spSort = findViewById(R.id.spSort)
        tvLibCount = findViewById(R.id.tvLibCount)
        spSort.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sortLabels)
        spSort.setSelection(prefs.getInt("sort", 0))
        spSort.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                getSharedPreferences("ui", MODE_PRIVATE).edit().putInt("sort", position).apply()
                refreshList()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        etSearch.doAfterTextChanged { refreshList() }
        wireTabBar()
        showTab(savedInstanceState?.getString("tab") ?: intent.getStringExtra("tab") ?: TAB_GENERATE)

        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        Diag.installCrashHandler(this)
        if (!JobState.serviceActive.value) showCrashReport()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JobState.state.collect { render(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JobState.preview.collect { renderPreview(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                Queue.items.collect { renderQueue(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JobState.serviceActive.collect { renderQueue(Queue.items.value) }
            }
        }
    }

    companion object {
        const val TAB_GENERATE = "generate"
        const val TAB_LIBRARY = "library"
    }
    private var currentTab = TAB_GENERATE
    /** True while the app itself moves the tab bar, so the bar's "selected" callback is ignored. */
    private var syncingNav = false

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", currentTab)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra("tab")?.let { showTab(it) }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.menu_feedback) { Feedback.show(this); return true }
        if (item.itemId == R.id.menu_folder) { folderDialog(); return true }
        return super.onOptionsItemSelected(item)
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) {
            try {
                contentResolver.takePersistableUriPermission(tree,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                val label = Uri.decode(tree.lastPathSegment ?: "chosen folder").substringAfter(':').ifBlank { "chosen folder" }
                Exporter.setCustomFolder(this, tree, label)
                Exporter.setEnabled(this, true)
                Toast.makeText(this, "New subtitles will be saved to: $label", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Couldn't use that folder: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Where finished subtitles are saved automatically. */
    private fun folderDialog() {
        AlertDialog.Builder(this)
            .setTitle("Save folder")
            .setMessage("Finished subtitles are saved automatically as .srt files.\n\nNow: ${Exporter.folderLabel(this)}\n\n" +
                "Files are named like \"movie.zh.srt\", which VLC and MX Player load automatically when the file is next to the video.")
            .setPositiveButton("Choose folder…") { _, _ -> pickFolder.launch(null) }
            .setNeutralButton("Use ${Exporter.DEFAULT_LABEL}") { _, _ ->
                Exporter.setCustomFolder(this, null, null); Exporter.setEnabled(this, true)
                Toast.makeText(this, "Saving to ${Exporter.DEFAULT_LABEL}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Turn off") { _, _ ->
                Exporter.setEnabled(this, false)
                Toast.makeText(this, "Automatic saving is off (subtitles stay in the Library)", Toast.LENGTH_LONG).show()
            }
            .show()
    }

    private fun wireTabBar() {
        bottomNav.setOnItemSelectedListener { item ->
            // the tab bar is already switching to this item: don't tell it to switch again
            if (!syncingNav) showTab(if (item.itemId == R.id.nav_library) TAB_LIBRARY else TAB_GENERATE, fromNav = true)
            true
        }
    }

    private fun showTab(tab: String, fromNav: Boolean = false) {
        currentTab = tab
        val lib = tab == TAB_LIBRARY
        pageGenerate.visibility = if (lib) View.GONE else View.VISIBLE
        pageLibrary.visibility = if (lib) View.VISIBLE else View.GONE
        val wanted = if (lib) R.id.nav_library else R.id.nav_generate
        // Only move the tab bar when the switch came from elsewhere (notification, restore).
        // The bar calls our listener *before* it updates its selection, so moving it from inside
        // the listener used to call back into here forever (StackOverflowError).
        if (!fromNav && bottomNav.selectedItemId != wanted) {
            syncingNav = true
            try { bottomNav.selectedItemId = wanted } finally { syncingNav = false }
        }
        supportActionBar?.title = if (lib) "Library" else "SubGen"
        if (lib) {
            // everything finished up to now counts as seen
            getSharedPreferences("ui", MODE_PRIVATE).edit().putLong("libSeen", System.currentTimeMillis()).apply()
            refreshList()
        }
        updateBadge()
    }

    /** Number badge on the Library tab: subtitles finished since the Library was last opened. */
    private fun updateBadge() {
        val seen = getSharedPreferences("ui", MODE_PRIVATE).getLong("libSeen", 0L)
        val fresh = if (currentTab == TAB_LIBRARY) 0 else Projects.list(this).count { it.created > seen }
        if (fresh > 0) bottomNav.getOrCreateBadge(R.id.nav_library).number = fresh
        else bottomNav.removeBadge(R.id.nav_library)
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun showCrashReport() {
        val report = Diag.pendingReport(this) ?: return
        AlertDialog.Builder(this)
            .setTitle("The last run stopped unexpectedly")
            .setMessage(report)
            .setPositiveButton("Copy report") { _, _ ->
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("SubGen report", report))
                Toast.makeText(this, "Copied. Paste it to Claude.", Toast.LENGTH_LONG).show()
                Diag.clear(this)
            }
            .setNegativeButton("Dismiss") { _, _ -> Diag.clear(this) }
            .show()
    }

    /** Adds the chosen video(s) to the queue with the current settings and starts processing. */
    private fun startJob() {
        if (picked.isEmpty()) {
            Toast.makeText(this, "Choose a video first", Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences("ui", MODE_PRIVATE).edit()
            .putInt("src", spSrc.selectedItemPosition)
            .putInt("tgt", spTgt.selectedItemPosition)
            .putBoolean("accurate", rbAccurate.isChecked)
            .apply()
        val now = System.currentTimeMillis()
        val items = picked.mapIndexed { i, (uri, name) ->
            QueueItem("${now}_$i", uri.toString(), name,
                srcCodes[spSrc.selectedItemPosition], tgtCodes[spTgt.selectedItemPosition], rbAccurate.isChecked)
        }
        Queue.add(this, items)
        picked = emptyList()
        tvFile.text = "No video selected"
        Toast.makeText(this, if (items.size == 1) "Added to the queue" else "${items.size} videos added to the queue", Toast.LENGTH_SHORT).show()
        SubtitleService.start(this)
    }

    private fun renderQueue(items: List<QueueItem>) {
        queueList.removeAllViews()
        queueBox.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        val running = JobState.serviceActive.value
        val waiting = items.count { it.status == QueueItem.WAITING }
        btnStartQueue.visibility = if (!running && waiting > 0) View.VISIBLE else View.GONE
        btnStartQueue.text = "Start queue ($waiting waiting)"
        btnStopQueue.visibility = if (running && waiting > 0) View.VISIBLE else View.GONE
        for (it in items) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 8, 0, 8) }
            val label = when (it.status) {
                QueueItem.WAITING -> "⏳ waiting"
                QueueItem.RUNNING -> "▶ working"
                QueueItem.DONE -> if (it.error.isNotEmpty()) "✓ done (see note)" else "✓ done"
                QueueItem.FAILED -> "✗ failed"
                else -> "– cancelled"
            }
            val tgt = when (it.target) { "en" -> "English"; "zh" -> "简体中文"; else -> "original" }
            row.addView(TextView(this).apply {
                text = "${it.name}\n$label · ${if (it.accurate) "Accurate" else "Fast"} · $tgt" +
                    (if (it.status == QueueItem.FAILED && it.error.isNotEmpty()) "\n" + it.error.take(120) else "")
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            when (it.status) {
                QueueItem.WAITING -> row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                    text = "Remove"
                    setOnClickListener { _ -> Queue.remove(this@MainActivity, it.id) }
                })
                QueueItem.FAILED, QueueItem.CANCELLED -> row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                    text = "Retry"
                    setOnClickListener { _ -> Queue.retry(this@MainActivity, it.id); SubtitleService.start(this@MainActivity) }
                })
                QueueItem.DONE -> if (it.resultId.isNotEmpty()) row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                    text = "Play"
                    setOnClickListener { _ -> openPlayer(it.resultId) }
                })
            }
            queueList.addView(row)
        }
    }

    private fun render(s: JobState.S) {
        if (!s.running) { tvPreview.visibility = View.GONE; btnWatch.visibility = View.GONE }
        else renderPreview(JobState.preview.value)
        btnGo.text = if (s.running || JobState.serviceActive.value) "Add to queue" else "Generate subtitles"
        btnCancel.visibility = if (s.running) View.VISIBLE else View.GONE
        progress.visibility = if (s.running) View.VISIBLE else View.GONE
        progress.progress = (s.progress * 1000).toInt()
        tvStatus.text = when {
            s.running -> "${s.stage}\nOverall ${(s.progress * 100).toInt()}%" +
                (s.etaSec?.let { " · ${Eta.format(it).replaceFirstChar { c -> c.uppercase() }}" } ?: " · Estimating time…") +
                "\nYou can leave the app; it keeps working in the background."
            s.error != null -> "Failed: ${s.error}"
            else -> s.stage
        }
        renderQueue(Queue.items.value)
        if (!s.running) refreshList()
        if (!s.running && s.doneId != null && s.doneId != JobState.shownDoneId) {
            JobState.shownDoneId = s.doneId
            refreshList()
            openPlayer(s.doneId)
        }
    }

    private fun renderPreview(lines: List<JobState.PreviewLine>) {
        val running = JobState.state.value.running
        tvPreview.visibility = if (running && lines.isNotEmpty()) View.VISIBLE else View.GONE
        btnWatch.visibility = if (running && lines.isNotEmpty()) View.VISIBLE else View.GONE
        tvPreview.text = "Latest lines (live):\n" + lines.joinToString("\n") { l ->
            val t = l.time.toInt()
            val stamp = if (t >= 3600) "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60) else "%d:%02d".format(t / 60, t % 60)
            (if (l.translated) "  → " else "$stamp  ") + l.text
        }
    }

    /** Opens the video with the subtitles made so far, a little before the newest line. */
    private fun watchSoFar() {
        val p = JobState.pipeline ?: return
        val res = try { p.savePreview() } catch (e: Exception) { null }
        if (res == null) {
            Toast.makeText(this, "No subtitles ready yet, try again in a moment", Toast.LENGTH_SHORT).show()
            return
        }
        val startMs = ((res.second - 20).coerceAtLeast(0.0) * 1000).toLong()
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", res.first).putExtra("startMs", startMs))
    }

    private fun openPlayer(id: String) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", id))
    }

    private fun fmtDur(sec: Double): String {
        val t = sec.toInt()
        return if (t >= 3600) "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60) else "%d:%02d".format(t / 60, t % 60)
    }

    /** Library tab: finished subtitles, filtered by the search box and sorted. */
    private fun refreshList() {
        updateBadge()
        if (currentTab != TAB_LIBRARY) return
        list.removeAllViews()
        val all = Projects.list(this)
        val q = etSearch.text?.toString()?.trim()?.lowercase() ?: ""
        var projects = if (q.isEmpty()) all else all.filter { it.name.lowercase().contains(q) }
        projects = when (spSort.selectedItemPosition) {
            1 -> projects.sortedBy { it.created }
            2 -> projects.sortedBy { it.name.lowercase() }
            else -> projects.sortedByDescending { it.created }
        }
        tvLibCount.text = when {
            all.isEmpty() -> ""
            q.isEmpty() -> "${all.size} video${if (all.size == 1) "" else "s"}"
            else -> "${projects.size} of ${all.size} match"
        }
        if (projects.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (all.isEmpty()) "No subtitles yet.\n\nGo to Generate, choose a video and tap Generate subtitles. Finished subtitles appear here."
                       else "Nothing matches \"$q\"."
                setPadding(0, 32, 0, 32)
            })
            return
        }
        val df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        for (p in projects) {
            val cues = try { Srt.parse(p.srtFile.readText()) } catch (_: Exception) { emptyList() }
            val card = MaterialCardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(0, 12, 0, 12) }
                radius = 24f
                cardElevation = 3f
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(32, 24, 32, 8)
            }
            box.addView(TextView(this).apply {
                text = p.name
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            val length = if (cues.isNotEmpty()) " · ${fmtDur(cues.last().end)}" else ""
            val offset = if (p.offsetMs != 0) " · timing %+.1fs".format(p.offsetMs / 1000.0) else ""
            val saved = p.props.getProperty("savedWhere")
            box.addView(TextView(this).apply {
                text = "${Projects.langLabel(p.srcLang)} → ${Projects.langLabel(p.outLang)} · ${cues.size} lines$length$offset\n${df.format(Date(p.created))}" +
                    "\n" + (if (saved != null) "📁 Saved: $saved" else "📁 Not saved to a folder yet")
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(MaterialButton(this).apply {
                text = "Play"
                setOnClickListener { openPlayer(p.id) }
            })
            if (saved == null) row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = "Save to folder"
                setOnClickListener {
                    if (!Exporter.enabled(this@MainActivity)) Exporter.setEnabled(this@MainActivity, true)
                    val where = Exporter.autoSave(this@MainActivity, p)
                    Toast.makeText(this@MainActivity, if (where != null) "Saved: $where" else "Couldn't save. Check the save folder in the ⋮ menu.", Toast.LENGTH_LONG).show()
                    refreshList()
                }
            })
            row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = "View"
                setOnClickListener { showSubtitles(p) }
            })
            row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = "More"
                setOnClickListener { moreMenu(p) }
            })
            box.addView(HorizontalScrollView(this).apply { addView(row) })
            card.addView(box)
            card.setOnClickListener { showSubtitles(p) }
            list.addView(card)
        }
    }

    /** Less common actions for one Library item. Ones that leave SubGen say so. */
    private fun moreMenu(p: Project) {
        val items = arrayOf(
            "Report a problem with this video",
            "Save a copy somewhere else… (opens your phone's Files)",
            "Delete from Library")
        AlertDialog.Builder(this)
            .setTitle(p.name)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> Feedback.show(this, p, title = "Report a problem with this video")
                    1 -> { exportTarget = p; exportSrt.launch(p.name.substringBeforeLast('.') + ".srt") }
                    2 -> AlertDialog.Builder(this)
                        .setTitle("Delete subtitles?")
                        .setMessage("\"${p.name}\"\n\nRemoves it from the Library. Your video and any .srt file already saved to a folder are not touched.")
                        .setPositiveButton("Delete") { _, _ -> Projects.delete(p); refreshList() }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    /**
     * In-app view of one finished subtitle file: where it is saved and every line with its time.
     * Search the lines; tap one to play the video from that moment. Nothing leaves SubGen.
     */
    private fun showSubtitles(p: Project) {
        val cues = try { Srt.parse(p.srtFile.readText()) } catch (_: Exception) { emptyList() }
        val off = p.offsetMs / 1000.0
        val rows = cues.map { c -> fmtClock(max(0.0, c.start + off)) + "   " + c.text.replace('\n', ' ') }
        val saved = p.props.getProperty("savedWhere")
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        box.addView(TextView(this).apply {
            text = "File: ${Exporter.fileName(p)}\n" +
                (if (saved != null) "Saved in: $saved" else "Not saved to a folder yet (it is kept here in SubGen)") +
                "\n${cues.size} lines" + (if (cues.isNotEmpty()) " · ${fmtDur(cues.last().end)}" else "") +
                "\nTap a line to play the video from there."
        })
        val search = EditText(this).apply { hint = "Search the subtitles"; isSingleLine = true }
        box.addView(search)
        val shown = rows.indices.toMutableList()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows.toMutableList())
        val lv = ListView(this).apply {
            this.adapter = adapter
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                (resources.displayMetrics.heightPixels * 0.55).toInt())
        }
        box.addView(lv)
        search.doAfterTextChanged { e ->
            val q = e?.toString()?.trim()?.lowercase() ?: ""
            shown.clear()
            rows.indices.filterTo(shown) { q.isEmpty() || rows[it].lowercase().contains(q) }
            adapter.clear(); adapter.addAll(shown.map { rows[it] }); adapter.notifyDataSetChanged()
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(p.name)
            .setView(box)
            .setPositiveButton("Play") { _, _ -> openPlayer(p.id) }
            .setNegativeButton("Close", null)
            .create()
        lv.setOnItemClickListener { _, _, pos, _ ->
            val c = cues.getOrNull(shown.getOrNull(pos) ?: return@setOnItemClickListener) ?: return@setOnItemClickListener
            dlg.dismiss()
            val ms = (max(0.0, c.start + off - 1.0) * 1000).toLong()
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", p.id).putExtra("startMs", ms))
        }
        dlg.show()
    }

    private fun fmtClock(sec: Double): String {
        val t = sec.toInt()
        return "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60)
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "Video"
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "Video"
    }
}
