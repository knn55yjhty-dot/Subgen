package com.subgen.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private val srcCodes = listOf("auto", "en", "zh", "ko", "ja")
    private val srcLabels = listOf("Auto-detect", "English", "Chinese", "Korean", "Japanese")
    private val tgtCodes = listOf("orig", "en", "zh")
    private val tgtLabels = listOf("Same as spoken language", "English", "Simplified Chinese (简体中文)")

    private var videoUri: Uri? = null
    private var videoName = ""
    private var exportTarget: Project? = null

    private lateinit var tvFile: TextView
    private lateinit var spSrc: Spinner
    private lateinit var spTgt: Spinner
    private lateinit var rbAccurate: RadioButton
    private lateinit var rbFast: RadioButton
    private lateinit var btnGo: Button
    private lateinit var btnCancel: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var list: LinearLayout

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            videoUri = uri
            videoName = displayName(uri)
            tvFile.text = videoName
        }
    }

    private val exportSrt = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        val p = exportTarget ?: return@registerForActivityResult
        if (uri != null) {
            try {
                val cues = Srt.parse(p.srtFile.readText())
                contentResolver.openOutputStream(uri)?.use {
                    it.write(Srt.format(cues, p.offsetMs / 1000.0).toByteArray())
                }
                Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvFile = findViewById(R.id.tvFile)
        spSrc = findViewById(R.id.spSrc)
        spTgt = findViewById(R.id.spTgt)
        rbAccurate = findViewById(R.id.rbAccurate)
        rbFast = findViewById(R.id.rbFast)
        btnGo = findViewById(R.id.btnGo)
        btnCancel = findViewById(R.id.btnCancel)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        list = findViewById(R.id.list)

        spSrc.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, srcLabels)
        spTgt.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tgtLabels)
        val prefs = getSharedPreferences("ui", MODE_PRIVATE)
        spSrc.setSelection(prefs.getInt("src", 0))
        spTgt.setSelection(prefs.getInt("tgt", 0))
        if (prefs.getBoolean("accurate", true)) rbAccurate.isChecked = true else rbFast.isChecked = true

        findViewById<Button>(R.id.btnPick).setOnClickListener { pickVideo.launch(arrayOf("video/*", "audio/*")) }
        btnGo.setOnClickListener { startJob() }
        btnCancel.setOnClickListener { SubtitleService.cancel() }
        findViewById<Button>(R.id.btnFeedback).setOnClickListener { Feedback.show(this) }

        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        Diag.installCrashHandler(this)
        if (!JobState.state.value.running) showCrashReport()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                JobState.state.collect { render(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun showCrashReport() {
        val report = Diag.pendingReport(this) ?: return
        AlertDialog.Builder(this)
            .setTitle("The last run stopped unexpectedly")
            .setMessage(report)
            .setPositiveButton("Copy report") { _, _ ->
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("SubGen report", report))
                Toast.makeText(this, "Copied. Paste it to Claude.", Toast.LENGTH_LONG).show()
                Diag.clear(this)
            }
            .setNegativeButton("Dismiss") { _, _ -> Diag.clear(this) }
            .show()
    }

    private fun startJob() {
        val uri = videoUri
        if (uri == null) {
            Toast.makeText(this, "Choose a video first", Toast.LENGTH_SHORT).show()
            return
        }
        if (JobState.state.value.running) return
        getSharedPreferences("ui", MODE_PRIVATE).edit()
            .putInt("src", spSrc.selectedItemPosition)
            .putInt("tgt", spTgt.selectedItemPosition)
            .putBoolean("accurate", rbAccurate.isChecked)
            .apply()
        val req = JobRequest(
            uri, videoName,
            srcCodes[spSrc.selectedItemPosition],
            tgtCodes[spTgt.selectedItemPosition],
            rbAccurate.isChecked
        )
        SubtitleService.start(this, req)
    }

    private fun render(s: JobState.S) {
        btnGo.isEnabled = !s.running
        btnCancel.visibility = if (s.running) View.VISIBLE else View.GONE
        progress.visibility = if (s.running) View.VISIBLE else View.GONE
        progress.progress = (s.progress * 1000).toInt()
        tvStatus.text = when {
            s.running -> "${s.stage}  ${(s.progress * 100).toInt()}%\nYou can leave the app; it keeps working in the background."
            s.error != null -> "Failed: ${s.error}"
            else -> s.stage
        }
        if (!s.running && s.doneId != null && s.doneId != JobState.shownDoneId) {
            JobState.shownDoneId = s.doneId
            refreshList()
            openPlayer(s.doneId)
        }
    }

    private fun openPlayer(id: String) {
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", id))
    }

    private fun refreshList() {
        list.removeAllViews()
        val projects = Projects.list(this)
        if (projects.isEmpty()) {
            list.addView(TextView(this).apply { text = "Nothing yet."; setPadding(0, 16, 0, 16) })
            return
        }
        val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        for (p in projects) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 24, 0, 8)
            }
            box.addView(TextView(this).apply {
                text = p.name
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            box.addView(TextView(this).apply {
                text = "${Projects.langLabel(p.srcLang)} → ${Projects.langLabel(p.outLang)} · ${df.format(Date(p.created))}"
            })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(MaterialButton(this).apply {
                text = "Play"
                setOnClickListener { openPlayer(p.id) }
            })
            row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "Save .srt"
                setOnClickListener {
                    exportTarget = p
                    exportSrt.launch(p.name.substringBeforeLast('.') + ".srt")
                }
            })
            row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = "Report"
                setOnClickListener { Feedback.show(this@MainActivity, p, title = "Report a problem with this video") }
            })
            row.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = "Delete"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("Delete these subtitles?")
                        .setPositiveButton("Delete") { _, _ -> Projects.delete(p); refreshList() }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            })
            box.addView(row)
            list.addView(box)
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "Video"
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: "Video"
    }
}
