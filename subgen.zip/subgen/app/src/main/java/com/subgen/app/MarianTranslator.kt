package com.subgen.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.Closeable
import java.io.File
import java.nio.LongBuffer
import java.text.Normalizer
import java.util.Properties
import kotlin.math.min

/**
 * Offline English -> Simplified Chinese translation with the OPUS-MT (Marian) model on ONNX Runtime.
 * Includes a small SentencePiece (unigram) tokenizer.
 */
class MarianTranslator(dir: File, threads: Int = 4) : Closeable {
    private val env = OrtEnvironment.getEnvironment()
    private val opts = OrtSession.SessionOptions().apply {
        setIntraOpNumThreads(threads)
        setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
    }
    private val enc = env.createSession(File(dir, "encoder.onnx").absolutePath, opts)
    private val dec = env.createSession(File(dir, "decoder.onnx").absolutePath, opts)

    private val pieceScore = HashMap<String, Float>(80000)
    private var maxPieceLen = 1
    private var unkScore = -100f
    private val srcVocab = HashMap<String, Long>(80000)
    private val tgtVocab = HashMap<Long, String>(80000)
    private val padId: Long
    private val eosId: Long
    private val unkId: Long
    private val startId: Long
    private val langId: Long

    init {
        var minScore = 0f
        File(dir, "src_pieces.tsv").forEachLine { line ->
            val i = line.lastIndexOf('\t')
            if (i > 0) {
                val p = line.substring(0, i)
                val s = line.substring(i + 1).toFloatOrNull() ?: return@forEachLine
                pieceScore[p] = s
                if (p.length > maxPieceLen) maxPieceLen = p.length
                if (s < minScore) minScore = s
            }
        }
        unkScore = minScore - 10f
        File(dir, "src_vocab.tsv").forEachLine { line ->
            val i = line.lastIndexOf('\t')
            if (i > 0) srcVocab[line.substring(0, i)] = line.substring(i + 1).toLong()
        }
        File(dir, "tgt_vocab.tsv").forEachLine { line ->
            val i = line.lastIndexOf('\t')
            if (i > 0) tgtVocab[line.substring(i + 1).toLong()] = line.substring(0, i)
        }
        val meta = Properties()
        File(dir, "meta.properties").inputStream().use { meta.load(it) }
        padId = meta.getProperty("pad").toLong()
        eosId = meta.getProperty("eos").toLong()
        unkId = meta.getProperty("unk").toLong()
        startId = meta.getProperty("start").toLong()
        langId = meta.getProperty("lang", "-1").toLong()
    }

    private fun encodePieces(text: String): List<String> {
        val norm = Normalizer.normalize(text, Normalizer.Form.NFKC).trim().replace(Regex("\\s+"), " ")
        if (norm.isEmpty()) return emptyList()
        val s = "▁" + norm.replace(' ', '▁')
        val n = s.length
        val best = DoubleArray(n + 1) { Double.NEGATIVE_INFINITY }
        val back = IntArray(n + 1)
        best[0] = 0.0
        for (i in 0 until n) {
            if (best[i] == Double.NEGATIVE_INFINITY) continue
            val lim = min(maxPieceLen, n - i)
            for (l in 1..lim) {
                val sc = pieceScore[s.substring(i, i + l)] ?: continue
                val v = best[i] + sc
                if (v > best[i + l]) { best[i + l] = v; back[i + l] = i }
            }
            val v = best[i] + unkScore
            if (v > best[i + 1]) { best[i + 1] = v; back[i + 1] = i }
        }
        val out = ArrayList<String>()
        var j = n
        while (j > 0) {
            val i = back[j]
            out.add(s.substring(i, j))
            j = i
        }
        out.reverse()
        return out
    }

    fun translate(text: String): String {
        val pieces = encodePieces(text)
        if (pieces.isEmpty()) return text
        val ids = ArrayList<Long>()
        if (langId >= 0) ids.add(langId)
        for (p in pieces) ids.add(srcVocab[p] ?: unkId)
        while (ids.size > 255) ids.removeAt(ids.size - 1)
        ids.add(eosId)
        val n = ids.size
        val inIds = ids.toLongArray()
        val mask = LongArray(n) { 1L }
        val shape = longArrayOf(1, n.toLong())

        val outIds = ArrayList<Long>()
        OnnxTensor.createTensor(env, LongBuffer.wrap(inIds), shape).use { tIds ->
            OnnxTensor.createTensor(env, LongBuffer.wrap(mask), shape).use { tMask ->
                enc.run(mapOf("input_ids" to tIds, "attention_mask" to tMask)).use { er ->
                    val hidden = er.get(0) as OnnxTensor
                    val dIds = ArrayList<Long>()
                    dIds.add(startId)
                    val maxSteps = min(256, n * 3 + 10)
                    for (step in 0 until maxSteps) {
                        val dArr = dIds.toLongArray()
                        val next = OnnxTensor.createTensor(env, LongBuffer.wrap(dArr), longArrayOf(1, dArr.size.toLong())).use { tDec ->
                            val inputs = HashMap<String, OnnxTensor>()
                            for (name in dec.inputNames) {
                                when (name) {
                                    "input_ids" -> inputs[name] = tDec
                                    "encoder_hidden_states" -> inputs[name] = hidden
                                    "encoder_attention_mask" -> inputs[name] = tMask
                                }
                            }
                            dec.run(inputs).use { dr ->
                                val logits = dr.get(0) as OnnxTensor
                                val shp = logits.info.shape
                                val v = shp[2].toInt()
                                val fb = logits.floatBuffer
                                val base = (dArr.size - 1) * v
                                var bi = 0
                                var bv = Float.NEGATIVE_INFINITY
                                for (k in 0 until v) {
                                    if (k.toLong() == padId) continue
                                    val x = fb.get(base + k)
                                    if (x > bv) { bv = x; bi = k }
                                }
                                bi.toLong()
                            }
                        }
                        if (next == eosId) break
                        dIds.add(next)
                        outIds.add(next)
                        val m = outIds.size
                        if (m >= 4 && outIds[m - 1] == outIds[m - 2] && outIds[m - 2] == outIds[m - 3] && outIds[m - 3] == outIds[m - 4]) break
                    }
                }
            }
        }
        val sb = StringBuilder()
        for (id in outIds) {
            if (id == padId || id == eosId || id == unkId) continue
            sb.append(tgtVocab[id] ?: "")
        }
        var out = sb.toString().replace('▁', ' ').trim()
        // Remove spaces between Chinese characters / punctuation.
        out = out.replace(Regex("(?<=[\\p{IsHan}，。！？、：；“”])\\s+(?=[\\p{IsHan}，。！？、：；“”])"), "")
        return out.ifBlank { text }
    }

    override fun close() {
        try { enc.close() } catch (_: Exception) {}
        try { dec.close() } catch (_: Exception) {}
        try { opts.close() } catch (_: Exception) {}
    }
}
