package com.subgen.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.io.Closeable
import java.io.File
import java.nio.LongBuffer
import java.text.Normalizer
import java.util.Properties
import kotlin.math.min

/**
 * Offline English -> Simplified Chinese translation with the OPUS-MT (Marian) model on ONNX Runtime.
 * Includes a small SentencePiece (unigram) tokenizer.
 */
class MarianTranslator(dir: File, threads: Int = 4) : Closeable {
    private val env = OrtEnvironment.getEnvironment()
    private val opts = OrtSession.SessionOptions().apply {
        setIntraOpNumThreads(threads)
        setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
    }
    private val enc = env.createSession(File(dir, "encoder.onnx").absolutePath, opts)
    private val dec = env.createSession(File(dir, "decoder.onnx").absolutePath, opts)
    /** Optional decoder that reuses earlier steps' work (much faster). Null if missing/unsupported. */
    private var decPast: OrtSession? = try {
        val f = File(dir, "decoder_past.onnx")
        if (f.exists()) env.createSession(f.absolutePath, opts) else null
    } catch (_: Throwable) { null }
    /** Set if the fast path failed once; we then stay on the plain path. */
    var fastPathError: String? = null
        private set

    private val pieceScore = HashMap<String, Float>(80000)
    private var maxPieceLen = 1
    private var unkScore = -100f
    private val srcVocab = HashMap<String, Long>(80000)
    private val tgtVocab = HashMap<Long, String>(80000)
    private val padId: Long
    private val eosId: Long
    private val unkId: Long
    private val startId: Long
    private val langId: Long
    private val encIds: String
    private val encMask: String?
    private val decIds: String
    private val decHidden: String
    private val decMask: String?

    /** Finds a model input by flexible name matching, so small naming differences don't break it. */
    private fun pick(names: Set<String>, vararg keys: String, exclude: String? = null): String? =
        keys.firstNotNullOfOrNull { k -> names.firstOrNull { it == k } }
            ?: keys.firstNotNullOfOrNull { k -> names.firstOrNull { it.contains(k) && (exclude == null || !it.contains(exclude)) } }

    init {
        val en = enc.inputNames
        val dn = dec.inputNames
        encIds = pick(en, "input_ids") ?: throw IllegalStateException("translator encoder inputs: $en")
        encMask = pick(en, "attention_mask")
        decIds = pick(dn, "input_ids", exclude = "encoder") ?: throw IllegalStateException("translator decoder inputs: $dn")
        decHidden = pick(dn, "encoder_hidden_states", "hidden") ?: throw IllegalStateException("translator decoder inputs: $dn")
        decMask = pick(dn, "encoder_attention_mask", "attention_mask", exclude = "decoder")
        if (dn.any { it.startsWith("past_key_values") || it == "use_cache_branch" })
            throw IllegalStateException("unsupported translator decoder (needs cache inputs): $dn")
        var minScore = 0f
        File(dir, "src_pieces.tsv").forEachLine { line ->
            val i = line.lastIndexOf('\t')
            if (i > 0) {
                val p = line.substring(0, i)
                val s = line.substring(i + 1).toFloatOrNull() ?: return@forEachLine
                pieceScore[p] = s
                if (p.length > maxPieceLen) maxPieceLen = p.length
                if (s < minScore) minScore = s
            }
        }
        unkScore = minScore - 10f
        File(dir, "src_vocab.tsv").forEachLine { line ->
            val i = line.lastIndexOf('\t')
            if (i > 0) srcVocab[line.substring(0, i)] = line.substring(i + 1).toLong()
        }
        File(dir, "tgt_vocab.tsv").forEachLine { line ->
            val i = line.lastIndexOf('\t')
            if (i > 0) tgtVocab[line.substring(i + 1).toLong()] = line.substring(0, i)
        }
        val meta = Properties()
        File(dir, "meta.properties").inputStream().use { meta.load(it) }
        padId = meta.getProperty("pad").toLong()
        eosId = meta.getProperty("eos").toLong()
        unkId = meta.getProperty("unk").toLong()
        startId = meta.getProperty("start").toLong()
        langId = meta.getProperty("lang", "-1").toLong()
    }

    private fun encodePieces(text: String): List<String> {
        val norm = Normalizer.normalize(text, Normalizer.Form.NFKC).trim().replace(Regex("\\s+"), " ")
        if (norm.isEmpty()) return emptyList()
        val s = "▁" + norm.replace(' ', '▁')
        val n = s.length
        val best = DoubleArray(n + 1) { Double.NEGATIVE_INFINITY }
        val back = IntArray(n + 1)
        best[0] = 0.0
        for (i in 0 until n) {
            if (best[i] == Double.NEGATIVE_INFINITY) continue
            val lim = min(maxPieceLen, n - i)
            for (l in 1..lim) {
                val sc = pieceScore[s.substring(i, i + l)] ?: continue
                val v = best[i] + sc
                if (v > best[i + l]) { best[i + l] = v; back[i + l] = i }
            }
            val v = best[i] + unkScore
            if (v > best[i + 1]) { best[i + 1] = v; back[i + 1] = i }
        }
        val out = ArrayList<String>()
        var j = n
        while (j > 0) {
            val i = back[j]
            out.add(s.substring(i, j))
            j = i
        }
        out.reverse()
        return out
    }

    fun translate(text: String): String {
        val pieces = encodePieces(text)
        if (pieces.isEmpty()) return text
        val ids = ArrayList<Long>()
        if (langId >= 0) ids.add(langId)
        for (p in pieces) ids.add(srcVocab[p] ?: unkId)
        while (ids.size > 255) ids.removeAt(ids.size - 1)
        ids.add(eosId)
        val n = ids.size
        val inIds = ids.toLongArray()
        val mask = LongArray(n) { 1L }
        val shape = longArrayOf(1, n.toLong())

        var outIds: List<Long> = emptyList()
        OnnxTensor.createTensor(env, LongBuffer.wrap(inIds), shape).use { tIds ->
            OnnxTensor.createTensor(env, LongBuffer.wrap(mask), shape).use { tMask ->
                val encIn = HashMap<String, OnnxTensor>()
                encIn[encIds] = tIds
                if (encMask != null) encIn[encMask] = tMask
                enc.run(encIn).use { er ->
                    val hidden = er.get(0) as OnnxTensor
                    val maxSteps = min(256, n * 3 + 10)
                    val fast = decPast
                    if (fast != null && fastPathError == null) {
                        try {
                            outIds = greedyCached(fast, hidden, tMask, maxSteps)
                        } catch (e: Throwable) {
                            fastPathError = e.toString()
                            try { fast.close() } catch (_: Throwable) {}
                            decPast = null
                        }
                    }
                    if (fastPathError != null || fast == null) outIds = greedyPlain(hidden, tMask, maxSteps)
                }
            }
        }
        val sb = StringBuilder()
        for (id in outIds) {
            if (id == padId || id == eosId || id == unkId) continue
            sb.append(tgtVocab[id] ?: "")
        }
        var out = sb.toString().replace('▁', ' ').trim()
        // Remove spaces between Chinese characters / punctuation.
        out = out.replace(Regex("(?<=[\\p{IsHan}，。！？、：；“”])\\s+(?=[\\p{IsHan}，。！？、：；“”])"), "")
        return CueBuilder.collapseRepeats(out).ifBlank { text }
    }

    /**
     * Picks the most likely next token, but never one that would repeat a 3-token sequence already
     * produced (the standard "no repeat n-gram" rule; stops the translator from looping).
     */
    private fun argmaxLast(logits: OnnxTensor, rows: Int, out: List<Long> = emptyList()): Long {
        val v = logits.info.shape[2].toInt()
        val fb = logits.floatBuffer
        val base = (rows - 1) * v
        val banned = HashSet<Long>()
        val m = out.size
        if (m >= 2) {
            val a = out[m - 2]; val b = out[m - 1]
            for (i in 0 until m - 2) if (out[i] == a && out[i + 1] == b) banned.add(out[i + 2])
        }
        var bi = eosId.toInt()
        var bv = Float.NEGATIVE_INFINITY
        for (k in 0 until v) {
            if (k.toLong() == padId || k.toLong() in banned) continue
            val x = fb.get(base + k)
            if (x > bv) { bv = x; bi = k }
        }
        return bi.toLong()
    }

    private fun repeating(out: List<Long>): Boolean {
        val m = out.size
        return m >= 4 && out[m - 1] == out[m - 2] && out[m - 2] == out[m - 3] && out[m - 3] == out[m - 4]
    }

    /** Plain greedy decoding: re-runs the decoder over the whole prefix each step. */
    private fun greedyPlain(hidden: OnnxTensor, tMask: OnnxTensor, maxSteps: Int): List<Long> {
        val outIds = ArrayList<Long>()
        val dIds = arrayListOf(startId)
        for (step in 0 until maxSteps) {
            val dArr = dIds.toLongArray()
            val next = OnnxTensor.createTensor(env, LongBuffer.wrap(dArr), longArrayOf(1, dArr.size.toLong())).use { tDec ->
                val inputs = HashMap<String, OnnxTensor>()
                inputs[decIds] = tDec
                inputs[decHidden] = hidden
                if (decMask != null) inputs[decMask] = tMask
                dec.run(inputs).use { dr -> argmaxLast(dr.get(0) as OnnxTensor, dArr.size, outIds) }
            }
            if (next == eosId) break
            dIds.add(next)
            outIds.add(next)
            if (repeating(outIds)) break
        }
        return outIds
    }

    /**
     * Cached greedy decoding: step 1 uses the plain decoder (which also returns its attention
     * cache, "present.*"); later steps feed only the newest token plus that cache
     * ("past_key_values.*") to the cached decoder.
     */
    private fun greedyCached(fast: OrtSession, hidden: OnnxTensor, tMask: OnnxTensor, maxSteps: Int): List<Long> {
        val outIds = ArrayList<Long>()
        val fastNames = fast.inputNames
        val fIds = pick(fastNames, "input_ids", exclude = "encoder") ?: throw IllegalStateException("fast inputs: $fastNames")
        val fMask = pick(fastNames, "encoder_attention_mask", "attention_mask", exclude = "decoder")
        val fHidden = fastNames.firstOrNull { it == "encoder_hidden_states" }
        val pastNames = fastNames.filter { it.startsWith("past_key_values") }
        if (pastNames.isEmpty()) throw IllegalStateException("fast decoder has no cache inputs: $fastNames")

        // step 1: plain decoder with the start token; keep its outputs (logits + present.*) open
        var first: OrtSession.Result? = null
        var prev: OrtSession.Result? = null
        try {
            val r0 = OnnxTensor.createTensor(env, LongBuffer.wrap(longArrayOf(startId)), longArrayOf(1, 1)).use { t ->
                val inputs = HashMap<String, OnnxTensor>()
                inputs[decIds] = t
                inputs[decHidden] = hidden
                if (decMask != null) inputs[decMask] = tMask
                dec.run(inputs)
            }
            first = r0
            val presentFirst = HashMap<String, OnnxTensor>()
            for (e in r0) if (e.key.startsWith("present")) presentFirst[e.key] = e.value as OnnxTensor
            if (presentFirst.isEmpty()) throw IllegalStateException("plain decoder returns no cache")
            var next = argmaxLast(r0.get(0) as OnnxTensor, 1)
            var decoderCache: Map<String, OnnxTensor> = presentFirst
            for (step in 1 until maxSteps) {
                if (next == eosId) break
                outIds.add(next)
                if (repeating(outIds)) break
                val r = OnnxTensor.createTensor(env, LongBuffer.wrap(longArrayOf(next)), longArrayOf(1, 1)).use { t ->
                    val inputs = HashMap<String, OnnxTensor>()
                    inputs[fIds] = t
                    if (fMask != null) inputs[fMask] = tMask
                    if (fHidden != null) inputs[fHidden] = hidden
                    for (pn in pastNames) {
                        val src = "present" + pn.removePrefix("past_key_values")
                        // encoder cache never changes: always from step 1; decoder cache: from last step
                        val tensor = if (pn.contains(".encoder.")) presentFirst[src] else (decoderCache[src] ?: presentFirst[src])
                        inputs[pn] = tensor ?: throw IllegalStateException("missing cache $src")
                    }
                    fast.run(inputs)
                }
                val newCache = HashMap<String, OnnxTensor>()
                for (e in r) if (e.key.startsWith("present")) newCache[e.key] = e.value as OnnxTensor
                next = argmaxLast(r.get(0) as OnnxTensor, 1, outIds)
                prev?.close()
                prev = r
                decoderCache = newCache
            }
        } finally {
            prev?.close()
            first?.close()
        }
        return outIds
    }

    override fun close() {
        try { decPast?.close() } catch (_: Exception) {}
        try { enc.close() } catch (_: Exception) {}
        try { dec.close() } catch (_: Exception) {}
        try { opts.close() } catch (_: Exception) {}
    }
}
