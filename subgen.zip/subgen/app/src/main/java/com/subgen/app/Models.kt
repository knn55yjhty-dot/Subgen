package com.subgen.app

import android.content.Context
import android.content.res.AssetManager
import java.io.File
import java.io.FileOutputStream

/** Copies the bundled models out of the APK once, so native code can open them as files. */
object Models {
    private const val VERSION = "1"

    fun dir(ctx: Context) = File(ctx.filesDir, "models")

    fun ready(ctx: Context) = File(dir(ctx), ".ok_$VERSION").exists()

    @Synchronized
    fun ensure(ctx: Context, report: (String) -> Unit) {
        val d = dir(ctx)
        val marker = File(d, ".ok_$VERSION")
        if (marker.exists()) return
        report("Unpacking models (first run only)…")
        d.deleteRecursively()
        d.mkdirs()
        copyTree(ctx.assets, "models", d)
        marker.writeText("ok")
    }

    private fun copyTree(am: AssetManager, path: String, dest: File) {
        val list = am.list(path) ?: emptyArray()
        if (list.isEmpty()) {
            am.open(path).use { inp ->
                FileOutputStream(dest).use { out -> inp.copyTo(out, 1 shl 20) }
            }
            return
        }
        dest.mkdirs()
        for (n in list) copyTree(am, "$path/$n", File(dest, n))
    }

    fun whisperFile(ctx: Context, accurate: Boolean) =
        File(dir(ctx), if (accurate) "ggml-small-q5_1.bin" else "ggml-base-q5_1.bin")

    fun mtDir(ctx: Context) = File(dir(ctx), "mt")
}
