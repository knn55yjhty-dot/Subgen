package com.subgen.app

import android.content.Context
import android.icu.text.Transliterator
import android.net.Uri
import java.io.File
import kotlin.math.max
import kotlin.math.min

data class JobRequest(
    val uri: Uri,
    val name: String,
    val srcLang: String,   // auto, en, zh, ko, ja
    val target: String,    // orig, en, zh
    val accurate: Boolean
)

class Pipeline(
    private val ctx: Context,
    private val req: JobRequest,
    private val report: (String, Float) -> Unit
) {
    @Volatile private var cancelled = false

    fun cancel() {
        cancelled = true
        WhisperLib.nSetAbort(true)
    }

    private fun check() {
        if (cancelled) throw CancelledException()
    }

    fun run(): String {
        WhisperLib.nSetAbort(false)
        report("Preparing models…", 0f)
        Models.ensure(ctx) { report(it, 0f) }
        check()

        val pcm = tempAudio(ctx)
        report("Extracting audio…", 0f)
        val total = AudioDecoder.decode(ctx, req.uri, pcm, { cancelled }) { p ->
            report("Extracting audio…", 0.08f * p)
        }
        if (total < SR) throw IllegalStateException("The audio is too short.")
        val pcmFile = PcmFile(pcm, total)
        val db = pcmFile.frameDb()
        val thr = Timing.threshold(db)
        val energy = Energy(db, thr)
        val chunks = Timing.planSpeechChunks(db, energy)
        if (chunks.isEmpty()) throw IllegalStateException("No speech was found in this video.")
        val threads = max(2, min(4, Runtime.getRuntime().availableProcessors()))
        check()

        report("Loading speech model…", 0.09f)
        val wctx = WhisperLib.nInit(Models.whisperFile(ctx, req.accurate).absolutePath, if (req.accurate) 1 else 0)
        if (wctx == 0L) throw IllegalStateException("Could not load the speech model.")

        val cues = mutableListOf<Cue>()
        var src = req.srcLang
        var needMt = false
        try {
            if (src == "auto") {
                report("Detecting language…", 0.1f)
                val first = chunks[0].pieces[0].first
                val from = first.toLong() * FRAME
                val samples = pcmFile.read(from, from + 30L * SR)
                Leveler.apply(samples, thr)
                src = WhisperLib.nDetectLang(wctx, samples, threads)
            }
            val (lang, translate) = decide(src, req.target)
            needMt = req.target == "zh" && src != "zh"
            val prompt = if (lang == "zh" && !translate) "以下是普通话的句子，使用简体中文。" else null

            val totalFrames = chunks.sumOf { it.frames }.coerceAtLeast(1)
            var doneFrames = 0
            for ((ci, ch) in chunks.withIndex()) {
                check()
                // Join the speech pieces with 0.3 s of silence and remember where each came from.
                val map = TimeMap()
                val gap = FloatArray(SR * 3 / 10)
                val parts = ArrayList<FloatArray>()
                var pos = 0.0
                for (r in ch.pieces) {
                    val s = pcmFile.read(r.first.toLong() * FRAME, (r.last + 1).toLong() * FRAME)
                    map.add(pos, r.first / 100.0, s.size / SR.toDouble())
                    parts.add(s); parts.add(gap)
                    pos += s.size / SR.toDouble() + 0.3
                }
                val samples = FloatArray(parts.sumOf { it.size })
                var o = 0
                for (a in parts) { a.copyInto(samples, o); o += a.size }
                Leveler.apply(samples, thr) // lift quiet / background speech

                val base = 0.1f + 0.8f * doneFrames / totalFrames
                val span = 0.8f * ch.frames / totalFrames
                doneFrames += ch.frames
                val label = if (translate) "Transcribing + translating" else "Transcribing"
                val part = if (chunks.size > 1) " (part ${ci + 1}/${chunks.size})" else ""
                report("$label…$part", base)
                val bytes = WhisperLib.nTranscribe(wctx, samples, lang, translate, threads, prompt,
                    object : ProgressCb {
                        override fun onProgress(p: Int) {
                            report("$label…$part", base + span * p / 100f)
                        }
                    })
                check()
                if (bytes == null) throw IllegalStateException("Transcription failed.")
                val segs = CueBuilder.parse(bytes)
                // Lines that will go through the Chinese translator stay as whole sentences for now.
                val local = when {
                    needMt -> CueBuilder.segmentCues(segs, 0.0, split = false)
                    translate -> CueBuilder.segmentCues(segs, 0.0)
                    else -> CueBuilder.wordCues(segs, 0.0)
                }
                for (c in local) {
                    c.start = map.map(c.start)
                    c.end = max(map.map(c.end), c.start + 0.2)
                }
                cues += local
            }
        } finally {
            WhisperLib.nFree(wctx)
        }
        check()

        if (needMt) {
            // Translate whole sentences, then split the Chinese into readable lines.
            report("Translating to Chinese…", 0.9f)
            val split = mutableListOf<Cue>()
            // don't spend time translating lines that will be dropped as silence anyway
            val toTranslate = cues.filter { energy.speechRatio(it.start, it.end) >= 0.03 }
            MarianTranslator(Models.mtDir(ctx), threads).use { tr ->
                for ((i, c) in toTranslate.withIndex()) {
                    check()
                    if (!CueBuilder.isAnnotation(c.text)) c.text = tr.translate(c.text)
                    split += CueBuilder.splitCue(c)
                    report("Translating to Chinese…", 0.9f + 0.09f * i / toTranslate.size.coerceAtLeast(1))
                }
            }
            cues.clear()
            cues += split
        }

        val result = Timing.finalize(cues, energy)
        if (result.isEmpty()) throw IllegalStateException("No speech was found in this video.")
        if (req.target == "zh" || (req.target == "orig" && src == "zh")) {
            // Some phones ship without this conversion table; if so, keep the text as it is
            // (Whisper is already prompted to write Simplified Chinese).
            val t = try { Transliterator.getInstance("Traditional-Simplified") } catch (e: Exception) { null }
            if (t != null) for (c in result) c.text = t.transliterate(c.text)
        }

        pcm.delete()
        report("Saving…", 1f)
        val outLang = when (req.target) { "en" -> "en"; "zh" -> "zh"; else -> src }
        return Projects.create(ctx, req, src, outLang, result)
    }

    companion object {
        fun tempAudio(ctx: Context) = File(ctx.cacheDir, "audio.pcm")
    }

    private fun decide(src: String, target: String): Pair<String, Boolean> = when (target) {
        "en" -> if (src == "en") "en" to false else src to true
        "zh" -> when (src) {
            "zh" -> "zh" to false
            "en" -> "en" to false
            else -> src to true // ja/ko -> English (Whisper) -> Chinese (OPUS-MT)
        }
        else -> src to false
    }
}
