package com.subgen.app

import android.content.Context
import android.icu.text.Transliterator
import android.net.Uri
import java.io.File
import kotlin.math.max
import kotlin.math.min

data class JobRequest(
    val uri: Uri,
    val name: String,
    val srcLang: String,   // auto, en, zh, ko, ja
    val target: String,    // orig, en, zh
    val accurate: Boolean
)

class Pipeline(
    private val ctx: Context,
    private val req: JobRequest,
    private val report: (String, Float, Double?) -> Unit
) {
    @Volatile private var cancelled = false

    /** A message for the user about something that went partly wrong (shown after the job). */
    var notice: String? = null

    fun cancel() {
        cancelled = true
        WhisperLib.nSetAbort(true)
    }

    private fun check() {
        if (cancelled) throw CancelledException()
    }

    // ---- time estimate ----
    private val speedPrefs = ctx.getSharedPreferences("speed", Context.MODE_PRIVATE)
    private val txKey get() = if (req.accurate) "tx_small" else "tx_base"
    /** seconds of processing per second of speech (learned from earlier runs on this phone) */
    private val txFactor: Double get() = speedPrefs.getFloat(txKey, if (req.accurate) 1.0f else 0.35f).toDouble()
    /** seconds per translated sentence */
    private val mtPerSentence: Double get() = speedPrefs.getFloat("mt_sentence", 1.2f).toDouble()
    private fun mtLikely(src: String) = req.target == "zh" && src != "zh"
    // translation runs alongside transcription, so the slower of the two decides (+ a little tail)
    private fun laterEstimate(speechSec: Double, src: String): Double =
        if (mtLikely(src)) max(speechSec * txFactor, speechSec / 4.0 * mtPerSentence) + 30.0
        else speechSec * txFactor

    private fun learn(key: String, value: Double) {
        if (value.isNaN() || value <= 0) return
        val old = speedPrefs.getFloat(key, value.toFloat())
        // blend with earlier runs so one odd video doesn't throw the estimate off
        speedPrefs.edit().putFloat(key, (old * 0.4f + value.toFloat() * 0.6f)).apply()
    }

    /**
     * One-time speed test per model: times the speech model with 4, 6 and 8 threads on a
     * piece of this video and remembers the fastest for this phone.
     */
    private fun tuneThreads(wctx: Long, pcm: PcmFile, chunks: List<Chunk>): Int {
        val key = "threads_" + (if (req.accurate) "small" else "base")
        val known = speedPrefs.getInt(key, 0)
        if (known > 0) return known
        val cores = Runtime.getRuntime().availableProcessors()
        val candidates = listOf(4, 6, 8).filter { it <= cores }.ifEmpty { listOf(max(1, cores)) }
        if (candidates.size == 1) return candidates[0]
        report("Testing this phone's speed (one-time)…", 0.095f, null)
        val first = chunks[0].pieces[0].first.toLong() * FRAME
        val sample = pcm.read(first, first + 10L * SR)
        val ms = WhisperLib.nBenchEncode(wctx, sample, candidates.toIntArray())
        Diag.info(ctx, "speed test: " + candidates.indices.joinToString { "${candidates[it]} threads ${ms[it]} ms" })
        val best = candidates.indices.filter { ms[it] > 0 }.minByOrNull { ms[it] }?.let { candidates[it] } ?: 4
        speedPrefs.edit().putInt(key, best).apply()
        return best
    }

    fun run(): String {
        WhisperLib.nSetAbort(false)
        report("Preparing models…", 0f, null)
        Models.ensure(ctx) { report(it, 0f, null) }
        check()

        val pcm = tempAudio(ctx)
        report("Extracting audio…", 0f, null)
        val tDec = System.currentTimeMillis()
        val total = AudioDecoder.decode(ctx, req.uri, pcm, { cancelled }, { Diag.info(ctx, it) }) { p, posUs, durUs ->
            val text = if (durUs > 0) "${AudioDecoder.fmtTime(posUs)} of ${AudioDecoder.fmtTime(durUs)}"
                       else "${AudioDecoder.fmtTime(posUs)} done"
            val el = (System.currentTimeMillis() - tDec) / 1000.0
            val eta = if (p > 0.02f && durUs > 0) {
                el * (1 - p) / p + laterEstimate(durUs / 1e6 * 0.75, req.srcLang)   // assume ~75% of a video is speech
            } else null
            report("Extracting audio… $text", if (p >= 0) 0.08f * p else 0f, eta)
        }
        if (total < SR) throw IllegalStateException("The audio is too short.")
        Diag.info(ctx, "audio decoded: %.1f s".format(total / SR.toDouble()))
        val pcmFile = PcmFile(pcm, total)
        val db = pcmFile.frameDb()
        val thr = Timing.threshold(db)
        val energy = Energy(db, thr)
        val chunks = Timing.planSpeechChunks(db, energy)
        val speechSec = chunks.sumOf { it.frames } / 100.0
        Diag.info(ctx, "speech threshold %.1f dBFS; speech found %.1f s in %d part(s), %d batch(es)".format(
            thr, speechSec, chunks.sumOf { it.pieces.size }, chunks.size))
        if (chunks.isEmpty()) throw IllegalStateException("No speech was found in this video.")
        check()

        Diag.info(ctx, "audio extraction took %.0f s".format((System.currentTimeMillis() - tDec) / 1000.0))
        report("Loading speech model…", 0.09f, laterEstimate(speechSec, req.srcLang))
        val wctx = WhisperLib.nInit(Models.whisperFile(ctx, req.accurate).absolutePath, if (req.accurate) 1 else 0)
        if (wctx == 0L) throw IllegalStateException("Could not load the speech model.")
        val threads = try { tuneThreads(wctx, pcmFile, chunks) } catch (e: Throwable) {
            Diag.info(ctx, "thread speed test failed ($e); using 4"); 4
        }
        check()
        Diag.info(ctx, "model ${if (req.accurate) "small" else "base"} loaded, $threads threads")

        val cues = mutableListOf<Cue>()
        var src = req.srcLang
        var needMt = false
        var bg: BgTranslator? = null
        try {
            if (src == "auto") {
                report("Detecting language…", 0.1f, laterEstimate(speechSec, req.srcLang))
                val first = chunks[0].pieces[0].first
                val from = first.toLong() * FRAME
                val samples = pcmFile.read(from, from + 30L * SR)
                Leveler.apply(samples, thr)
                src = WhisperLib.nDetectLang(wctx, samples, threads)
                Diag.info(ctx, "detected language: $src")
            }
            val (lang, translate) = decide(src, req.target)
            needMt = req.target == "zh" && src != "zh"
            Diag.info(ctx, "plan: whisper lang=$lang translate=$translate chineseMT=$needMt")
            val prompt = if (lang == "zh" && !translate) "以下是普通话的句子，使用简体中文。" else null
            // Chinese translation runs alongside transcription, on 2 threads so it doesn't starve the speech model.
            if (needMt) bg = BgTranslator(Models.mtDir(ctx), 2, { cancelled }) { Diag.info(ctx, it) }
            // Leave 2 cores for the translator so the two don't fight over the processor.
            val cores = Runtime.getRuntime().availableProcessors()
            val txThreads = if (needMt) min(threads, max(2, cores - 2)) else threads
            if (txThreads != threads) Diag.info(ctx, "using $txThreads threads for transcription (2 cores left for translation)")

            val totalFrames = chunks.sumOf { it.frames }.coerceAtLeast(1)
            var doneFrames = 0
            val tTx = System.currentTimeMillis()
            fun txEta(processedSec: Double): Double {
                val el = (System.currentTimeMillis() - tTx) / 1000.0
                val f = if (processedSec > 15 && el > 10) el / processedSec else txFactor
                val txLeft = (speechSec - processedSec).coerceAtLeast(0.0) * f
                val b = bg ?: return txLeft
                // translation runs in parallel: whichever finishes last decides
                val per = b.secPerSentence() ?: mtPerSentence
                val expected = b.submitted + (speechSec - processedSec).coerceAtLeast(0.0) / 4.0
                return max(txLeft + per * 3, (expected - b.done) * per)
            }
            for ((ci, ch) in chunks.withIndex()) {
                check()
                // Join the speech pieces with 0.3 s of silence and remember where each came from.
                val map = TimeMap()
                val gap = FloatArray(SR * 3 / 10)
                val parts = ArrayList<FloatArray>()
                var pos = 0.0
                for (r in ch.pieces) {
                    val s = pcmFile.read(r.first.toLong() * FRAME, (r.last + 1).toLong() * FRAME)
                    map.add(pos, r.first / 100.0, s.size / SR.toDouble())
                    parts.add(s); parts.add(gap)
                    pos += s.size / SR.toDouble() + 0.3
                }
                val samples = FloatArray(parts.sumOf { it.size })
                var o = 0
                for (a in parts) { a.copyInto(samples, o); o += a.size }
                Leveler.apply(samples, thr) // lift quiet / background speech

                val base = 0.1f + 0.8f * doneFrames / totalFrames
                val span = 0.8f * ch.frames / totalFrames
                val doneBefore = doneFrames / 100.0
                val chSec = ch.frames / 100.0
                doneFrames += ch.frames
                val label = if (translate) "Transcribing + translating" else "Transcribing"
                val part = if (chunks.size > 1) " (part ${ci + 1}/${chunks.size})" else ""
                report("$label…$part", base, txEta(doneBefore))
                val t0 = System.currentTimeMillis()
                val bytes = WhisperLib.nTranscribe(wctx, samples, lang, translate, txThreads, prompt,
                    object : ProgressCb {
                        override fun onProgress(p: Int) {
                            report("$label…$part", base + span * p / 100f, txEta(doneBefore + chSec * p / 100.0))
                        }
                    })
                check()
                if (bytes == null) throw IllegalStateException("Transcription failed.")
                val segs = CueBuilder.parse(bytes)
                val secs = (System.currentTimeMillis() - t0) / 1000.0
                Diag.info(ctx, "batch ${ci + 1}/${chunks.size}: %.0f s audio in %.0f s (%.2fx), %d segments".format(
                    samples.size / SR.toDouble(), secs, samples.size / SR.toDouble() / secs.coerceAtLeast(0.01), segs.size))
                // Lines that will go through the Chinese translator stay as whole sentences for now.
                val local = when {
                    needMt -> CueBuilder.segmentCues(segs, 0.0, split = false)
                    translate -> CueBuilder.segmentCues(segs, 0.0)
                    else -> CueBuilder.wordCues(segs, 0.0)
                }
                for (c in local) {
                    c.start = map.map(c.start)
                    c.end = max(map.map(c.end), c.start + 0.2)
                }
                val b = bg
                if (b != null) b.submit(local.filter { energy.speechRatio(it.start, it.end) >= 0.03 })
                else cues += local
            }
            val txSec = (System.currentTimeMillis() - tTx) / 1000.0
            Diag.info(ctx, "transcription took %.0f s for %.0f s of speech (%.2f s per s)".format(txSec, speechSec, txSec / speechSec.coerceAtLeast(1.0)))
            if (speechSec >= 60) learn(txKey, txSec / speechSec)
        } catch (e: Throwable) {
            bg?.close()
            throw e
        } finally {
            WhisperLib.nFree(wctx)
        }
        check()

        var mtFailed = false
        val b = bg
        if (b != null) {
            val tWait = System.currentTimeMillis()
            val lines = b.finish { done, total ->
                check()
                val per = b.secPerSentence() ?: mtPerSentence
                report("Finishing Chinese translation… $done of $total", 0.9f + 0.09f * done / total.coerceAtLeast(1),
                    (total - done) * per)
            }
            check()
            mtFailed = b.failed
            if (mtFailed) Diag.info(ctx, "translation failed; English lines kept")
            b.fastErr?.let { Diag.info(ctx, "fast translation path unavailable, used slower path: $it") }
            Diag.info(ctx, "translated ${b.done} sentence(s) -> ${lines.size} line(s); %.0f s busy, waited %.0f s after transcription"
                .format(b.busySec, (System.currentTimeMillis() - tWait) / 1000.0))
            if (!mtFailed && b.done >= 10) learn("mt_sentence", b.busySec / b.done)
            cues += lines
        }

        val result = Timing.finalize(cues, energy)
        Diag.info(ctx, "lines: ${cues.size} raw -> ${result.size} final")
        if (result.isEmpty()) throw IllegalStateException("No speech was found in this video.")
        if ((req.target == "zh" && !mtFailed) || (req.target == "orig" && src == "zh")) {
            // Some phones ship without this conversion table; if so, keep the text as it is
            // (Whisper is already prompted to write Simplified Chinese).
            val t = try { Transliterator.getInstance("Traditional-Simplified") } catch (e: Exception) { null }
            if (t != null) for (c in result) c.text = t.transliterate(c.text)
        }

        pcm.delete()
        report("Saving…", 1f, null)
        val outLang = when {
            req.target == "en" || mtFailed -> "en"
            req.target == "zh" -> "zh"
            else -> src
        }
        if (mtFailed) notice = "Chinese translation failed, so these subtitles were saved in English. Please send a report."
        return Projects.create(ctx, req, src, outLang, result)
    }

    companion object {
        fun tempAudio(ctx: Context) = File(ctx.cacheDir, "audio.pcm")
    }

    private fun decide(src: String, target: String): Pair<String, Boolean> = when (target) {
        "en" -> if (src == "en") "en" to false else src to true
        "zh" -> when (src) {
            "zh" -> "zh" to false
            "en" -> "en" to false
            else -> src to true // ja/ko -> English (Whisper) -> Chinese (OPUS-MT)
        }
        else -> src to false
    }
}
