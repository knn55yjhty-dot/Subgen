package com.subgen.app

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import java.io.File
import kotlin.math.abs

/**
 * Video player laid out like MX Player: the picture fills the screen, thin control bars fade in
 * at the top and bottom only, and hide by themselves after a few seconds of playback.
 */
@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var project: Project
    private lateinit var cues: List<Cue>
    private lateinit var playerView: PlayerView
    private lateinit var tvOffset: TextView
    private lateinit var tvCenter: TextView
    private lateinit var tvPos: TextView
    private lateinit var tvDur: TextView
    private lateinit var seek: SeekBar
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var timingPanel: View
    private lateinit var btnPlay: ImageButton
    private lateinit var btnUnlock: ImageButton
    private var savedPos = 0L
    private var offsetAtOpen = 0

    private val ui = Handler(Looper.getMainLooper())
    private var controlsShown = true
    private var locked = false
    private var userDragging = false
    private var userRotated = false
    private var resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT

    private val hideControls = Runnable { if (player?.isPlaying == true && !userDragging) setControls(false) }
    private val hideCenter = Runnable { tvCenter.visibility = View.GONE }
    private val hideUnlock = Runnable { btnUnlock.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() { updateProgress(); ui.postDelayed(this, 500) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        val id = intent.getStringExtra("id")
        val p = id?.let { Projects.load(this, it) }
        if (p == null) { finish(); return }
        project = p
        savedPos = intent.getLongExtra("startMs", 0L)
        Diag.installCrashHandler(this)
        cues = Srt.parse(project.srtFile.readText())
        offsetAtOpen = project.offsetMs

        playerView = findViewById(R.id.playerView)
        tvOffset = findViewById(R.id.tvOffset)
        tvCenter = findViewById(R.id.tvCenter)
        tvPos = findViewById(R.id.tvPos)
        tvDur = findViewById(R.id.tvDur)
        seek = findViewById(R.id.seek)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        timingPanel = findViewById(R.id.timingPanel)
        btnPlay = findViewById(R.id.btnPlay)
        btnUnlock = findViewById(R.id.btnUnlock)
        findViewById<TextView>(R.id.tvTitle).text = project.name

        playerView.subtitleView?.apply {
            setStyle(CaptionStyleCompat(Color.WHITE, 0x88000000.toInt(), Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null))
            setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * 1.15f)
        }

        findViewById<ImageButton>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btnReport).setOnClickListener { report() }
        findViewById<ImageButton>(R.id.btnTiming).setOnClickListener {
            timingPanel.visibility = if (timingPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            poke()
        }
        findViewById<Button>(R.id.btnM5).setOnClickListener { shift(-500) }
        findViewById<Button>(R.id.btnM1).setOnClickListener { shift(-100) }
        findViewById<Button>(R.id.btnP1).setOnClickListener { shift(100) }
        findViewById<Button>(R.id.btnP5).setOnClickListener { shift(500) }
        findViewById<Button>(R.id.btnReset).setOnClickListener { shift(-project.offsetMs) }
        btnPlay.setOnClickListener { togglePlay() }
        findViewById<ImageButton>(R.id.btnRew).setOnClickListener { seekBy(-10_000) }
        findViewById<ImageButton>(R.id.btnFwd).setOnClickListener { seekBy(10_000) }
        findViewById<ImageButton>(R.id.btnAspect).setOnClickListener { cycleAspect() }
        findViewById<ImageButton>(R.id.btnRotate).setOnClickListener { rotate() }
        findViewById<ImageButton>(R.id.btnLock).setOnClickListener { setLocked(true) }
        btnUnlock.setOnClickListener { setLocked(false) }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val d = duration()
                if (d > 0) {
                    val t = d * progress / 1000
                    tvPos.text = fmt(t)
                    showCenter("${fmt(t)} / ${fmt(d)}", 0)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { userDragging = true; ui.removeCallbacks(hideControls) }
            override fun onStopTrackingTouch(sb: SeekBar?) {
                userDragging = false
                val d = duration()
                if (d > 0) player?.seekTo(d * seek.progress / 1000)
                ui.postDelayed(hideCenter, 300)
                poke()
            }
        })

        setupGestures()
        updateOffsetLabel()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        // keep the bars clear of the camera notch / rounded corners / gesture area
        val padTop = topBar.paddingTop; val padBottom = bottomBar.paddingBottom
        val padL = topBar.paddingLeft; val padR = topBar.paddingRight
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { _, insets ->
            val cut = insets.getInsets(WindowInsetsCompat.Type.displayCutout())
            topBar.setPadding(padL + cut.left, padTop + cut.top, padR + cut.right, topBar.paddingBottom)
            bottomBar.setPadding(padL + cut.left, bottomBar.paddingTop, padR + cut.right, padBottom + cut.bottom)
            insets
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- controls ----------

    private fun setControls(show: Boolean) {
        controlsShown = show && !locked
        val v = if (controlsShown) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomBar.visibility = v
        if (!controlsShown) timingPanel.visibility = View.GONE
        if (controlsShown) poke()
        liftSubtitles()
    }

    /** Like MX Player: while the controls are showing, subtitles move up so the bar never hides them. */
    private fun liftSubtitles() {
        val sv = playerView.subtitleView ?: return
        if (!controlsShown) { sv.setBottomPaddingFraction(SubtitleView.DEFAULT_BOTTOM_PADDING_FRACTION); return }
        bottomBar.post {
            val h = playerView.height
            if (h > 0 && controlsShown) sv.setBottomPaddingFraction((bottomBar.height.toFloat() / h + 0.02f).coerceIn(0.08f, 0.6f))
        }
    }

    /** Restart the auto-hide timer (controls fade away 3.5 s after the last touch while playing). */
    private fun poke() {
        ui.removeCallbacks(hideControls)
        ui.postDelayed(hideControls, 3500)
    }

    private fun setLocked(on: Boolean) {
        locked = on
        if (on) {
            setControls(false)
            btnUnlock.visibility = View.VISIBLE
            ui.removeCallbacks(hideUnlock); ui.postDelayed(hideUnlock, 2500)
            Toast.makeText(this, "Screen locked. Tap, then tap the lock to unlock.", Toast.LENGTH_SHORT).show()
        } else {
            btnUnlock.visibility = View.GONE
            setControls(true)
        }
    }

    private fun togglePlay() {
        val pl = player ?: return
        if (pl.playbackState == Player.STATE_ENDED) pl.seekTo(0)
        pl.playWhenReady = !pl.playWhenReady
        poke()
    }

    private fun seekBy(deltaMs: Long) {
        val pl = player ?: return
        val d = duration()
        var t = pl.currentPosition + deltaMs
        if (t < 0) t = 0
        if (d > 0 && t > d) t = d
        pl.seekTo(t)
        showCenter((if (deltaMs >= 0) "+" else "−") + "${abs(deltaMs) / 1000}s   ${fmt(t)}", 700)
        updateProgress()
        if (controlsShown) poke()
    }

    private fun cycleAspect() {
        resizeMode = when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        playerView.resizeMode = resizeMode
        showCenter(when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Crop to fill"
            AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Stretch"
            else -> "Fit to screen"
        }, 900)
        poke()
    }

    private fun rotate() {
        userRotated = true
        val landscape = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                               else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        poke()
    }

    private fun duration(): Long {
        val d = player?.duration ?: C.TIME_UNSET
        return if (d == C.TIME_UNSET || d < 0) 0L else d
    }

    private fun updateProgress() {
        val pl = player ?: return
        val d = duration()
        if (!userDragging) {
            tvPos.text = fmt(pl.currentPosition)
            seek.progress = if (d > 0) (pl.currentPosition * 1000 / d).toInt() else 0
            seek.secondaryProgress = if (d > 0) (pl.bufferedPosition * 1000 / d).toInt() else 0
        }
        tvDur.text = fmt(d)
    }

    private fun showCenter(text: String, hideAfterMs: Long) {
        tvCenter.text = text
        tvCenter.visibility = View.VISIBLE
        ui.removeCallbacks(hideCenter)
        if (hideAfterMs > 0) ui.postDelayed(hideCenter, hideAfterMs)
    }

    // ---------- gestures ----------

    private enum class Drag { NONE, SEEK, VOLUME, BRIGHTNESS }

    private fun setupGestures() {
        val gestureView = findViewById<View>(R.id.gestures)
        val audio = getSystemService(AudioManager::class.java)
        val edge = 40 * resources.displayMetrics.density   // leave screen edges to the system's own swipes
        var drag = Drag.NONE
        var downX = 0f; var downY = 0f
        var startPos = 0L; var seekTarget = 0L
        var startVol = 0; var startBright = 0.5f

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    btnUnlock.visibility = View.VISIBLE
                    ui.removeCallbacks(hideUnlock); ui.postDelayed(hideUnlock, 2500)
                } else setControls(!controlsShown)
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = gestureView.width.toFloat()
                when {
                    e.x < w / 3 -> seekBy(-10_000)
                    e.x > w * 2 / 3 -> seekBy(10_000)
                    else -> togglePlay()
                }
                return true
            }
        })

        gestureView.setOnTouchListener { v, ev ->
            detector.onTouchEvent(ev)
            if (locked) return@setOnTouchListener true
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; drag = Drag.NONE
                    startPos = player?.currentPosition ?: 0L
                    startVol = audio?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                    val b = window.attributes.screenBrightness
                    startBright = (if (b < 0) currentSystemBrightness() else b).coerceIn(0.01f, 1f)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.x - downX; val dy = ev.y - downY
                    val slop = 24 * resources.displayMetrics.density
                    if (drag == Drag.NONE && (abs(dx) > slop || abs(dy) > slop) &&
                        downY > edge && downY < v.height - edge) {
                        drag = when {
                            abs(dx) > abs(dy) -> Drag.SEEK
                            downX < v.width / 2f -> Drag.BRIGHTNESS
                            else -> Drag.VOLUME
                        }
                    }
                    when (drag) {
                        Drag.SEEK -> {
                            // a full screen-width swipe = 2 minutes, like MX Player's fine seeking
                            val d = duration()
                            val delta = (dx / v.width * 120_000).toLong()
                            seekTarget = (startPos + delta).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                            val sign = if (seekTarget >= startPos) "+" else "−"
                            showCenter("${fmt(seekTarget)}\n[$sign${fmt(abs(seekTarget - startPos))}]", 0)
                        }
                        Drag.VOLUME -> if (audio != null) {
                            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            val vol = (startVol - dy / (v.height * 0.6f) * max).toInt().coerceIn(0, max)
                            // throws SecurityException on some phones in Do Not Disturb mode
                            try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0) } catch (_: Exception) {}
                            showCenter("Volume ${vol * 100 / maxOf(1, max)}%", 0)
                        }
                        Drag.BRIGHTNESS -> {
                            val b = (startBright - dy / (v.height * 0.6f)).coerceIn(0.01f, 1f)
                            window.attributes = window.attributes.apply { screenBrightness = b }
                            showCenter("Brightness ${(b * 100).toInt()}%", 0)
                        }
                        Drag.NONE -> {}
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (drag == Drag.SEEK && ev.actionMasked == MotionEvent.ACTION_UP) {
                        player?.seekTo(seekTarget); updateProgress()
                    }
                    if (drag != Drag.NONE) ui.postDelayed(hideCenter, 500)
                    drag = Drag.NONE
                }
            }
            true
        }
    }

    private fun currentSystemBrightness(): Float = try {
        android.provider.Settings.System.getInt(contentResolver, android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (_: Exception) { 0.5f }

    // ---------- subtitles / report ----------

    /** Report with the exact playback moment and the subtitle lines around it. */
    private fun report() {
        val pl = player
        pl?.playWhenReady = false
        val posSec = (pl?.currentPosition ?: 0L) / 1000.0
        val off = project.offsetMs / 1000.0
        val sb = StringBuilder("--- player ---\nPaused at %d:%05.2f (timing offset %+.1fs)\nLines around this moment:\n"
            .format((posSec / 60).toInt(), posSec % 60, off))
        val idx = cues.indexOfLast { it.start + off <= posSec }.coerceAtLeast(0)
        for (i in (idx - 3).coerceAtLeast(0)..(idx + 3).coerceAtMost(cues.size - 1)) {
            val c = cues[i]
            val mark = if (posSec >= c.start + off && posSec <= c.end + off) " <== on screen" else ""
            sb.append("  %.2f–%.2f  %s%s\n".format(c.start + off, c.end + off, c.text.replace("\n", " / "), mark))
        }
        Feedback.show(this, project, sb.toString(), "Report a problem at this moment")
    }

    private fun updateOffsetLabel() {
        val ms = project.offsetMs
        tvOffset.text = if (ms == 0) "Subtitle timing: 0.0s (in sync)"
                        else "Subtitle timing: %+.1fs (%s)".format(ms / 1000.0, if (ms > 0) "later" else "earlier")
    }

    private fun buildItem(): MediaItem {
        val f = File(cacheDir, "play_${project.id}_${project.offsetMs}.srt")
        f.writeText(Srt.format(cues, project.offsetMs / 1000.0))
        val lang = project.outLang.ifEmpty { "und" }
        val sub = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
            .setMimeType(MimeTypes.APPLICATION_SUBRIP)
            .setLanguage(lang)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        return MediaItem.Builder()
            .setUri(Uri.parse(project.uri))
            .setSubtitleConfigurations(listOf(sub))
            .build()
    }

    private fun shift(deltaMs: Int) {
        project.offsetMs += deltaMs
        Projects.save(project)
        updateOffsetLabel()
        poke()
        val pl = player ?: return
        val pos = pl.currentPosition
        val play = pl.playWhenReady
        pl.setMediaItem(buildItem(), pos)
        pl.prepare()
        pl.playWhenReady = play
    }

    override fun onStart() {
        super.onStart()
        if (!::project.isInitialized) return
        val pl = ExoPlayer.Builder(this).build()
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage(project.outLang.ifEmpty { "und" })
            .setSelectUndeterminedTextLanguage(true)
            .build()
        playerView.player = pl
        playerView.resizeMode = resizeMode
        pl.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity,
                    "Can't play this video (it may have been moved or deleted): ${error.errorCodeName}",
                    Toast.LENGTH_LONG).show()
            }
            // Follow play/pause intent, not "is frames moving": a short buffering pause on a slow
            // card must not flash the play icon or pop the controls up over the picture.
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                btnPlay.setImageResource(if (playWhenReady) R.drawable.ic_pl_pause else R.drawable.ic_pl_play)
                if (playWhenReady) poke() else { ui.removeCallbacks(hideControls); if (!locked) setControls(true) }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { if (isPlaying && controlsShown) poke() }
            override fun onPlaybackStateChanged(state: Int) { updateProgress() }
            override fun onVideoSizeChanged(size: VideoSize) {
                // like MX Player: wide videos open in landscape, tall ones in portrait (until you rotate yourself)
                if (userRotated || size.width <= 0 || size.height <= 0) return
                val wide = size.width * size.pixelWidthHeightRatio > size.height
                requestedOrientation = if (wide) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                       else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        })
        try {
            pl.setMediaItem(buildItem(), savedPos)
            pl.prepare()
            pl.playWhenReady = true
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open the video: ${e.message}", Toast.LENGTH_LONG).show()
        }
        player = pl
        setControls(true)
        ui.post(tick)
    }

    override fun onStop() {
        super.onStop()
        ui.removeCallbacksAndMessages(null)
        // timing was adjusted: update the saved .srt in the folder too
        if (::project.isInitialized && project.offsetMs != offsetAtOpen) {
            offsetAtOpen = project.offsetMs
            Exporter.autoSave(this, project)?.let {
                Toast.makeText(this, "Saved file updated with the new timing", Toast.LENGTH_SHORT).show()
            }
        }
        player?.let { savedPos = it.currentPosition; it.release() }
        player = null
    }

    private fun fmt(ms: Long): String {
        val t = (ms / 1000).toInt()
        return if (t >= 3600) "%d:%02d:%02d".format(t / 3600, (t / 60) % 60, t % 60)
               else "%d:%02d".format(t / 60, t % 60)
    }
}
