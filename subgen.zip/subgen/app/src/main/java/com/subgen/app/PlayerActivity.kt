package com.subgen.app

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import java.io.File

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var project: Project
    private lateinit var cues: List<Cue>
    private lateinit var playerView: PlayerView
    private lateinit var tvOffset: TextView
    private var savedPos = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        val id = intent.getStringExtra("id")
        val p = id?.let { Projects.load(this, it) }
        if (p == null) { finish(); return }
        project = p
        savedPos = intent.getLongExtra("startMs", 0L)
        Diag.installCrashHandler(this)
        cues = Srt.parse(project.srtFile.readText())

        playerView = findViewById(R.id.playerView)
        tvOffset = findViewById(R.id.tvOffset)
        val bar = findViewById<LinearLayout>(R.id.offsetBar)
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> bar.visibility = v })
        playerView.subtitleView?.apply {
            setStyle(CaptionStyleCompat(Color.WHITE, 0x88000000.toInt(), Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null))
            setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * 1.15f)
        }
        findViewById<Button>(R.id.btnM5).setOnClickListener { shift(-500) }
        findViewById<Button>(R.id.btnM1).setOnClickListener { shift(-100) }
        findViewById<Button>(R.id.btnP1).setOnClickListener { shift(100) }
        findViewById<Button>(R.id.btnP5).setOnClickListener { shift(500) }
        tvOffset.setOnClickListener { shift(-project.offsetMs) }
        findViewById<Button>(R.id.btnReport).setOnClickListener { report() }
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        updateOffsetLabel()

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    /** Report with the exact playback moment and the subtitle lines around it. */
    private fun report() {
        val pl = player
        pl?.playWhenReady = false
        val posSec = (pl?.currentPosition ?: 0L) / 1000.0
        val off = project.offsetMs / 1000.0
        val sb = StringBuilder("--- player ---\nPaused at %d:%05.2f (timing offset %+.1fs)\nLines around this moment:\n"
            .format((posSec / 60).toInt(), posSec % 60, off))
        val idx = cues.indexOfLast { it.start + off <= posSec }.coerceAtLeast(0)
        for (i in (idx - 3).coerceAtLeast(0)..(idx + 3).coerceAtMost(cues.size - 1)) {
            val c = cues[i]
            val mark = if (posSec >= c.start + off && posSec <= c.end + off) " <== on screen" else ""
            sb.append("  %.2f–%.2f  %s%s\n".format(c.start + off, c.end + off, c.text.replace("\n", " / "), mark))
        }
        Feedback.show(this, project, sb.toString(), "Report a problem at this moment")
    }

    private fun updateOffsetLabel() {
        val ms = project.offsetMs
        tvOffset.text = if (ms == 0) "Subtitle timing: 0.0s" else "Subtitle timing: %+.1fs (tap to reset)".format(ms / 1000.0)
    }

    private fun buildItem(): MediaItem {
        val f = File(cacheDir, "play_${project.id}_${project.offsetMs}.srt")
        f.writeText(Srt.format(cues, project.offsetMs / 1000.0))
        val lang = project.outLang.ifEmpty { "und" }
        val sub = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
            .setMimeType(MimeTypes.APPLICATION_SUBRIP)
            .setLanguage(lang)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        return MediaItem.Builder()
            .setUri(Uri.parse(project.uri))
            .setSubtitleConfigurations(listOf(sub))
            .build()
    }

    private fun shift(deltaMs: Int) {
        project.offsetMs += deltaMs
        Projects.save(project)
        updateOffsetLabel()
        val pl = player ?: return
        val pos = pl.currentPosition
        val play = pl.playWhenReady
        pl.setMediaItem(buildItem(), pos)
        pl.prepare()
        pl.playWhenReady = play
    }

    override fun onStart() {
        super.onStart()
        if (!::project.isInitialized) return
        val pl = ExoPlayer.Builder(this).build()
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage(project.outLang.ifEmpty { "und" })
            .setSelectUndeterminedTextLanguage(true)
            .build()
        playerView.player = pl
        pl.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity,
                    "Can't play this video (it may have been moved or deleted): ${error.errorCodeName}",
                    Toast.LENGTH_LONG).show()
            }
        })
        try {
            pl.setMediaItem(buildItem(), savedPos)
            pl.prepare()
            pl.playWhenReady = true
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open the video: ${e.message}", Toast.LENGTH_LONG).show()
        }
        player = pl
    }

    override fun onStop() {
        super.onStop()
        player?.let { savedPos = it.currentPosition; it.release() }
        player = null
    }
}
