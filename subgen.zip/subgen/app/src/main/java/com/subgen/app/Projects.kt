package com.subgen.app

import android.content.Context
import java.io.File
import java.util.Properties

class Project(val id: String, val dir: File, val props: Properties) {
    val name: String get() = props.getProperty("name", "Video")
    val uri: String get() = props.getProperty("uri", "")
    val srcLang: String get() = props.getProperty("src", "")
    val outLang: String get() = props.getProperty("out", "")
    var offsetMs: Int
        get() = props.getProperty("offsetMs", "0").toIntOrNull() ?: 0
        set(v) { props.setProperty("offsetMs", v.toString()) }
    val srtFile get() = File(dir, "subs.srt")
    val created: Long get() = props.getProperty("created", "0").toLongOrNull() ?: 0L
}

object Projects {
    private fun root(ctx: Context) = File(ctx.filesDir, "projects").apply { mkdirs() }

    fun create(ctx: Context, req: JobRequest, src: String, out: String, cues: List<Cue>): String {
        val id = System.currentTimeMillis().toString()
        val dir = File(root(ctx), id).apply { mkdirs() }
        File(dir, "subs.srt").writeText(Srt.format(cues))
        val p = Properties()
        p.setProperty("name", req.name)
        p.setProperty("uri", req.uri.toString())
        p.setProperty("src", src)
        p.setProperty("out", out)
        p.setProperty("offsetMs", "0")
        p.setProperty("created", id)
        File(dir, "meta.properties").outputStream().use { p.store(it, null) }
        return id
    }

    fun load(ctx: Context, id: String): Project? {
        val dir = File(root(ctx), id)
        val f = File(dir, "meta.properties")
        if (!f.exists()) return null
        val p = Properties()
        f.inputStream().use { p.load(it) }
        return Project(id, dir, p)
    }

    fun save(p: Project) {
        File(p.dir, "meta.properties").outputStream().use { p.props.store(it, null) }
    }

    fun list(ctx: Context): List<Project> =
        (root(ctx).listFiles() ?: emptyArray()).mapNotNull { load(ctx, it.name) }.sortedByDescending { it.created }

    fun delete(p: Project) {
        p.dir.deleteRecursively()
    }

    fun langLabel(code: String) = when (code) {
        "en" -> "English"; "zh" -> "简体中文"; "ja" -> "Japanese"; "ko" -> "Korean"; else -> code
    }
}
