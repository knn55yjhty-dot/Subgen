package com.subgen.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder

/** One video waiting for (or done with) subtitle generation, with the settings it was added with. */
data class QueueItem(
    val id: String,
    val uri: String,
    val name: String,
    val src: String,
    val target: String,
    val accurate: Boolean,
    val status: String = WAITING,   // waiting, running, done, failed, cancelled
    val resultId: String = "",
    val error: String = ""
) {
    fun request() = JobRequest(Uri.parse(uri), name, src, target, accurate)

    companion object {
        const val WAITING = "waiting"
        const val RUNNING = "running"
        const val DONE = "done"
        const val FAILED = "failed"
        const val CANCELLED = "cancelled"
    }
}

/**
 * The list of videos to process one after another. Saved to a small text file so it survives
 * the app or phone restarting. All changes go through here (thread-safe) and update [items].
 */
object Queue {
    val items = MutableStateFlow<List<QueueItem>>(emptyList())
    private var loaded = false

    private fun file(ctx: Context) = File(ctx.filesDir, "queue.txt")
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun dec(s: String) = URLDecoder.decode(s, "UTF-8")

    fun serialize(list: List<QueueItem>): String = list.joinToString("\n") {
        listOf(it.id, it.uri, it.name, it.src, it.target, it.accurate.toString(), it.status, it.resultId, it.error)
            .joinToString("\t") { f -> enc(f) }
    }

    fun parse(text: String): List<QueueItem> = text.lines().mapNotNull { line ->
        val f = line.split("\t").map { dec(it) }
        if (f.size < 9) null
        else QueueItem(f[0], f[1], f[2], f[3], f[4], f[5] == "true", f[6], f[7], f[8])
    }

    @Synchronized
    fun load(ctx: Context): List<QueueItem> {
        if (!loaded) {
            val f = file(ctx)
            items.value = if (f.exists()) try { parse(f.readText()) } catch (_: Exception) { emptyList() } else emptyList()
            loaded = true
        }
        return items.value
    }

    @Synchronized
    private fun set(ctx: Context, list: List<QueueItem>) {
        items.value = list
        try { file(ctx).writeText(serialize(list)) } catch (_: Exception) {}
    }

    @Synchronized
    fun add(ctx: Context, newItems: List<QueueItem>) {
        set(ctx, load(ctx) + newItems)
    }

    /** Marks the next waiting video as running and returns it (null if none). */
    @Synchronized
    fun takeNext(ctx: Context): QueueItem? {
        val list = load(ctx)
        val i = list.indexOfFirst { it.status == QueueItem.WAITING }
        if (i < 0) return null
        val item = list[i].copy(status = QueueItem.RUNNING, error = "")
        set(ctx, list.toMutableList().also { it[i] = item })
        return item
    }

    @Synchronized
    fun finish(ctx: Context, id: String, status: String, resultId: String = "", error: String = "") {
        set(ctx, load(ctx).map { if (it.id == id) it.copy(status = status, resultId = resultId, error = error) else it })
    }

    /** After a crash or restart nothing is really running: put such videos back in line. */
    @Synchronized
    fun resetStale(ctx: Context) {
        val list = load(ctx)
        if (list.any { it.status == QueueItem.RUNNING })
            set(ctx, list.map { if (it.status == QueueItem.RUNNING) it.copy(status = QueueItem.WAITING) else it })
    }

    @Synchronized
    fun remove(ctx: Context, id: String) {
        set(ctx, load(ctx).filter { it.id != id || it.status == QueueItem.RUNNING })
    }

    /** Removes finished/failed/cancelled videos from the list (their subtitles stay saved). */
    @Synchronized
    fun clearFinished(ctx: Context) {
        set(ctx, load(ctx).filter { it.status == QueueItem.WAITING || it.status == QueueItem.RUNNING })
    }

    /** Puts failed/cancelled videos back in line. */
    @Synchronized
    fun retry(ctx: Context, id: String) {
        set(ctx, load(ctx).map { if (it.id == id && (it.status == QueueItem.FAILED || it.status == QueueItem.CANCELLED)) it.copy(status = QueueItem.WAITING, error = "") else it })
    }

    fun waitingCount(ctx: Context) = load(ctx).count { it.status == QueueItem.WAITING }

    /** Position of an item among this round's videos, e.g. (2, 5) = "2 of 5". */
    fun position(ctx: Context, id: String): Pair<Int, Int> {
        val active = load(ctx).filter { it.status == QueueItem.WAITING || it.status == QueueItem.RUNNING || it.status == QueueItem.DONE }
        val i = active.indexOfFirst { it.id == id }
        return (i + 1) to active.size
    }
}
