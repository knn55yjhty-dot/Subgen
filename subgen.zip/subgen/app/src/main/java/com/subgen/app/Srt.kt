package com.subgen.app

object Srt {
    private fun ts(sec: Double): String {
        val ms = (sec.coerceAtLeast(0.0) * 1000).toLong()
        val h = ms / 3600000
        val m = (ms / 60000) % 60
        val s = (ms / 1000) % 60
        val r = ms % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, r)
    }

    fun format(cues: List<Cue>, offsetSec: Double = 0.0): String {
        val sb = StringBuilder()
        var n = 1
        for (c in cues) {
            val s = c.start + offsetSec
            val e = c.end + offsetSec
            if (e <= 0) continue
            sb.append(n++).append('\n')
            sb.append(ts(s)).append(" --> ").append(ts(e)).append('\n')
            sb.append(c.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun parseTs(t: String): Double {
        val m = Regex("(\\d+):(\\d+):(\\d+)[,.](\\d+)").find(t) ?: return 0.0
        val (h, mi, s, ms) = m.destructured
        return h.toInt() * 3600 + mi.toInt() * 60 + s.toInt() + ms.padEnd(3, '0').take(3).toInt() / 1000.0
    }

    fun parse(text: String): List<Cue> {
        val out = mutableListOf<Cue>()
        val blocks = text.replace("\r", "").split(Regex("\n\\s*\n"))
        for (b in blocks) {
            val lines = b.trim().lines()
            val idx = lines.indexOfFirst { it.contains("-->") }
            if (idx < 0) continue
            val parts = lines[idx].split("-->")
            val body = lines.drop(idx + 1).joinToString("\n").trim()
            if (body.isEmpty()) continue
            out.add(Cue(parseTs(parts[0]), parseTs(parts[1]), body))
        }
        return out
    }
}
