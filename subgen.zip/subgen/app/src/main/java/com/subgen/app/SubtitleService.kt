package com.subgen.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlin.concurrent.thread

object Eta {
    /** "About 1 h 20 min left" style text. */
    fun format(sec: Double): String {
        val m = Math.round(sec / 60.0).toInt()
        return when {
            sec < 60 -> "less than a minute left"
            m < 60 -> "about $m min left"
            else -> "about ${m / 60} h ${m % 60} min left"
        }
    }
}

object JobState {
    data class S(
        val running: Boolean = false,
        val stage: String = "",
        val progress: Float = 0f,
        val etaSec: Double? = null,
        val current: String = "",
        val error: String? = null,
        val doneId: String? = null
    )

    val state = MutableStateFlow(S())

    /** Newest subtitle lines while generating (time in seconds, text). */
    /** [count] > 1: the same line came out several times in a row (the model repeating itself). */
    data class PreviewLine(val time: Double, val text: String, val translated: Boolean = false,
                           val note: Boolean = false, val count: Int = 1)
    val preview = MutableStateFlow<List<PreviewLine>>(emptyList())
    /** True once "Watch so far" has finished subtitles to play (not just live lines). */
    val watchReady = MutableStateFlow(false)
    /** The user already watched this job's subtitles from the start (then the button jumps to the newest). */
    @Volatile var watchedFromStart = false
    fun addPreview(line: PreviewLine) {
        preview.update { list ->   // atomic: two threads add lines
            // a line identical to one of the last few (same kind) is counted, not listed again
            val k = CueBuilder.sameKey(line.text)
            val i = list.indexOfLast { !it.note && it.translated == line.translated }
            val prev = list.getOrNull(i)
            if (!line.note && k.isNotEmpty() && prev != null && CueBuilder.sameKey(prev.text) == k && line.time - prev.time < 15)
                list.toMutableList().also { it[i] = prev.copy(count = prev.count + 1) }
            else (list + line).takeLast(8)
        }
    }
    @Volatile var pipeline: Pipeline? = null
    @Volatile var shownDoneId: String? = null
    @Volatile var stopRequested = false
    /** True while the queue worker is alive (including the moment between two videos). */
    val serviceActive = MutableStateFlow(false)
}

class SubtitleService : Service() {
    companion object {
        private const val CHANNEL = "jobs"
        private const val NOTIF_ID = 1

        private const val DONE_CHANNEL = "done"

        /** Starts working through the queue (does nothing extra if already running). */
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, SubtitleService::class.java))
        }

        /** Cancels the current video; the queue continues with the next one. */
        fun cancel() {
            JobState.pipeline?.cancel()
        }

        /** Cancels the current video and stops the queue (waiting videos stay in the list). */
        fun stopQueue() {
            JobState.stopRequested = true
            JobState.pipeline?.cancel()
        }
    }

    @Volatile private var worker: Thread? = null
    private val lock = Any()
    @Volatile private var lastStartId = 0
    private var lastNotif = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    // Android 14/15 stop long background jobs after ~6 h; cancel cleanly instead of being force-closed.
    override fun onTimeout(startId: Int) = timedOut()
    override fun onTimeout(startId: Int, fgsType: Int) = timedOut()
    private fun timedOut() {
        Diag.info(this, "Android background time limit reached; cancelling")
        try {
            val pi = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java).putExtra("tab", MainActivity.TAB_GENERATE),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID + 1, NotificationCompat.Builder(this, DONE_CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Paused by Android's background time limit")
                .setContentText("Android allows about 6 hours of background work a day. Open SubGen and tap Start queue to continue.")
                .setStyle(NotificationCompat.BigTextStyle().bigText("Android allows about 6 hours of background work a day. " +
                    "The video in progress went back into the queue. Open SubGen and tap Start queue to continue."))
                .setAutoCancel(true).setContentIntent(pi).build())
        } catch (_: Exception) {}
        JobState.stopRequested = true
        JobState.pipeline?.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notif(text: String, progress: Int): android.app.Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Generating subtitles")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(pi)
            .setProgress(100, progress, false)
            .build()
    }

    private fun runOne(item: QueueItem, nm: NotificationManager) {
        nm.cancel(NOTIF_ID + 2)
        val req = item.request()
        val (pos, total) = Queue.position(this, item.id)
        val tag = if (total > 1) "[$pos/$total] " else ""
        Diag.begin(this, "${req.name} | src=${req.srcLang} target=${req.target} accurate=${req.accurate}")
        JobState.preview.value = emptyList()
        JobState.watchReady.value = false
        JobState.watchedFromStart = false
        JobState.state.value = JobState.S(running = true, stage = "${tag}Starting…", current = req.name)
        val p = Pipeline(this, req) { stage, prog, eta ->
            Diag.stage(this, stage.substringBefore('…'))
            JobState.state.value = JobState.S(running = true, stage = tag + stage, progress = prog, etaSec = eta, current = req.name)
            val now = System.currentTimeMillis()
            if (now - lastNotif > 1000) {
                lastNotif = now
                val etaText = eta?.let { " · ${Eta.format(it)}" } ?: ""
                nm.notify(NOTIF_ID, notif(tag + stage + etaText, (prog * 100).toInt()))
            }
        }
        p.onFirstCheck = { first ->
            Diag.info(this, "first minute ready for checking (first line at %.1f s)".format(first))
            if (JobState.pipeline === p) notifyFirstCheck(nm, req.name)   // not if the job just ended
        }
        JobState.pipeline = p
        try {
            val id = p.run()
            val where = Projects.load(this, id)?.let { proj -> Exporter.autoSave(this, proj) { Diag.info(this, it) } }
            Diag.info(this, if (where != null) "saved to $where" else "not saved to a folder (saving is ${Exporter.folderLabel(this)})")
            Diag.end(this, "done" + (p.notice?.let { " ($it)" } ?: ""))
            Queue.finish(this, item.id, QueueItem.DONE, resultId = id, error = p.notice ?: "")
            JobState.state.value = JobState.S(running = false, stage = p.notice ?: "Done: ${req.name}", progress = 1f,
                doneId = if (Queue.waitingCount(this) == 0 && !JobState.stopRequested) id else null)
            notifyDone(nm, item, "Subtitles ready", req.name)
        } catch (e: CancelledException) {
            Diag.end(this, "cancelled")
            Queue.finish(this, item.id, if (JobState.stopRequested) QueueItem.WAITING else QueueItem.CANCELLED)
            JobState.state.value = JobState.S(running = false, stage = if (JobState.stopRequested) "Queue stopped" else "Cancelled: ${req.name}")
        } catch (e: Throwable) {
            Diag.end(this, "failed: $e")
            val msg = e.message ?: e.toString()
            Queue.finish(this, item.id, QueueItem.FAILED, error = msg)
            JobState.state.value = JobState.S(running = false, stage = "Failed", error = "${req.name}: $msg")
            notifyDone(nm, item, "Subtitles failed", req.name)
        } finally {
            Pipeline.tempAudio(this).delete()
            JobState.pipeline = null
            nm.cancel(NOTIF_ID + 2)   // done, failed or cancelled: the "first minute" check is no longer useful
        }
    }

    /** "First minute ready": lets the user check sync early instead of after the whole video. */
    private fun notifyFirstCheck(nm: NotificationManager, name: String) {
        try {
            val pi = PendingIntent.getActivity(this, 3,
                Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_WATCH, true),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(NOTIF_ID + 2, NotificationCompat.Builder(this, DONE_CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("First minute ready: check the sync")
                .setContentText("Tap to watch the first subtitles of $name while the rest is made.")
                .setStyle(NotificationCompat.BigTextStyle().bigText(
                    "Tap to watch the first subtitles of $name while the rest is made. " +
                    "If they're out of sync or wrong, cancel now instead of waiting for the whole video."))
                .setAutoCancel(true).setContentIntent(pi).build())
        } catch (_: Exception) {}
    }

    private fun notifyDone(nm: NotificationManager, item: QueueItem, title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java).putExtra("tab", MainActivity.TAB_LIBRARY),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(1000 + (item.id.hashCode() and 0xffff), NotificationCompat.Builder(this, DONE_CHANNEL)
                .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
                .setAutoCancel(true).setContentIntent(pi).build())
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Subtitle jobs", NotificationManager.IMPORTANCE_LOW))
        // "dataSync" works on every Android version. (The newer "mediaProcessing" type is rejected as
        // "type none" on some Android 15 builds, e.g. OPPO ColorOS, which crashed the app.)
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, notif("Starting…", 0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            // Don't crash: tell the user and stop.
            Diag.installCrashHandler(this)
            Diag.begin(this, "foreground start failed")
            Diag.end(this, "failed to start background job: $e")
            JobState.state.value = JobState.S(running = false, stage = "Failed",
                error = "Android refused to start the background job: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }

        Queue.load(this)
        Diag.installCrashHandler(this)
        nm.createNotificationChannel(NotificationChannel(DONE_CHANNEL, "Finished subtitles", NotificationManager.IMPORTANCE_DEFAULT))
        synchronized(lock) {
            lastStartId = startId
            if (worker != null) return START_NOT_STICKY   // already working: it will pick up new videos
            JobState.stopRequested = false
            JobState.serviceActive.value = true
            val wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "subgen:job")
            // not reference-counted: re-acquiring per video just renews the timeout, one release ends it
            wl.setReferenceCounted(false)
            val me = thread(start = false, name = "subgen-job") {
                try {
                    while (true) {
                        // Taking the next video and deciding to finish happen under one lock, so a video
                        // added at the last moment is either picked up here or starts a fresh worker.
                        val item = synchronized(lock) {
                            val next = if (JobState.stopRequested) null else Queue.takeNext(this)
                            if (next == null) {
                                worker = null
                                JobState.serviceActive.value = false
                            }
                            next
                        } ?: break
                        wl.acquire(4 * 60 * 60 * 1000L)   // safety timeout per video, renewed for each
                        runOne(item, nm)
                    }
                } finally {
                    Pipeline.tempAudio(this).delete()
                    JobState.pipeline = null
                    if (wl.isHeld) wl.release()
                    synchronized(lock) {
                        if (worker == null || worker === Thread.currentThread()) {
                            worker = null
                            JobState.serviceActive.value = false
                            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                            stopSelf(lastStartId)   // ignored if a newer start request came in
                        }
                    }
                }
            }
            worker = me
            me.start()
        }
        return START_NOT_STICKY
    }
}
