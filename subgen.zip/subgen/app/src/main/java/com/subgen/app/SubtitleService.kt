package com.subgen.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlin.concurrent.thread

object Eta {
    /** "About 1 h 20 min left" style text. */
    fun format(sec: Double): String {
        val m = Math.round(sec / 60.0).toInt()
        return when {
            sec < 60 -> "less than a minute left"
            m < 60 -> "about $m min left"
            else -> "about ${m / 60} h ${m % 60} min left"
        }
    }
}

object JobState {
    data class S(
        val running: Boolean = false,
        val stage: String = "",
        val progress: Float = 0f,
        val etaSec: Double? = null,
        val current: String = "",
        val error: String? = null,
        val doneId: String? = null
    )

    val state = MutableStateFlow(S())

    /** Newest subtitle lines while generating (time in seconds, text). */
    data class PreviewLine(val time: Double, val text: String, val translated: Boolean = false)
    val preview = MutableStateFlow<List<PreviewLine>>(emptyList())
    fun addPreview(line: PreviewLine) {
        preview.update { (it + line).takeLast(8) }   // atomic: two threads add lines
    }
    @Volatile var pipeline: Pipeline? = null
    @Volatile var shownDoneId: String? = null
    @Volatile var stopRequested = false
    /** True while the queue worker is alive (including the moment between two videos). */
    val serviceActive = MutableStateFlow(false)
}

class SubtitleService : Service() {
    companion object {
        private const val CHANNEL = "jobs"
        private const val NOTIF_ID = 1

        private const val DONE_CHANNEL = "done"

        /** Starts working through the queue (does nothing extra if already running). */
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, SubtitleService::class.java))
        }

        /** Cancels the current video; the queue continues with the next one. */
        fun cancel() {
            JobState.pipeline?.cancel()
        }

        /** Cancels the current video and stops the queue (waiting videos stay in the list). */
        fun stopQueue() {
            JobState.stopRequested = true
            JobState.pipeline?.cancel()
        }
    }

    @Volatile private var worker: Thread? = null
    private val lock = Any()
    @Volatile private var lastStartId = 0
    private var lastNotif = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    // Android 14/15 stop long background jobs after ~6 h; cancel cleanly instead of being force-closed.
    override fun onTimeout(startId: Int) = timedOut()
    override fun onTimeout(startId: Int, fgsType: Int) = timedOut()
    private fun timedOut() {
        Diag.info(this, "Android background time limit reached; cancelling")
        JobState.stopRequested = true
        JobState.pipeline?.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notif(text: String, progress: Int): android.app.Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Generating subtitles")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(pi)
            .setProgress(100, progress, false)
            .build()
    }

    private fun runOne(item: QueueItem, nm: NotificationManager) {
        val req = item.request()
        val (pos, total) = Queue.position(this, item.id)
        val tag = if (total > 1) "[$pos/$total] " else ""
        Diag.begin(this, "${req.name} | src=${req.srcLang} target=${req.target} accurate=${req.accurate}")
        JobState.preview.value = emptyList()
        JobState.state.value = JobState.S(running = true, stage = "${tag}Starting…", current = req.name)
        val p = Pipeline(this, req) { stage, prog, eta ->
            Diag.stage(this, stage.substringBefore('…'))
            JobState.state.value = JobState.S(running = true, stage = tag + stage, progress = prog, etaSec = eta, current = req.name)
            val now = System.currentTimeMillis()
            if (now - lastNotif > 1000) {
                lastNotif = now
                val etaText = eta?.let { " · ${Eta.format(it)}" } ?: ""
                nm.notify(NOTIF_ID, notif(tag + stage + etaText, (prog * 100).toInt()))
            }
        }
        JobState.pipeline = p
        try {
            val id = p.run()
            Diag.end(this, "done" + (p.notice?.let { " ($it)" } ?: ""))
            Queue.finish(this, item.id, QueueItem.DONE, resultId = id, error = p.notice ?: "")
            JobState.state.value = JobState.S(running = false, stage = p.notice ?: "Done: ${req.name}", progress = 1f,
                doneId = if (Queue.waitingCount(this) == 0 && !JobState.stopRequested) id else null)
            notifyDone(nm, item, "Subtitles ready", req.name)
        } catch (e: CancelledException) {
            Diag.end(this, "cancelled")
            Queue.finish(this, item.id, if (JobState.stopRequested) QueueItem.WAITING else QueueItem.CANCELLED)
            JobState.state.value = JobState.S(running = false, stage = if (JobState.stopRequested) "Queue stopped" else "Cancelled: ${req.name}")
        } catch (e: Throwable) {
            Diag.end(this, "failed: $e")
            val msg = e.message ?: e.toString()
            Queue.finish(this, item.id, QueueItem.FAILED, error = msg)
            JobState.state.value = JobState.S(running = false, stage = "Failed", error = "${req.name}: $msg")
            notifyDone(nm, item, "Subtitles failed", req.name)
        } finally {
            Pipeline.tempAudio(this).delete()
            JobState.pipeline = null
        }
    }

    private fun notifyDone(nm: NotificationManager, item: QueueItem, title: String, text: String) {
        try {
            val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            nm.notify(1000 + (item.id.hashCode() and 0xffff), NotificationCompat.Builder(this, DONE_CHANNEL)
                .setSmallIcon(R.drawable.ic_notif).setContentTitle(title).setContentText(text)
                .setAutoCancel(true).setContentIntent(pi).build())
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Subtitle jobs", NotificationManager.IMPORTANCE_LOW))
        // "dataSync" works on every Android version. (The newer "mediaProcessing" type is rejected as
        // "type none" on some Android 15 builds, e.g. OPPO ColorOS, which crashed the app.)
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, notif("Starting…", 0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            // Don't crash: tell the user and stop.
            Diag.installCrashHandler(this)
            Diag.begin(this, "foreground start failed")
            Diag.end(this, "failed to start background job: $e")
            JobState.state.value = JobState.S(running = false, stage = "Failed",
                error = "Android refused to start the background job: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }

        Queue.load(this)
        Diag.installCrashHandler(this)
        nm.createNotificationChannel(NotificationChannel(DONE_CHANNEL, "Finished subtitles", NotificationManager.IMPORTANCE_DEFAULT))
        synchronized(lock) {
            lastStartId = startId
            if (worker != null) return START_NOT_STICKY   // already working: it will pick up new videos
            JobState.stopRequested = false
            JobState.serviceActive.value = true
            val wl = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "subgen:job")
            wl.acquire(6 * 60 * 60 * 1000L)
            val me = thread(start = false, name = "subgen-job") {
                try {
                    while (true) {
                        // Taking the next video and deciding to finish happen under one lock, so a video
                        // added at the last moment is either picked up here or starts a fresh worker.
                        val item = synchronized(lock) {
                            val next = if (JobState.stopRequested) null else Queue.takeNext(this)
                            if (next == null) {
                                worker = null
                                JobState.serviceActive.value = false
                            }
                            next
                        } ?: break
                        runOne(item, nm)
                    }
                } finally {
                    Pipeline.tempAudio(this).delete()
                    JobState.pipeline = null
                    if (wl.isHeld) wl.release()
                    synchronized(lock) {
                        if (worker == null || worker === Thread.currentThread()) {
                            worker = null
                            JobState.serviceActive.value = false
                            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                            stopSelf(lastStartId)   // ignored if a newer start request came in
                        }
                    }
                }
            }
            worker = me
            me.start()
        }
        return START_NOT_STICKY
    }
}
