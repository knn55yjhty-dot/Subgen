package com.subgen.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.concurrent.thread

object JobState {
    data class S(
        val running: Boolean = false,
        val stage: String = "",
        val progress: Float = 0f,
        val error: String? = null,
        val doneId: String? = null
    )

    val state = MutableStateFlow(S())
    @Volatile var pipeline: Pipeline? = null
    @Volatile var shownDoneId: String? = null
}

class SubtitleService : Service() {
    companion object {
        private const val CHANNEL = "jobs"
        private const val NOTIF_ID = 1

        fun start(ctx: Context, req: JobRequest) {
            val i = Intent(ctx, SubtitleService::class.java)
                .putExtra("uri", req.uri.toString())
                .putExtra("name", req.name)
                .putExtra("src", req.srcLang)
                .putExtra("target", req.target)
                .putExtra("accurate", req.accurate)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun cancel() {
            JobState.pipeline?.cancel()
        }
    }

    private var worker: Thread? = null
    private var lastNotif = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    // Android 14/15 stop long background jobs after ~6 h; cancel cleanly instead of being force-closed.
    override fun onTimeout(startId: Int) = timedOut()
    override fun onTimeout(startId: Int, fgsType: Int) = timedOut()
    private fun timedOut() {
        Diag.info(this, "Android background time limit reached; cancelling")
        JobState.pipeline?.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notif(text: String, progress: Int): android.app.Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Generating subtitles")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(pi)
            .setProgress(100, progress, false)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Subtitle jobs", NotificationManager.IMPORTANCE_LOW))
        val type = if (Build.VERSION.SDK_INT >= 35) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING
        else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        ServiceCompat.startForeground(this, NOTIF_ID, notif("Starting…", 0), type)

        if (worker != null || intent == null) return START_NOT_STICKY
        val req = JobRequest(
            Uri.parse(intent.getStringExtra("uri")),
            intent.getStringExtra("name") ?: "Video",
            intent.getStringExtra("src") ?: "auto",
            intent.getStringExtra("target") ?: "orig",
            intent.getBooleanExtra("accurate", true)
        )
        val wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "subgen:job")
        wl.acquire(6 * 60 * 60 * 1000L)

        Diag.installCrashHandler(this)
        Diag.begin(this, "${req.name} | src=${req.srcLang} target=${req.target} accurate=${req.accurate}")
        JobState.state.value = JobState.S(running = true, stage = "Starting…")
        worker = thread(name = "subgen-job") {
            val p = Pipeline(this, req) { stage, prog ->
                Diag.stage(this, stage)
                JobState.state.value = JobState.S(running = true, stage = stage, progress = prog)
                val now = System.currentTimeMillis()
                if (now - lastNotif > 1000) {
                    lastNotif = now
                    nm.notify(NOTIF_ID, notif(stage, (prog * 100).toInt()))
                }
            }
            JobState.pipeline = p
            try {
                val id = p.run()
                Diag.end(this, "done" + (p.notice?.let { " ($it)" } ?: ""))
                JobState.state.value = JobState.S(running = false, stage = p.notice ?: "Done", progress = 1f, doneId = id)
            } catch (e: CancelledException) {
                Diag.end(this, "cancelled")
                JobState.state.value = JobState.S(running = false, stage = "Cancelled")
            } catch (e: Throwable) {
                Diag.end(this, "failed: $e")
                JobState.state.value = JobState.S(running = false, stage = "Failed", error = e.message ?: e.toString())
            } finally {
                Pipeline.tempAudio(this).delete()
                JobState.pipeline = null
                if (wl.isHeld) wl.release()
                worker = null
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }
}
