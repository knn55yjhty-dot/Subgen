package com.subgen.app

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

const val SR = 16000
const val FRAME = 160 // 10 ms

class PcmFile(val file: File, val samples: Long) {

    /** Loudness of every 10 ms frame, in dBFS. */
    fun frameDb(): FloatArray {
        val nf = (samples / FRAME).toInt()
        val out = FloatArray(nf)
        BufferedInputStream(FileInputStream(file), 1 shl 16).use { inp ->
            val b = ByteArray(FRAME * 2)
            var px = 0.0
            var py = 0.0
            for (f in 0 until nf) {
                var read = 0
                while (read < b.size) {
                    val r = inp.read(b, read, b.size - read)
                    if (r < 0) break
                    read += r
                }
                var sum = 0.0
                var i = 0
                while (i + 1 < read) {
                    val x = ((b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)).toShort() / 32768.0
                    val y = 0.944 * (py + x - px) // 150 Hz high-pass
                    px = x; py = y
                    sum += y * y
                    i += 2
                }
                out[f] = (10 * log10(sum / FRAME + 1e-10)).toFloat()
            }
        }
        return out
    }

    fun read(from: Long, to: Long): FloatArray {
        val a = from.coerceIn(0, samples)
        val b = to.coerceIn(a, samples)
        val n = (b - a).toInt()
        val bytes = ByteArray(n * 2)
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(a * 2)
            raf.readFully(bytes)
        }
        val out = FloatArray(n)
        for (i in 0 until n) {
            out[i] = ((bytes[2 * i].toInt() and 0xFF) or (bytes[2 * i + 1].toInt() shl 8)).toShort() / 32768f
        }
        return out
    }
}

/** Uses the audio's loudness to snap subtitle edges to where speech really starts and stops. */
class Energy(private val db: FloatArray, private val thr: Float) {
    val frames get() = db.size

    fun isSpeech(f: Int) = f in db.indices && db[f] > thr
    private fun speech(f: Int) = isSpeech(f)

    /** true if every frame in [a, b] that exists is below the threshold */
    private fun quiet(a: Int, b: Int): Boolean {
        for (f in max(0, a)..min(db.size - 1, b)) if (speech(f)) return false
        return true
    }

    fun firstSpeech(from: Int = 0): Int {
        for (f in from until db.size) if (speech(f) && speech(f + 1) && speech(f + 2)) return f
        return -1
    }

    fun hasSpeech(range: IntRange): Boolean {
        var c = 0
        for (f in range) if (speech(f)) { c++; if (c > 40) return true }
        return false
    }

    fun speechRatio(start: Double, end: Double): Double {
        val a = (start * 100).toInt().coerceIn(0, db.size)
        val b = (end * 100).toInt().coerceIn(a, db.size)
        if (b <= a) return 0.0
        var c = 0
        for (f in a until b) if (speech(f)) c++
        return c.toDouble() / (b - a)
    }

    /** Nearest silence->speech transition within ±0.3 s. */
    fun refineStart(t: Double): Double {
        val c = (t * 100).roundToInt()
        var best = -1
        var bestD = Int.MAX_VALUE
        for (f in (c - 30)..(c + 30)) {
            if (f < 1 || f + 2 >= db.size) continue
            // a real onset: >= 80 ms of quiet before it (short dips between syllables don't count)
            if (speech(f) && speech(f + 1) && quiet(f - 8, f - 1)) {
                // slightly prefer onsets before the model's estimate (subtitles should never lag)
                val d = if (f <= c) (c - f) else (f - c) * 3 / 2
                if (d < bestD) { bestD = d; best = f }
            }
        }
        return if (best >= 0) max(0.0, best / 100.0 - 0.05) else t
    }

    /** Nearest speech->silence transition within -0.3 s / +0.6 s. */
    fun refineEnd(t: Double): Double {
        val c = (t * 100).roundToInt()
        var best = -1
        var bestD = Int.MAX_VALUE
        for (f in (c - 30)..(c + 60)) {
            if (f < 1 || f >= db.size) continue
            // a real offset: >= 100 ms of quiet after it
            if (speech(f - 1) && quiet(f, f + 9)) {
                val d = abs(f - c)
                if (d < bestD) { bestD = d; best = f }
            }
        }
        return if (best >= 0) best / 100.0 + 0.12 else t
    }
}

/** A batch of speech-only audio pieces, processed together with short silences in between. */
class Chunk(val pieces: List<IntRange>) {
    val frames get() = pieces.sumOf { it.last - it.first + 1 }
}

/** Maps time in the packed (speech-only) audio back to time in the original video. */
class TimeMap {
    private val packedStart = ArrayList<Double>()
    private val origStart = ArrayList<Double>()
    private val len = ArrayList<Double>()

    fun add(packed: Double, orig: Double, length: Double) {
        packedStart.add(packed); origStart.add(orig); len.add(length)
    }

    fun map(t: Double): Double {
        if (packedStart.isEmpty()) return t
        var i = 0
        while (i + 1 < packedStart.size && packedStart[i + 1] <= t) i++
        return origStart[i] + (t - packedStart[i]).coerceIn(0.0, len[i])
    }
}

object Timing {
    /**
     * Finds the stretches that contain speech (with generous padding) and packs them into
     * batches of up to ~4.5 minutes, so the speech model never spends time on silence.
     */
    fun planSpeechChunks(db: FloatArray, energy: Energy): List<Chunk> {
        val regions = mutableListOf<IntRange>()
        var f = 0
        while (f < db.size) {
            if (energy.isSpeech(f)) {
                val s = f
                while (f < db.size && energy.isSpeech(f)) f++
                regions.add(s until f)
            } else f++
        }
        if (regions.isEmpty()) return emptyList()

        // Merge pauses shorter than 2 s, then pad 0.4 s on each side so no word gets clipped.
        val merged = mutableListOf<IntRange>()
        for (r in regions) {
            val last = merged.lastOrNull()
            if (last != null && r.first - last.last < 300) merged[merged.size - 1] = last.first..r.last
            else merged.add(r)
        }
        val padded = mutableListOf<IntRange>()
        for (r in merged) {
            if (r.last - r.first < 4) continue // clicks, not speech
            val a = max(0, r.first - 60)
            val b = min(db.size - 1, r.last + 60)
            val last = padded.lastOrNull()
            if (last != null && a <= last.last + 1) padded[padded.size - 1] = last.first..b
            else padded.add(a..b)
        }

        // Very long continuous regions are split at their quietest point.
        val pieces = mutableListOf<IntRange>()
        for (r in padded) {
            if (r.last - r.first + 1 <= 30000) { pieces.add(r); continue }
            for (sub in planChunks(db.copyOfRange(r.first, r.last + 1))) {
                pieces.add((sub.first + r.first)..(sub.last + r.first))
            }
        }

        val chunks = mutableListOf<Chunk>()
        var cur = mutableListOf<IntRange>()
        var size = 0
        for (p in pieces) {
            val n = p.last - p.first + 1
            if (cur.isNotEmpty() && size + n > 27000) {
                chunks.add(Chunk(cur)); cur = mutableListOf(); size = 0
            }
            cur.add(p); size += n + 30
        }
        if (cur.isNotEmpty()) chunks.add(Chunk(cur))
        return chunks
    }

    fun threshold(db: FloatArray): Float {
        if (db.isEmpty()) return -45f
        val s = db.copyOf()
        s.sort()
        val floor = s[(s.size * 0.10).toInt().coerceIn(0, s.size - 1)]
        // Only ~6 dB above the background noise counts as possible speech, so murmurs are kept.
        return (floor + 6f).coerceIn(-62f, -38f)
    }

    /** Splits audio into ~5 minute chunks, cutting at the quietest moment near each boundary. */
    fun planChunks(db: FloatArray): List<IntRange> {
        val chunk = 30000
        val out = mutableListOf<IntRange>()
        var s = 0
        while (s < db.size) {
            if (db.size - s <= chunk + 3000) {
                out.add(s until db.size); break
            }
            var bestCut = s + chunk
            var bestVal = Float.MAX_VALUE
            var f = s + chunk - 3000
            while (f < s + chunk) {
                var sum = 0f
                for (k in f until min(f + 30, db.size)) sum += db[k]
                if (sum < bestVal) { bestVal = sum; bestCut = f + 15 }
                f += 5
            }
            out.add(s until bestCut)
            s = bestCut
        }
        return out
    }

    fun finalize(input: List<Cue>, energy: Energy): List<Cue> {
        var list = input.map { it.copy(text = CueBuilder.clean(it.text)) }
            .filter { it.text.isNotBlank() && !CueBuilder.isAnnotation(it.text) }
            .sortedBy { it.start }
            .toMutableList()

        for (c in list) {
            val s = energy.refineStart(c.start)
            val e = energy.refineEnd(c.end)
            c.start = s
            c.end = max(e, s + 0.2)
        }
        list.sortBy { it.start }

        // Drop lines that sit on silence (typical hallucinations).
        list = list.filter { energy.speechRatio(it.start, it.end) >= 0.03 }.toMutableList()

        // Drop repetition loops (same line 3+ times in a row).
        val dedup = mutableListOf<Cue>()
        for (c in list) {
            val n = dedup.size
            if (n >= 2 && dedup[n - 1].text == c.text && dedup[n - 2].text == c.text) continue
            dedup.add(c)
        }
        list = dedup

        for (i in list.indices) {
            val c = list[i]
            val next = list.getOrNull(i + 1)
            val minDur = max(0.9, min(3.0, CueBuilder.displayLen(c.text) * 0.045))
            if (c.end - c.start < minDur) c.end = c.start + minDur
            if (next != null) {
                if (next.start <= c.start) next.start = c.start + 0.05
                if (c.end > next.start - 0.03) c.end = max(c.start + 0.2, next.start - 0.03)
                // close tiny gaps so text doesn't flicker
                if (next.start - c.end < 0.25) c.end = max(c.start + 0.2, next.start - 0.03)
            }
        }
        return list
    }
}

/**
 * Raises quiet passages (murmurs, background voices) toward normal speech loudness before
 * recognition, without boosting pure silence. Gain is limited to +16 dB and smoothed.
 */
object Leveler {
    private const val WIN = 6400 // 0.4 s
    private const val TARGET = 0.08f // about -22 dBFS
    private const val MAX_GAIN = 6.3f // +16 dB

    /**
     * gateDb: the video's own speech threshold (a few dB above its background noise).
     * Windows quieter than that are left alone, so room tone and hiss are not amplified.
     */
    fun apply(x: FloatArray, gateDb: Float) {
        val gate = Math.pow(10.0, (gateDb + 3f) / 20.0).toFloat()
        if (x.isEmpty()) return
        val nw = (x.size + WIN - 1) / WIN
        val gains = FloatArray(nw)
        for (w in 0 until nw) {
            val a = w * WIN
            val b = min(x.size, a + WIN)
            var sum = 0.0
            for (i in a until b) sum += (x[i] * x[i]).toDouble()
            val rms = kotlin.math.sqrt(sum / (b - a)).toFloat()
            gains[w] = if (rms < gate) 1f else (TARGET / rms).coerceIn(1f, MAX_GAIN)
        }
        // smooth: never let gain jump by more than ~6 dB between neighbouring windows
        for (w in 1 until nw) gains[w] = min(gains[w], gains[w - 1] * 2f)
        for (w in nw - 2 downTo 0) gains[w] = min(gains[w], gains[w + 1] * 2f)
        for (i in x.indices) {
            val pos = (i - WIN / 2).toFloat() / WIN
            val w0 = pos.toInt().coerceIn(0, nw - 1)
            val w1 = (w0 + 1).coerceAtMost(nw - 1)
            val t = (pos - w0).coerceIn(0f, 1f)
            val g = gains[w0] + (gains[w1] - gains[w0]) * t
            var y = x[i] * g
            val ay = abs(y)
            if (ay > 0.9f) y = kotlin.math.sign(y) * (0.9f + 0.1f * kotlin.math.tanh((ay - 0.9f) / 0.1f))
            x[i] = y
        }
    }
}
