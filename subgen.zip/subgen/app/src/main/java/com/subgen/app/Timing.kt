package com.subgen.app

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

const val SR = 16000
const val FRAME = 160 // 10 ms

class PcmFile(val file: File, val samples: Long) {

    /** Loudness of every 10 ms frame, in dBFS. */
    fun frameDb(): FloatArray {
        val nf = (samples / FRAME).toInt()
        val out = FloatArray(nf)
        BufferedInputStream(FileInputStream(file), 1 shl 16).use { inp ->
            val b = ByteArray(FRAME * 2)
            var px = 0.0
            var py = 0.0
            for (f in 0 until nf) {
                var read = 0
                while (read < b.size) {
                    val r = inp.read(b, read, b.size - read)
                    if (r < 0) break
                    read += r
                }
                var sum = 0.0
                var i = 0
                while (i + 1 < read) {
                    val x = ((b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)).toShort() / 32768.0
                    val y = 0.944 * (py + x - px) // 150 Hz high-pass
                    px = x; py = y
                    sum += y * y
                    i += 2
                }
                out[f] = (10 * log10(sum / FRAME + 1e-10)).toFloat()
            }
        }
        return out
    }

    fun read(from: Long, to: Long): FloatArray {
        val a = from.coerceIn(0, samples)
        val b = to.coerceIn(a, samples)
        val n = (b - a).toInt()
        val bytes = ByteArray(n * 2)
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(a * 2)
            raf.readFully(bytes)
        }
        val out = FloatArray(n)
        for (i in 0 until n) {
            out[i] = ((bytes[2 * i].toInt() and 0xFF) or (bytes[2 * i + 1].toInt() shl 8)).toShort() / 32768f
        }
        return out
    }
}

/** Uses the audio's loudness to snap subtitle edges to where speech really starts and stops. */
class Energy(private val db: FloatArray, private val thr: Float) {
    val frames get() = db.size

    fun isSpeech(f: Int) = f in db.indices && db[f] > thr
    private fun speech(f: Int) = isSpeech(f)

    /** true if every frame in [a, b] that exists is below the threshold */
    private fun quiet(a: Int, b: Int): Boolean {
        for (f in max(0, a)..min(db.size - 1, b)) if (speech(f)) return false
        return true
    }

    fun firstSpeech(from: Int = 0): Int {
        for (f in from until db.size) if (speech(f) && speech(f + 1) && speech(f + 2)) return f
        return -1
    }

    fun hasSpeech(range: IntRange): Boolean {
        var c = 0
        for (f in range) if (speech(f)) { c++; if (c > 40) return true }
        return false
    }

    fun speechRatio(start: Double, end: Double): Double {
        val a = (start * 100).toInt().coerceIn(0, db.size)
        val b = (end * 100).toInt().coerceIn(a, db.size)
        if (b <= a) return 0.0
        var c = 0
        for (f in a until b) if (speech(f)) c++
        return c.toDouble() / (b - a)
    }

    /** Nearest silence->speech transition within ±0.3 s. */
    fun refineStart(t: Double): Double {
        val c = (t * 100).roundToInt()
        var best = -1
        var bestD = Int.MAX_VALUE
        for (f in (c - 30)..(c + 30)) {
            if (f < 1 || f + 2 >= db.size) continue
            // a real onset: >= 80 ms of quiet before it (short dips between syllables don't count)
            if (speech(f) && speech(f + 1) && quiet(f - 8, f - 1)) {
                // slightly prefer onsets before the model's estimate (subtitles should never lag)
                val d = if (f <= c) (c - f) else (f - c) * 3 / 2
                if (d < bestD) { bestD = d; best = f }
            }
        }
        return if (best >= 0) max(0.0, best / 100.0 - 0.05) else t
    }

    /** Nearest speech->silence transition within -0.3 s / +0.6 s. */
    fun refineEnd(t: Double): Double {
        val c = (t * 100).roundToInt()
        var best = -1
        var bestD = Int.MAX_VALUE
        for (f in (c - 30)..(c + 60)) {
            if (f < 1 || f >= db.size) continue
            // a real offset: >= 100 ms of quiet after it
            if (speech(f - 1) && quiet(f, f + 9)) {
                val d = abs(f - c)
                if (d < bestD) { bestD = d; best = f }
            }
        }
        return if (best >= 0) best / 100.0 + 0.12 else t
    }
}

/** A batch of speech-only audio pieces, processed together with short silences in between. */
class Chunk(val pieces: List<IntRange>) {
    val frames get() = pieces.sumOf { it.last - it.first + 1 }
}

/** Maps time in the packed (speech-only) audio back to time in the original video. */
class TimeMap {
    private val packedStart = ArrayList<Double>()
    private val origStart = ArrayList<Double>()
    private val len = ArrayList<Double>()

    fun add(packed: Double, orig: Double, length: Double) {
        packedStart.add(packed); origStart.add(orig); len.add(length)
    }

    fun map(t: Double): Double {
        if (packedStart.isEmpty()) return t
        var i = 0
        while (i + 1 < packedStart.size && packedStart[i + 1] <= t) i++
        return origStart[i] + (t - packedStart[i]).coerceIn(0.0, len[i])
    }
}

object Timing {
    /**
     * For sentence-level lines (translations): moves the sentence's edges to where speech really
     * starts/ends, then splits long sentences into lines at the real pauses, sharing the speech
     * (not the clock time) in proportion to text length.
     */
    fun alignSegment(c: Cue, energy: Energy): List<Cue> {
        val n = energy.frames
        if (n == 0) return CueBuilder.splitCue(c)
        fun sp(f: Int) = energy.isSpeech(f)
        val fs0 = (c.start * 100).roundToInt().coerceIn(0, n - 1)
        val fe0 = (c.end * 100).roundToInt().coerceIn(fs0, n - 1)

        // 1) edges
        fun quietRun(a: Int, b: Int): Boolean { for (q in max(0, a)..min(n - 1, b)) if (sp(q)) return false; return true }
        var fs = fs0
        if (!(sp(fs0) && sp(fs0 - 1) && sp(fs0 - 2))) {
            // model starts early (in quiet): move forward to where speech begins
            for (f in max(0, fs0 - 30) until fe0) if (sp(f) && sp(f + 1) && sp(f + 2)) { fs = f; break }
        } else {
            // model starts late (inside speech): look back up to 0.5 s for the real start
            for (f in fs0 downTo max(1, fs0 - 50)) if (sp(f) && quietRun(f - 8, f - 1)) { fs = f; break }
        }
        var fe = fe0
        if (!(sp(fe0) && sp(fe0 + 1) && sp(fe0 - 1))) {
            // model ends late (in quiet): move back to where speech ends
            for (f in min(n - 1, fe0 + 30) downTo fs + 1) if (sp(f) && sp(f - 1) && sp(f - 2)) { fe = f + 1; break }
        } else {
            // model ends early (inside speech): look ahead up to 0.5 s for the real end
            for (f in fe0..min(n - 2, fe0 + 50)) if (sp(f) && quietRun(f + 1, f + 10)) { fe = f + 1; break }
        }
        if (fe - fs < 20) { fs = fs0; fe = fe0 }   // no clear speech found: keep the model's times
        val start = max(0.0, fs / 100.0 - 0.05)
        val end = fe / 100.0 + 0.1

        val parts = CueBuilder.splitParts(c.text, end - start)
        if (parts.size <= 1) return listOf(Cue(start, end, c.text))

        // 2) cumulative speech time and pauses (>= 120 ms of quiet) inside the sentence
        val cum = IntArray(fe - fs + 1)
        for (i in 1..(fe - fs)) cum[i] = cum[i - 1] + if (sp(fs + i - 1)) 1 else 0
        val total = cum.last().coerceAtLeast(1)
        val pauses = ArrayList<IntRange>()
        var f = fs
        while (f < fe) {
            if (!sp(f)) {
                val a = f
                while (f < fe && !sp(f)) f++
                if (f - a >= 12 && a > fs) pauses.add(a until f)
            } else f++
        }

        val widths = parts.map { CueBuilder.displayLen(it).coerceAtLeast(1) }
        val wTotal = widths.sum().toDouble()
        val k = parts.size - 1
        // target frame of each split = where that share of the speech has been spoken
        val targets = IntArray(k)
        var acc = 0.0
        for (i in 0 until k) {
            acc += widths[i] / wTotal
            val ts = (acc * total).toInt()
            var tf = fs
            while (tf < fe && cum[tf - fs] < ts) tf++
            targets[i] = tf
        }
        // choose pauses for the splits: if there are enough, pick the ordered set that best fits all
        // targets together; otherwise give each pause to its nearest target (within 0.8 s)
        val chosen = arrayOfNulls<IntRange>(k)
        fun centre(r: IntRange) = (r.first + r.last) / 2
        if (pauses.size >= k) {
            val m = pauses.size
            val inf = Long.MAX_VALUE / 4
            val dp = Array(k + 1) { LongArray(m + 1) { inf } }
            for (j in 0..m) dp[0][j] = 0
            for (i in 1..k) for (j in i..m) {
                val take = dp[i - 1][j - 1] + abs(centre(pauses[j - 1]) - targets[i - 1])
                dp[i][j] = min(dp[i][j - 1], take)
            }
            var i = k; var j = m
            while (i > 0) {
                if (dp[i][j] == dp[i][j - 1]) j-- else { chosen[i - 1] = pauses[j - 1]; i--; j-- }
            }
        } else {
            val free = pauses.toMutableList()
            for (i in 0 until k) {
                val p = free.filter { abs(centre(it) - targets[i]) <= 80 }.minByOrNull { abs(centre(it) - targets[i]) }
                if (p != null) { chosen[i] = p; free.remove(p) }
            }
        }
        val out = ArrayList<Cue>()
        var curStart = start
        for (i in 0 until k) {
            val p = chosen[i]
            val (thisEnd, nextStart) = if (p != null && p.first / 100.0 > curStart) {
                (p.first / 100.0 + 0.1) to max(p.first / 100.0 + 0.1, (p.last + 1) / 100.0 - 0.05)
            } else (targets[i] / 100.0) to (targets[i] / 100.0)
            out.add(Cue(curStart, max(thisEnd, curStart + 0.3), parts[i]))
            curStart = max(nextStart, out.last().end)
        }
        out.add(Cue(curStart, max(end, curStart + 0.3), parts.last()))
        return out
    }

    /**
     * Finds the stretches that contain speech (with generous padding) and packs them into
     * batches of up to ~4.5 minutes, so the speech model never spends time on silence.
     */
    fun planSpeechChunks(db: FloatArray, energy: Energy): List<Chunk> {
        val regions = mutableListOf<IntRange>()
        var f = 0
        while (f < db.size) {
            if (energy.isSpeech(f)) {
                val s = f
                while (f < db.size && energy.isSpeech(f)) f++
                regions.add(s until f)
            } else f++
        }
        if (regions.isEmpty()) return emptyList()

        // Merge pauses shorter than 2 s, then pad 0.4 s on each side so no word gets clipped.
        val merged = mutableListOf<IntRange>()
        for (r in regions) {
            val last = merged.lastOrNull()
            if (last != null && r.first - last.last < 300) merged[merged.size - 1] = last.first..r.last
            else merged.add(r)
        }
        val padded = mutableListOf<IntRange>()
        for (r in merged) {
            if (r.last - r.first < 4) continue // clicks, not speech
            val a = max(0, r.first - 60)
            val b = min(db.size - 1, r.last + 60)
            val last = padded.lastOrNull()
            if (last != null && a <= last.last + 1) padded[padded.size - 1] = last.first..b
            else padded.add(a..b)
        }

        // Very long continuous regions are split at their quietest point.
        val pieces = mutableListOf<IntRange>()
        for (r in padded) {
            if (r.last - r.first + 1 <= 30000) { pieces.add(r); continue }
            for (sub in planChunks(db.copyOfRange(r.first, r.last + 1))) {
                pieces.add((sub.first + r.first)..(sub.last + r.first))
            }
        }

        // The first batch is kept to about a minute of speech, so the first subtitles can be
        // checked ("Watch so far" / the "first minute ready" notification) a minute or two in,
        // instead of only after a full ~4.5 minute batch. A long first stretch of talk is cut at
        // its quietest moment near the 1-minute mark (the same way 5-minute stretches are cut).
        val p0 = pieces.firstOrNull()
        if (p0 != null && p0.last - p0.first + 1 > FIRST_BATCH + 1500) {
            val cut = quietCut(db, p0.first + FIRST_BATCH - 1500, p0.first + FIRST_BATCH)
            pieces[0] = p0.first until cut
            pieces.add(1, cut..p0.last)
        }

        val chunks = mutableListOf<Chunk>()
        var cur = mutableListOf<IntRange>()
        var size = 0
        for (p in pieces) {
            val n = p.last - p.first + 1
            val limit = if (chunks.isEmpty()) FIRST_BATCH else 27000
            if (cur.isNotEmpty() && size + n > limit) {
                chunks.add(Chunk(cur)); cur = mutableListOf(); size = 0
            }
            cur.add(p); size += n + 30
        }
        if (cur.isNotEmpty()) chunks.add(Chunk(cur))
        return chunks
    }

    fun threshold(db: FloatArray): Float {
        if (db.isEmpty()) return -45f
        val s = db.copyOf()
        s.sort()
        val floor = s[(s.size * 0.10).toInt().coerceIn(0, s.size - 1)]
        // Only ~6 dB above the background noise counts as possible speech, so murmurs are kept.
        return (floor + 6f).coerceIn(-62f, -38f)
    }

    /** Speech in the first batch (frames of 10 ms): about one minute. */
    const val FIRST_BATCH = 6000

    /** The quietest 0.3 s moment between frames [from, to): where it is safe to cut. */
    fun quietCut(db: FloatArray, from: Int, to: Int): Int {
        var bestCut = to
        var bestVal = Float.MAX_VALUE
        var f = max(0, from)
        while (f < to) {
            var sum = 0f
            for (k in f until min(f + 30, db.size)) sum += db[k]
            if (sum < bestVal) { bestVal = sum; bestCut = f + 15 }
            f += 5
        }
        return bestCut
    }

    /** Splits audio into ~5 minute chunks, cutting at the quietest moment near each boundary. */
    fun planChunks(db: FloatArray): List<IntRange> {
        val chunk = 30000
        val out = mutableListOf<IntRange>()
        var s = 0
        while (s < db.size) {
            if (db.size - s <= chunk + 3000) {
                out.add(s until db.size); break
            }
            val bestCut = quietCut(db, s + chunk - 3000, s + chunk)
            out.add(s until bestCut)
            s = bestCut
        }
        return out
    }

    /**
     * Why lines were removed in the last finalize() call (written to the run log). Pass [stats] to
     * get them for one call only: "Watch so far" also runs finalize() and would overwrite this.
     */
    @Volatile var lastStats: String = ""

    fun finalize(input: List<Cue>, energy: Energy, stats: StringBuilder? = null): List<Cue> {
        var list = input.map { it.copy(text = CueBuilder.clean(it.text)) }
            .filter { it.text.isNotBlank() && !CueBuilder.isAnnotation(it.text) }
            .sortedBy { it.start }
            .toMutableList()
        val nEmpty = input.size - list.size

        for (c in list) {
            val s = energy.refineStart(c.start)
            val e = energy.refineEnd(c.end)
            c.start = s
            c.end = max(e, s + 0.2)
        }
        list.sortBy { it.start }

        // Drop lines that sit on silence (typical hallucinations).
        val beforeSilence = list.size
        list = list.filter { energy.speechRatio(it.start, it.end) >= 0.03 }.toMutableList()
        val nSilence = beforeSilence - list.size
        var nMerged = 0; var nRecent = 0; var nThird = 0
        val dropped = HashMap<String, Int>()

        // Drop repetition loops:
        //  - a line identical to the previous one shortly after it is merged into it;
        //  - a line (6+ letters) that already appeared in the last 3 lines within 12 s is dropped;
        //  - any line appearing a 3rd time within 30 s is dropped.
        val dedup = mutableListOf<Cue>()
        for (c in list) {
            val key = CueBuilder.sameKey(c.text)
            if (key.isEmpty()) { dedup.add(c); continue }
            val prev = dedup.lastOrNull()
            if (prev != null && CueBuilder.sameKey(prev.text) == key && c.start - prev.end < 1.5) {
                prev.end = max(prev.end, c.end)
                nMerged++
                continue
            }
            val recent = dedup.takeLast(3).filter { c.start - it.start < 12 }
            if (key.length >= 6 && recent.any { CueBuilder.sameKey(it.text) == key }) {
                nRecent++; dropped[c.text] = (dropped[c.text] ?: 0) + 1; continue
            }
            val window = dedup.filter { c.start - it.start < 30 && CueBuilder.sameKey(it.text) == key }
            if (window.size >= 2) { nThird++; dropped[c.text] = (dropped[c.text] ?: 0) + 1; continue }
            dedup.add(c)
        }
        list = dedup
        val top = dropped.entries.sortedByDescending { it.value }.take(3)
            .joinToString("; ") { "\"${it.key.take(30)}\" x${it.value}" }
        val st = "removed: $nEmpty empty/sound-tags, $nSilence over silence, $nMerged merged into an identical " +
            "line just before, $nRecent repeated within 12 s, $nThird 3rd repeat within 30 s" +
            (if (top.isNotEmpty()) " | most repeated: $top" else "")
        lastStats = st
        stats?.append(st)

        for (i in list.indices) {
            val c = list[i]
            val next = list.getOrNull(i + 1)
            val minDur = max(0.9, min(3.0, CueBuilder.displayLen(c.text) * 0.045))
            if (c.end - c.start < minDur) c.end = c.start + minDur
            if (next != null) {
                if (next.start <= c.start) next.start = c.start + 0.05
                if (c.end > next.start - 0.03) c.end = max(c.start + 0.2, next.start - 0.03)
                // close tiny gaps so text doesn't flicker
                if (next.start - c.end < 0.25) c.end = max(c.start + 0.2, next.start - 0.03)
            }
        }
        return list
    }
}

/**
 * Raises quiet passages (murmurs, background voices) toward normal speech loudness before
 * recognition, without boosting pure silence. Gain is limited to +16 dB and smoothed.
 */
object Leveler {
    private const val WIN = 6400 // 0.4 s
    private const val TARGET = 0.08f // about -22 dBFS
    private const val MAX_GAIN = 6.3f // +16 dB

    /**
     * gateDb: the video's own speech threshold (a few dB above its background noise).
     * Windows quieter than that are left alone, so room tone and hiss are not amplified.
     */
    fun apply(x: FloatArray, gateDb: Float) {
        val gate = Math.pow(10.0, (gateDb + 3f) / 20.0).toFloat()
        if (x.isEmpty()) return
        val nw = (x.size + WIN - 1) / WIN
        val gains = FloatArray(nw)
        for (w in 0 until nw) {
            val a = w * WIN
            val b = min(x.size, a + WIN)
            var sum = 0.0
            for (i in a until b) sum += (x[i] * x[i]).toDouble()
            val rms = kotlin.math.sqrt(sum / (b - a)).toFloat()
            gains[w] = if (rms < gate) 1f else (TARGET / rms).coerceIn(1f, MAX_GAIN)
        }
        // smooth: never let gain jump by more than ~6 dB between neighbouring windows
        for (w in 1 until nw) gains[w] = min(gains[w], gains[w - 1] * 2f)
        for (w in nw - 2 downTo 0) gains[w] = min(gains[w], gains[w + 1] * 2f)
        for (i in x.indices) {
            val pos = (i - WIN / 2).toFloat() / WIN
            val w0 = pos.toInt().coerceIn(0, nw - 1)
            val w1 = (w0 + 1).coerceAtMost(nw - 1)
            val t = (pos - w0).coerceIn(0f, 1f)
            val g = gains[w0] + (gains[w1] - gains[w0]) * t
            var y = x[i] * g
            val ay = abs(y)
            if (ay > 0.9f) y = kotlin.math.sign(y) * (0.9f + 0.1f * kotlin.math.tanh((ay - 0.9f) / 0.1f))
            x[i] = y
        }
    }
}
