package com.subgen.app

interface ProgressCb {
    fun onProgress(p: Int)
}

object WhisperLib {
    init {
        System.loadLibrary("subgen")
    }

    /** kind: 0 = base model, 1 = small model */
    @JvmStatic external fun nInit(path: String, kind: Int): Long
    @JvmStatic external fun nFree(ctx: Long)
    @JvmStatic external fun nSetLogFile(path: String)
    @JvmStatic external fun nBenchEncode(ctx: Long, samples: FloatArray, threads: IntArray): LongArray
    @JvmStatic external fun nSetAbort(v: Boolean)
    @JvmStatic external fun nDetectLang(ctx: Long, samples: FloatArray, threads: Int): String
    @JvmStatic external fun nTranscribe(
        ctx: Long, samples: FloatArray, lang: String, translate: Boolean,
        threads: Int, prompt: String?, cb: ProgressCb?
    ): ByteArray?
}
