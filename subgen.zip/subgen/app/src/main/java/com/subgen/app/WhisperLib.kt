package com.subgen.app

interface ProgressCb {
    fun onProgress(p: Int)
    /** A finished segment: times in centiseconds (within the batch), UTF-8 text bytes. */
    fun onSegment(t0: Long, t1: Long, text: ByteArray) {}
}

object WhisperLib {
    init {
        System.loadLibrary("subgen")
    }

    /** kind: 0 = base model, 1 = small model */
    @JvmStatic external fun nInit(path: String, kind: Int): Long
    @JvmStatic external fun nFree(ctx: Long)
    @JvmStatic external fun nSetLogFile(path: String)
    @JvmStatic external fun nBenchEncode(ctx: Long, samples: FloatArray, threads: IntArray): LongArray
    @JvmStatic external fun nSetAbort(v: Boolean)
    @JvmStatic external fun nDetectLang(ctx: Long, samples: FloatArray, threads: Int): String
    @JvmStatic external fun nTranscribe(
        ctx: Long, samples: FloatArray, lang: String, translate: Boolean,
        threads: Int, prompt: String?, cb: ProgressCb?, careful: Int
    ): ByteArray?
}
