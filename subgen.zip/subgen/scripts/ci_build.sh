#!/usr/bin/env bash
# Full build, run by GitHub Actions after it unzips subgen.zip.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "::group::whisper.cpp"
rm -rf third_party/whisper.cpp
git clone --depth 1 --branch v1.7.6 https://github.com/ggml-org/whisper.cpp third_party/whisper.cpp
echo "::endgroup::"

echo "::group::Android NDK"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses > /dev/null || true
"$SDKM" "ndk;27.2.12479018" "cmake;3.22.1" "platforms;android-35" "build-tools;35.0.0" > /dev/null
echo "::endgroup::"

echo "::group::Models"
python3 -m venv /tmp/venv
/tmp/venv/bin/pip install -q sentencepiece
PATH="/tmp/venv/bin:$PATH" bash scripts/prepare_assets.sh
echo "::endgroup::"

gradle assembleRelease --no-daemon --stacktrace

mkdir -p dist
APK="dist/SubGen-${GITHUB_RUN_NUMBER:-local}.apk"
cp app/build/outputs/apk/release/app-release.apk "$APK"
ls -la dist

if [ -n "${GH_TOKEN:-}" ]; then
  gh release create "build-${GITHUB_RUN_NUMBER}" "$APK" \
    --repo "$GITHUB_REPOSITORY" \
    --title "SubGen build ${GITHUB_RUN_NUMBER}" \
    --notes "Open this page on your Android phone, download the .apk and tap it to install."
fi
