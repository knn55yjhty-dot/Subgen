#!/usr/bin/env bash
# Full build, run by GitHub Actions after it unzips subgen.zip.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "::group::whisper.cpp"
rm -rf third_party/whisper.cpp
git clone --depth 1 --branch v1.7.6 https://github.com/ggml-org/whisper.cpp third_party/whisper.cpp
echo "::endgroup::"

echo "::group::Android NDK"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
yes | "$SDKM" --licenses > /dev/null || true
"$SDKM" "ndk;27.2.12479018" "cmake;3.22.1" "platforms;android-35" "build-tools;35.0.0" > /dev/null
echo "::endgroup::"

echo "::group::Models"
python3 -m venv /tmp/venv
/tmp/venv/bin/pip install -q sentencepiece
PATH="/tmp/venv/bin:$PATH" bash scripts/prepare_assets.sh
echo "::endgroup::"

gradle assembleRelease --no-daemon --stacktrace

mkdir -p dist
APK="dist/SubGen-${GITHUB_RUN_NUMBER:-local}.apk"
cp app/build/outputs/apk/release/app-release.apk "$APK"
ls -la dist

# ---------- Robot tester: the same app, built for the virtual phone (x86_64), used like a person would ----------
ROBOT=dist/robot
set +e
echo "::group::Test build for the virtual phone"
SUBGEN_TEST_ABI=1 gradle assembleDebug --no-daemon --stacktrace
TB=$?
echo "::endgroup::"
if [ $TB -eq 0 ]; then
  sudo rm -rf /usr/share/dotnet /opt/ghc /usr/local/share/boost /usr/local/lib/node_modules > /dev/null 2>&1
  bash scripts/test/device_test.sh app/build/outputs/apk/debug/app-debug.apk "$ROBOT"
  RC=$?
else
  mkdir -p "$ROBOT"; printf 'VERDICT: TEST COULD NOT RUN\nreason: the test build failed\n' > "$ROBOT/report.txt"; RC=2
fi
set -e
cp "$ROBOT/report.txt" dist/test_report.txt
( cd "$ROBOT" && zip -qr ../robot_details.zip . -x 'media/*' ) || true
{ echo '```'; cat dist/test_report.txt; echo '```'; } >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
echo "robot result: $RC"; head -20 dist/test_report.txt

if [ -n "${GH_TOKEN:-}" ]; then
  TAG="build-${GITHUB_RUN_NUMBER}"
  VERDICT=$(head -1 dist/test_report.txt | sed 's/^VERDICT: //')
  {
    if [ $RC -eq 1 ]; then
      echo "**Robot test: ${VERDICT}. Don't install this build** (it is kept off the \"latest\" link)."
    else
      echo "Open this page on your Android phone, download the .apk and tap it to install."
      echo
      echo "**Robot test: ${VERDICT}**"
    fi
    echo
    echo '```'
    sed -n '1,/^$/p' dist/test_report.txt
    echo '```'
    echo "Full report: test_report.txt below. Screenshots and subtitle files: robot_details.zip."
  } > dist/notes.md
  FILES=("$APK" dist/test_report.txt)
  [ -f dist/robot_details.zip ] && FILES+=(dist/robot_details.zip)
  PRE=(); [ $RC -eq 1 ] && PRE=(--prerelease)
  if gh release view "$TAG" --repo "$GITHUB_REPOSITORY" > /dev/null 2>&1; then
    # re-run of the same build: replace the files instead of failing
    gh release upload "$TAG" "${FILES[@]}" --clobber --repo "$GITHUB_REPOSITORY"
    gh release edit "$TAG" --notes-file dist/notes.md --repo "$GITHUB_REPOSITORY" --prerelease=$([ $RC -eq 1 ] && echo true || echo false)
  else
    gh release create "$TAG" "${FILES[@]}" \
      --repo "$GITHUB_REPOSITORY" \
      --title "SubGen build ${GITHUB_RUN_NUMBER}" \
      --notes-file dist/notes.md "${PRE[@]}"
  fi
fi
