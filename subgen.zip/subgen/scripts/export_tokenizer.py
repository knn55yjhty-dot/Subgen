"""Converts the Marian SentencePiece model + vocab into simple TSV files the app can read."""
import json
import os
import sys

import sentencepiece as spm

src, out = sys.argv[1], sys.argv[2]
sp = spm.SentencePieceProcessor(model_file=os.path.join(src, "source.spm"))
with open(os.path.join(out, "src_pieces.tsv"), "w", encoding="utf-8") as f:
    for i in range(sp.get_piece_size()):
        if sp.is_unknown(i) or sp.is_control(i):
            continue
        p = sp.id_to_piece(i)
        if "\t" in p or "\n" in p:
            continue
        f.write(f"{p}\t{sp.get_score(i)}\n")

vocab = json.load(open(os.path.join(src, "vocab.json"), encoding="utf-8"))
tv_path = os.path.join(src, "target_vocab.json")
tvocab = json.load(open(tv_path, encoding="utf-8")) if os.path.exists(tv_path) else vocab


def dump(v, name):
    with open(os.path.join(out, name), "w", encoding="utf-8") as f:
        for k, i in v.items():
            if "\t" in k or "\n" in k:
                continue
            f.write(f"{k}\t{i}\n")


dump(vocab, "src_vocab.tsv")
dump(tvocab, "tgt_vocab.tsv")

cfg = json.load(open(os.path.join(src, "config.json"), encoding="utf-8"))
pad = cfg.get("pad_token_id", vocab.get("<pad>"))
meta = {
    "pad": pad,
    "eos": cfg.get("eos_token_id", vocab.get("</s>", 0)),
    "unk": vocab.get("<unk>", 1),
    "start": cfg.get("decoder_start_token_id", pad),
    "lang": vocab.get(">>cmn_Hans<<", -1),
}
with open(os.path.join(out, "meta.properties"), "w") as f:
    for k, v in meta.items():
        f.write(f"{k}={v}\n")
print("tokenizer meta:", meta, "pieces:", sp.get_piece_size(), "vocab:", len(vocab), "target vocab:", len(tvocab))
