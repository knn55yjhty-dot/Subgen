#!/usr/bin/env bash
# Downloads the offline models into app/src/main/assets/models (run by the GitHub build).
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=app/src/main/assets/models
mkdir -p "$OUT/mt" /tmp/mt
HF=https://huggingface.co

dl() { # url dest
  if [ ! -s "$2" ]; then
    echo "Downloading $1"
    curl -L --fail --retry 5 --retry-delay 5 -o "$2.part" "$1"
    mv "$2.part" "$2"
  fi
}

# Speech recognition (whisper.cpp, quantised)
dl "$HF/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin" "$OUT/ggml-small-q5_1.bin"
dl "$HF/ggerganov/whisper.cpp/resolve/main/ggml-base-q5_1.bin"  "$OUT/ggml-base-q5_1.bin"

# English -> Chinese translation (OPUS-MT, int8 ONNX)
dl "$HF/Xenova/opus-mt-en-zh/resolve/main/onnx/encoder_model_quantized.onnx" "$OUT/mt/encoder.onnx"
dl "$HF/Xenova/opus-mt-en-zh/resolve/main/onnx/decoder_model_quantized.onnx" "$OUT/mt/decoder.onnx"
for f in source.spm vocab.json config.json tokenizer_config.json; do
  dl "$HF/Helsinki-NLP/opus-mt-en-zh/resolve/main/$f" "/tmp/mt/$f"
done
curl -L --fail -s -o /tmp/mt/target_vocab.json "$HF/Helsinki-NLP/opus-mt-en-zh/resolve/main/target_vocab.json" || rm -f /tmp/mt/target_vocab.json

python3 -I scripts/export_tokenizer.py /tmp/mt "$OUT/mt"
ls -la "$OUT" "$OUT/mt"
