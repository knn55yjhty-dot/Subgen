#!/usr/bin/env bash
# Robot tester, run by GitHub Actions after the app is built.
#   device_test.sh TEST_APK OUT_DIR
# Starts a virtual Android 15 phone, installs the test build and runs robot.py.
# Exit: 0 = no crash, 1 = crash / failed video, 2 = the test itself could not run.
set -uo pipefail
cd "$(dirname "$0")/../.."
APK="$1"; OUT="$2"
mkdir -p "$OUT"
REPORT="$OUT/report.txt"
cant() { printf 'VERDICT: TEST COULD NOT RUN\nreason: %s\n' "$*" > "$REPORT"; echo "robot: could not run: $*"; exit 2; }

echo "::group::Robot: tools and test videos"
sudo apt-get update -qq > /dev/null 2>&1
sudo apt-get install -y -qq espeak-ng ffmpeg > /dev/null 2>&1 || cant "could not install espeak-ng / ffmpeg"
python3 -I scripts/test/gen_media.py "$OUT/media" || cant "could not make the test videos"
echo "::endgroup::"

echo "::group::Robot: virtual phone"
echo 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules > /dev/null
sudo udevadm control --reload-rules && sudo udevadm trigger --name-match=kvm
[ -e /dev/kvm ] || cant "this GitHub machine has no hardware virtualisation (KVM)"
SDKM="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
AVDM="$ANDROID_HOME/cmdline-tools/latest/bin/avdmanager"
IMG="system-images;android-35;google_apis;x86_64"
yes | "$SDKM" --licenses > /dev/null 2>&1 || true
"$SDKM" "emulator" "platform-tools" "$IMG" > /dev/null || cant "could not download the Android 15 system image"
export PATH="$ANDROID_HOME/platform-tools:$ANDROID_HOME/emulator:$PATH"
echo no | "$AVDM" create avd -n robot -k "$IMG" -d pixel_6 --force > /dev/null || cant "could not create the virtual phone"
emulator -avd robot -no-window -no-audio -no-boot-anim -no-snapshot -gpu swiftshader_indirect \
  -memory 4096 -cores 4 -partition-size 8192 -camera-back none -camera-front none > "$OUT/emulator.log" 2>&1 &
timeout 300 adb wait-for-device || cant "virtual phone did not start"
for i in $(seq 1 120); do
  [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = "1" ] && break
  sleep 5
done
[ "$(adb shell getprop sys.boot_completed | tr -d '\r')" = "1" ] || cant "virtual phone did not finish starting in 10 minutes"
adb shell settings put global window_animation_scale 0
adb shell settings put global transition_animation_scale 0
adb shell settings put global animator_duration_scale 0
adb shell input keyevent 82
adb shell svc power stayon true
echo "::endgroup::"

echo "::group::Robot: install"
adb install -r -g "$APK" > "$OUT/install.log" 2>&1 || { cat "$OUT/install.log"; cant "the test build would not install: $(tail -1 "$OUT/install.log")"; }
adb logcat -c; adb logcat -b crash -c
echo "::endgroup::"

echo "::group::Robot: testing"
python3 -I scripts/test/robot.py "$OUT/media" "$OUT"
code=$?
adb logcat -d -t 3000 > "$OUT/logcat.txt" 2>/dev/null || true
echo "::endgroup::"
[ -s "$REPORT" ] || cant "the robot stopped unexpectedly (exit $code)"
exit $code
