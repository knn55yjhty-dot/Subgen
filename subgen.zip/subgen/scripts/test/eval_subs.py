#!/usr/bin/env python3
"""
Grades one subtitle file from the app against the true sentence times of a test video.

  eval_subs.py CLIP.json SUBS.srt [RUN_LOG.txt]   -> prints a report block; exit 0 ok, 1 problems

Checks: every sentence got a subtitle; how early/late subtitles start and end; subtitles shown
over silence; repeated lines; right language/script; for English->English, word accuracy.
"""
import json, re, sys, unicodedata

TOL_START_AVG, TOL_START_WORST = 0.40, 1.20     # seconds
MAX_WER = 0.35                                  # synthetic voice; real speech scores better


def parse_srt(text):
    cues = []
    for block in re.split(r"\n\s*\n", text.replace("\r", "").strip()):
        lines = block.split("\n")
        for i, l in enumerate(lines):
            m = re.match(r"(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)", l)
            if m:
                g = list(map(int, m.groups()))
                s = g[0] * 3600 + g[1] * 60 + g[2] + g[3] / 1000
                e = g[4] * 3600 + g[5] * 60 + g[6] + g[7] / 1000
                cues.append({"start": s, "end": e, "text": " ".join(lines[i + 1:]).strip()})
                break
    return cues


def is_cjk(ch):
    return "CJK" in unicodedata.name(ch, "")


def words(t):
    return re.findall(r"[a-z0-9']+", t.lower())


def wer(ref, hyp):
    r, h = words(ref), words(hyp)
    if not r:
        return 0.0
    d = list(range(len(h) + 1))
    for i in range(1, len(r) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(h) + 1):
            cur = min(d[j] + 1, d[j - 1] + 1, prev + (r[i - 1] != h[j - 1]))
            prev, d[j] = d[j], cur
    return d[len(h)] / len(r)


def grade(meta, cues, log=""):
    refs = meta["sentences"]
    out, problems = [], []
    # cue -> sentence it overlaps most (cues may split one sentence into several lines)
    def overlap(c, r, pad=0.0):
        return max(0.0, min(c["end"], r["end"] + pad) - max(c["start"], r["start"] - pad))
    owner = []
    for c in cues:
        best = max(range(len(refs)), key=lambda k: overlap(c, refs[k], 0.3)) if refs else -1
        owner.append(best if best >= 0 and overlap(c, refs[best], 0.3) > 0 else -1)
    start_err, end_err, missed = [], [], []
    for k, r in enumerate(refs):
        mine = [c for c, o in zip(cues, owner) if o == k]
        if not mine:
            missed.append(k)
            continue
        start_err.append(mine[0]["start"] - r["start"])
        end_err.append(mine[-1]["end"] - r["end"])
    over_silence = [c for c, o in zip(cues, owner) if o < 0]
    keys = [re.sub(r"\W", "", c["text"].lower()) for c in cues]
    repeats = sum(1 for i in range(1, len(keys)) if keys[i] and keys[i] == keys[i - 1])
    repeats += sum(max(0, keys.count(k) - 2) for k in set(keys) if k)

    found = len(refs) - len(missed)
    out.append("sentences with a subtitle: %d of %d" % (found, len(refs)))
    for k in missed:
        r = refs[k]
        tag = " (the quiet murmur line)" if r.get("quiet") else ""
        out.append("  MISSED %.1f-%.1f s%s: %s" % (r["start"], r["end"], tag, r["text"]))
        if not r.get("quiet"):
            problems.append("missed a sentence")
    if start_err:
        a = sum(abs(e) for e in start_err) / len(start_err)
        w = max(start_err, key=abs)
        ea = sum(abs(e) for e in end_err) / len(end_err)
        out.append("subtitle start vs speech: average %.2f s off, worst %+.2f s (+ = late)" % (a, w))
        out.append("subtitle end vs speech:   average %.2f s off" % ea)
        if a > TOL_START_AVG or abs(w) > TOL_START_WORST:
            problems.append("timing off (avg %.2f s, worst %+.2f s)" % (a, w))
    out.append("lines shown over silence: %d" % len(over_silence))
    for c in over_silence[:3]:
        out.append("  over silence %.1f-%.1f s: %s" % (c["start"], c["end"], c["text"][:60]))
    if over_silence:
        problems.append("%d line(s) over silence" % len(over_silence))
    out.append("repeated lines: %d" % repeats)
    if repeats:
        problems.append("repeated lines")
    text = " ".join(c["text"] for c in cues)
    letters = [ch for ch in text if ch.isalpha()]
    cjk = sum(1 for ch in letters if is_cjk(ch)) / max(1, len(letters))
    tgt = meta["target"] if meta["target"] != "orig" else meta["src"]
    if tgt == "zh":
        out.append("Chinese characters in subtitles: %d%%" % round(cjk * 100))
        if cjk < 0.8:
            problems.append("subtitles are not in Chinese")
    elif tgt == "en":
        out.append("English letters in subtitles: %d%%" % round((1 - cjk) * 100))
        if cjk > 0.2:
            problems.append("subtitles are not in English")
    if meta["src"] == "en" and meta["target"] in ("orig", "en"):
        w = wer(" ".join(r["text"] for r in refs if not r.get("quiet")),
                " ".join(c["text"] for c, o in zip(cues, owner) if o < 0 or not refs[o].get("quiet")))
        out.append("word accuracy: %d%% (word error rate %.2f)" % (round((1 - min(1, w)) * 100), w))
        if w > MAX_WER:
            problems.append("too many wrong words (%.0f%%)" % (w * 100))
    for key in ("transcription took", "lines:", "removed:", "translated", "fast translation path unavailable", "translation failed"):
        for l in log.splitlines():
            if key in l:
                out.append("log: " + l.strip()[:160])
                break
    return out, list(dict.fromkeys(problems))


if __name__ == "__main__":
    meta = json.load(open(sys.argv[1], encoding="utf-8"))
    cues = parse_srt(open(sys.argv[2], encoding="utf-8").read())
    log = open(sys.argv[3], encoding="utf-8", errors="replace").read() if len(sys.argv) > 3 else ""
    lines, problems = grade(meta, cues, log)
    print("\n".join(lines))
    print("RESULT: " + ("OK" if not problems else "PROBLEMS: " + "; ".join(problems)))
    sys.exit(1 if problems else 0)
