#!/usr/bin/env python3
"""
Makes the robot tester's videos: synthetic speech placed at exactly known times, so the app's
subtitles can be checked against the truth (timing, missed lines, lines over silence, repeats).

  gen_media.py OUT_DIR        -> OUT_DIR/<clip>.mp4 + OUT_DIR/<clip>.json (true sentence times)

Uses espeak-ng for speech and ffmpeg to make the video. Pure Python otherwise (no numpy).
"""
import json, os, random, shutil, struct, subprocess, sys, wave

RATE = 22050

# A longer talk (about 2 minutes of speech), so the job has several batches and the early
# "First minute ready" check can be tested while the rest is still being made. Runs first.
_TALK = [
    "Welcome back to our weekly science show.", "Today we visit a small farm in the hills.",
    "The farmer grows apples, pears and plums.", "Every morning she checks the trees before sunrise.",
    "Last winter was very cold and very dry.", "Many young trees did not survive the frost.",
    "So this spring she planted two hundred new ones.", "She also built a pond to collect rain water.",
    "Ducks and frogs moved in within a few weeks.", "Now the children from the village come to visit.",
    "They learn how fruit grows from flower to harvest.", "In the afternoon we tasted fresh apple juice.",
    "It was sweet, cold and a little bit sour.", "Next we drove to the old mill by the river.",
    "The mill is more than one hundred years old.", "It still grinds flour for the local bakery.",
    "The baker opens his shop at five in the morning.", "His bread is famous in the whole region.",
    "People travel for hours to buy a loaf.", "We asked him for the secret of his recipe.",
    "He laughed and said patience is the only secret.", "The dough rests for a full day before baking.",
    "After that we went back to the studio.", "Next week we will talk about bees and honey.",
    "Thank you for watching, and see you soon.",
]
_GAPS = [1.5, 0.6, 1.2, 0.4, 2.5, 0.8, 0.5, 1.8, 0.7, 3.0, 0.6, 1.1, 0.4, 2.2, 0.9, 0.5, 1.4, 0.6, 0.8, 2.0, 0.5, 1.0, 3.5, 0.7, 1.2]

CLIPS = [
    ("a_long_en_to_zh", "en-us", "en", "zh", False, -48, [(t, g, 1.0) for t, g in zip(_TALK, _GAPS)]),
    # name, voice, source language, target, accurate, noise dBFS, sentences (text, gap_before_s, gain)
    ("en_to_zh", "en-us", "en", "zh", False, -48, [
        ("Good morning, everyone. Thank you for coming today.", 2.0, 1.0),
        ("We will talk about the new train station near the river.", 0.8, 1.0),
        ("The building work starts next month and takes two years.", 1.5, 1.0),
        ("Some roads will close at night.", 6.0, 1.0),          # long silence before: no subtitle may sit in it
        ("Buses will run every ten minutes instead.", 0.5, 1.0),
        ("If you have questions, please write to the city office.", 0.35, 1.0),  # almost no pause
        ("Thank you, and have a nice day.", 2.5, 1.0),
    ]),
    ("en_noisy", "en-us", "en", "orig", True, -32, [
        ("I left my keys in the kitchen this morning.", 1.5, 1.0),
        ("Did you see them anywhere?", 1.2, 1.0),
        ("Maybe they are under the newspaper.", 2.0, 0.18),     # quiet murmur, about 15 dB softer
        ("No, I already looked there twice.", 1.0, 1.0),
        ("Let me check the car before we leave.", 3.0, 1.0),
        ("Found them! They were in my coat pocket.", 1.0, 1.0),
    ]),
    ("zh_to_en", "cmn", "zh", "en", False, -48, [
        ("大家好，欢迎来到今天的节目。", 1.5, 1.0),
        ("今天我们要介绍一家新的餐厅。", 1.0, 1.0),
        ("这家餐厅的面条非常好吃。", 2.0, 1.0),
        ("价格也很便宜。", 4.0, 1.0),
        ("我们下次再见。", 1.2, 1.0),
    ]),
]


def speak(voice, text, path):
    if shutil.which("espeak-ng"):
        subprocess.run(["espeak-ng", "-v", voice, "-s", "150", "-w", path, text], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        with wave.open(path) as w:
            assert w.getsampwidth() == 2 and w.getnchannels() == 1
            rate = w.getframerate()
            x = list(struct.unpack("<%dh" % w.getnframes(), w.readframes(w.getnframes())))
        if rate != RATE:  # simple linear resample
            n = int(len(x) * RATE / rate)
            x = [x[min(len(x) - 1, int(i * rate / RATE))] for i in range(n)]
        return x
    # Fallback for checking this script without espeak: a tone burst as long as the text.
    import math
    n = int(RATE * (0.25 + 0.07 * len(text)))
    return [int(8000 * math.sin(2 * math.pi * 220 * i / RATE) * (0.6 + 0.4 * math.sin(i / 900))) for i in range(n)]


def trim(x, thr=300):
    a = next((i for i, v in enumerate(x) if abs(v) > thr), 0)
    b = len(x) - next((i for i, v in enumerate(reversed(x)) if abs(v) > thr), 0)
    return x[a:b]


def build(out_dir, clip):
    name, voice, src, target, accurate, noise_db, sents = clip
    rnd = random.Random(name)
    track, refs = [], []
    tmp = os.path.join(out_dir, "_s.wav")
    for text, gap, gain in sents:
        track += [0] * int(gap * RATE)
        x = trim(speak(voice, text, tmp))
        start = len(track) / RATE
        track += [int(v * gain) for v in x]
        refs.append({"start": round(start, 3), "end": round(len(track) / RATE, 3), "text": text, "quiet": gain < 0.5})
    track += [0] * int(2.0 * RATE)
    if os.path.exists(tmp):
        os.remove(tmp)
    sigma = 32767 * 10 ** (noise_db / 20)
    track = [max(-32767, min(32767, int(v + rnd.gauss(0, sigma)))) for v in track]
    wav = os.path.join(out_dir, name + ".wav")
    with wave.open(wav, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE)
        w.writeframes(struct.pack("<%dh" % len(track), *track))
    mp4 = os.path.join(out_dir, name + ".mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error",
                    "-f", "lavfi", "-i", "testsrc=size=640x360:rate=25",
                    "-i", wav, "-shortest", "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-ar", "44100", "-b:a", "96k", mp4], check=True)
    os.remove(wav)
    meta = {"name": name, "src": src, "target": target, "accurate": accurate,
            "duration": round(len(track) / RATE, 3), "sentences": refs}
    with open(os.path.join(out_dir, name + ".json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    print("made %s: %.1f s, %d sentences" % (mp4, meta["duration"], len(refs)))


if __name__ == "__main__":
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    for c in CLIPS:
        build(out, c)
