#!/usr/bin/env python3
"""
SubGen robot tester: drives the real app on a virtual Android phone (adb), the way a person would.

  robot.py MEDIA_DIR OUT_DIR      (emulator already booted, test APK installed)

1. Queues each test video through the app's normal queue + background service.
2. While it works, opens the Generate screen and checks what it says.
3. Grades every finished subtitle file against the true speech times (eval_subs.py).
4. Taps through Library, viewer, player, rotation, select / delete, and Generate.
5. After every step: did the app crash or freeze?
Writes OUT_DIR/report.txt. Exit 0 = no crash, 1 = crash or a video failed.
"""
import glob, json, os, re, subprocess, sys, time, urllib.parse
import xml.etree.ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eval_subs

PKG = "com.subgen.app"
APPDIR = "/data/user/0/%s/files" % PKG
MEDIA, OUT = sys.argv[1], sys.argv[2]
SHOTS = os.path.join(OUT, "screens")
os.makedirs(SHOTS, exist_ok=True)
report, serious, warnings = [], [], []


def say(line=""):
    print(line, flush=True)
    report.append(line)


def adb(*args, timeout=120, binary=False):
    try:
        r = subprocess.run(["adb"] + list(args), capture_output=True, timeout=timeout)
        return r.stdout if binary else r.stdout.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        return b"" if binary else ""


def sh(cmd, timeout=120):
    return adb("shell", cmd, timeout=timeout)


def run_as(cmd, timeout=120):
    return sh("run-as %s %s" % (PKG, cmd), timeout=timeout)


# ---------- crash / freeze watch ----------
seen_crash = ""


def new_crashes():
    """Text of app crashes / freezes since the last call."""
    global seen_crash
    txt = adb("logcat", "-b", "crash", "-d")
    anr = [l for l in adb("logcat", "-b", "main", "-d", "-s", "ActivityManager:E").splitlines() if "ANR in " + PKG in l]
    mine = txt if PKG in txt else ""
    fresh = mine[len(seen_crash):] if mine.startswith(seen_crash) else mine
    seen_crash = mine
    return (fresh.strip() + ("\n" + "\n".join(anr) if anr else "")).strip()


def check(step):
    c = new_crashes()
    if c and "SIGILL" in c:
        # the virtual phone's processor lacks an instruction the test build uses: a test-machine issue
        warnings.append("test machine: processor feature missing (SIGILL) during " + step)
        say("  !! test machine problem (SIGILL) during '%s'; this is not an app bug" % step)
        return False
    if c:
        serious.append("CRASH during: " + step)
        say("  !! APP CRASHED during '%s':" % step)
        for l in c.splitlines()[:40]:
            say("     " + l)
        return False
    return True


# ---------- screen helpers ----------
def dump():
    for _ in range(4):
        out = sh("uiautomator dump /sdcard/ui.xml >/dev/null 2>&1; cat /sdcard/ui.xml", timeout=40)
        if "<hierarchy" in out:
            try:
                return ET.fromstring(out[out.index("<?xml") if "<?xml" in out else out.index("<hierarchy"):])
            except ET.ParseError:
                pass
        time.sleep(1.5)
    return None


def nodes(root):
    if root is None:
        return []
    res = []
    for n in root.iter("node"):
        m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", n.get("bounds", ""))
        if m:
            x1, y1, x2, y2 = map(int, m.groups())
            res.append({"text": n.get("text", ""), "desc": n.get("content-desc", ""), "id": n.get("resource-id", ""),
                        "cls": n.get("class", ""), "x": (x1 + x2) // 2, "y": (y1 + y2) // 2, "checked": n.get("checked") == "true"})
    return res


def find(ns, text=None, contains=None, rid=None, desc=None):
    for n in ns:
        if text is not None and n["text"] != text:
            continue
        if contains is not None and contains not in n["text"]:
            continue
        if rid is not None and not n["id"].endswith(rid):
            continue
        if desc is not None and n["desc"] != desc:
            continue
        return n
    return None


def screen_text(ns):
    return " | ".join(n["text"] for n in ns if n["text"])[:400]


def tap(n):
    sh("input tap %d %d" % (n["x"], n["y"]))
    time.sleep(1.5)


def long_press(n):
    sh("input swipe %d %d %d %d 900" % (n["x"], n["y"], n["x"], n["y"]))
    time.sleep(1.5)


def key(k):
    sh("input keyevent " + k)
    time.sleep(1.5)


def shot(name):
    data = adb("exec-out", "screencap", "-p", binary=True)
    if data:
        open(os.path.join(SHOTS, name + ".png"), "wb").write(data)


def resumed():
    out = sh("dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity'")
    m = re.search(r"com\.subgen\.app/\.?(\w+)", out)
    return m.group(1) if m else out.strip()[:80]


def center():
    m = re.search(r"cur=(\d+)x(\d+)", sh("dumpsys window displays"))
    w, h = (int(m.group(1)), int(m.group(2))) if m else (1080, 2400)
    return w // 2, h // 2


steps_ok = 0


def step(name, ok, detail=""):
    global steps_ok
    crashed = not check(name)
    if ok and not crashed:
        steps_ok += 1
        say("  PASS  " + name + (("  (" + detail + ")") if detail else ""))
    elif not crashed:
        warnings.append("screen check: " + name)
        say("  WARN  " + name + (("  (" + detail + ")") if detail else ""))
    return ok and not crashed


# ---------- queue ----------
def queue_items():
    items = []
    for line in run_as("cat files/queue.txt").splitlines():
        f = [urllib.parse.unquote_plus(x) for x in line.split("\t")]
        if len(f) >= 9:
            items.append({"id": f[0], "uri": f[1], "name": f[2], "status": f[6], "result": f[7], "error": f[8]})
    return items


def check_preview(metas, items, when):
    """The early sync check: notification -> Watch -> player, and are those first subtitles in sync?"""
    run = next((it for it in items if it["status"] == "running"), None)
    say("  'First minute ready' notification after %.0f s%s" % (when, (" (working on %s)" % run["name"]) if run else ""))
    sh("am start -W -n %s/.MainActivity" % PKG)
    time.sleep(2)
    ns = nodes(dump())
    shot("01b_check_sync_button")
    b = find(ns, text="Check sync: watch from the start")
    if not step("Generate screen offers 'Check sync: watch from the start'", b is not None, screen_text(ns)[:120]):
        return
    tap(b)
    time.sleep(4)
    step("it opens the player with the subtitles so far", resumed() == "PlayerActivity", resumed())
    shot("01c_check_sync_player")
    key("KEYCODE_BACK")
    srt = run_as("cat files/projects/_preview/subs.srt")
    meta = metas.get(run["name"]) if run else None
    if not meta or not srt.strip():
        say("  (no preview file to grade)")
        return
    cues = eval_subs.parse_srt(srt)
    last = max(c["end"] for c in cues) if cues else 0
    part = dict(meta, sentences=[r for r in meta["sentences"] if r["end"] <= last + 0.5])
    lines, problems = eval_subs.grade(part, cues)
    say("  preview subtitles (first %.0f s of the video) graded:" % last)
    for l in lines[:6]:
        say("    " + l)
    if problems:
        warnings.append("early preview: " + "; ".join(problems))
        say("    RESULT: needs work: " + "; ".join(problems))
    else:
        say("    RESULT: OK, the preview is in sync")


def main():
    new_crashes()
    clips = sorted(glob.glob(os.path.join(MEDIA, "*.json")))
    metas = {}
    say("SubGen robot test")
    say("Virtual phone: " + sh("getprop ro.product.model").strip() + ", Android " + sh("getprop ro.build.version.release").strip()
        + " (x86_64, %s cores)" % sh("nproc").strip())
    say()
    run_as("mkdir -p files/test")
    for j in clips:
        meta = json.load(open(j, encoding="utf-8"))
        name = meta["name"] + ".mp4"
        metas[name] = meta
        adb("push", os.path.join(MEDIA, name), "/data/local/tmp/" + name, timeout=300)
        sh("chmod 644 /data/local/tmp/" + name)
        run_as("cp /data/local/tmp/%s files/test/%s" % (name, name))
        sh("am start -n %s/.SelfTestActivity --es path %s/test/%s --es src %s --es target %s --ez accurate %s"
           % (PKG, APPDIR, name, meta["src"], meta["target"], "true" if meta["accurate"] else "false"))
        time.sleep(2)
    check("queueing the test videos")

    say("== While working ==")
    t0 = time.time()
    label_checked = False
    first_seen = None
    done_at = {}
    while time.time() - t0 < 50 * 60:
        items = queue_items()
        for it in items:
            if it["status"] in ("done", "failed", "cancelled") and it["name"] not in done_at:
                done_at[it["name"]] = time.time() - t0
        running = [it for it in items if it["status"] == "running"]
        if running and not label_checked and time.time() - t0 > 20:
            label_checked = True
            sh("am start -W -n %s/.MainActivity" % PKG)
            time.sleep(3)
            ns = nodes(dump())
            shot("01_generate_while_working")
            lab = find(ns, contains="Now working on")
            step("Generate screen names the video being worked on", lab is not None, (lab or {}).get("text", screen_text(ns))[:120].replace("\n", " / "))
            st = find(ns, contains="Overall")
            step("progress and time estimate shown", st is not None and "%" in st["text"], (st or {}).get("text", "")[:120].replace("\n", " / "))
        if first_seen is None and "First minute ready" in sh("dumpsys notification --noredact", timeout=40):
            first_seen = time.time() - t0
            check_preview(metas, items, first_seen)
        if items and all(it["status"] not in ("waiting", "running") for it in items) and len(items) >= len(clips):
            break
        if not check("processing videos in the background"):
            break
        time.sleep(10)
    else:
        serious.append("videos not finished after 50 minutes")
        say("  !! not finished after 50 minutes")

    if first_seen is None:
        warnings.append("no 'First minute ready' notification seen")
        say("  WARN  no 'First minute ready' notification seen")
    say()
    items = {it["name"]: it for it in queue_items()}
    for name, meta in metas.items():
        it = items.get(name)
        say("== Video: %s  (%s -> %s, %s) ==" % (name, meta["src"], meta["target"], "Accurate" if meta["accurate"] else "Fast"))
        if not it or it["status"] != "done":
            st = it["status"] if it else "missing"
            serious.append("%s did not finish (%s)" % (name, st))
            say("  !! did not finish: %s %s" % (st, (it or {}).get("error", "")))
            continue
        pdir = "files/projects/" + it["result"]
        srt = run_as("cat %s/subs.srt" % pdir)
        log = run_as("cat %s/run_log.txt" % pdir) or run_as("cat files/run_log.txt")
        open(os.path.join(OUT, name + ".srt"), "w", encoding="utf-8").write(srt)
        open(os.path.join(OUT, name + ".log.txt"), "w", encoding="utf-8").write(log)
        lines, problems = eval_subs.grade(meta, eval_subs.parse_srt(srt), log)
        if name in done_at:
            say("  finished %.0f s after start (%.0f s of video; virtual phone, not your Oppo)" % (done_at[name], meta["duration"]))
        for l in lines:
            say("  " + l)
        if problems:
            warnings.append("%s: %s" % (name, "; ".join(problems)))
            say("  RESULT: needs work: " + "; ".join(problems))
        else:
            say("  RESULT: OK")
        say()

    say("== Screens ==")
    time.sleep(3)
    step("last finished video opens in the player by itself", resumed() == "PlayerActivity", resumed())
    for _ in range(3):
        if resumed() == "MainActivity":
            break
        key("KEYCODE_BACK")
    if resumed() != "MainActivity":
        sh("am start -W -n %s/.MainActivity" % PKG)
    time.sleep(2)
    ns = nodes(dump())
    step("app opens", find(ns, contains="Choose video") is not None or find(ns, rid="nav_library") is not None, screen_text(ns)[:100])
    lib = find(ns, rid="nav_library") or find(ns, text="Library")
    if lib:
        tap(lib)
    ns = nodes(dump())
    shot("02_library")
    names = [n for n in ns if n["text"].endswith(".mp4")]
    step("Library tab opens and lists the finished videos", len(names) >= 1, "%d listed" % len(names))

    sh("settings put system accelerometer_rotation 0")
    sh("settings put system user_rotation 1")
    time.sleep(3)
    ns = nodes(dump())
    shot("03_library_landscape")
    step("rotate to landscape: Library stays open", find(ns, text="Select") is not None or any(n["text"].endswith(".mp4") for n in ns))
    sh("settings put system user_rotation 0")
    time.sleep(3)
    ns = nodes(dump())

    view = find(ns, text="View") or find(ns, text="VIEW")
    if view:
        tap(view)
        ns = nodes(dump())
        shot("04_viewer")
        info = find(ns, contains="Tap a line to play")
        step("View shows the subtitle lines inside the app", info is not None, (info or {}).get("text", "")[:80].replace("\n", " / "))
        row = next((n for n in ns if n["id"].endswith("text1") and re.match(r"\d+:\d\d:\d\d", n["text"])), None)
        if row:
            tap(row)
            time.sleep(4)
            step("tapping a line opens the player", resumed() == "PlayerActivity", resumed())
            shot("05_player")
            cx, cy = center()
            sh("input tap %d %d" % (cx, cy)); time.sleep(1)
            shot("06_player_controls")
            sh("input tap %d %d" % (cx, cy)); time.sleep(0.15); sh("input tap %d %d" % (cx, cy))
            time.sleep(2)
            step("player: tap / double-tap without crashing", resumed() == "PlayerActivity")
            ns = nodes(dump())
            close = find(ns, desc="Close")
            if close:
                tap(close)
            else:
                key("KEYCODE_BACK")
            time.sleep(2)
            step("player Close returns to the app", resumed() == "MainActivity", resumed())
        else:
            step("viewer has lines to tap", False, screen_text(ns)[:100])
            key("KEYCODE_BACK")
    else:
        step("View button on Library cards", False, screen_text(ns)[:100])

    ns = nodes(dump())
    sel = find(ns, text="Select") or find(ns, text="SELECT")
    if sel:
        tap(sel)
        ns = nodes(dump())
        step("Select starts choosing", find(ns, text="Tap videos to select") is not None)
        card = next((n for n in ns if n["text"].endswith(".mp4")), None)
        if card:
            tap(card)
            ns = nodes(dump())
            step("tapping a card ticks it", find(ns, text="1 selected") is not None, screen_text(ns)[:80])
        allb = find(ns, text="Select all") or find(ns, text="SELECT ALL")
        if allb:
            tap(allb)
            ns = nodes(dump())
            n_names = len([n for n in ns if n["text"].endswith(".mp4")])
            step("Select all ticks every video", find(ns, text="%d selected" % n_names) is not None, screen_text(ns)[:80])
        shot("07_selecting")
        key("KEYCODE_BACK")
        ns = nodes(dump())
        step("Back cancels selecting (and stays in the app)", resumed() == "MainActivity" and find(ns, text="Tap videos to select") is None)
    else:
        step("Select button in Library", False, screen_text(ns)[:100])

    ns = nodes(dump())
    before = [n for n in ns if n["text"].endswith(".mp4")]
    if before:
        long_press(before[-1])
        ns = nodes(dump())
        step("long-press starts choosing with that video ticked", find(ns, text="1 selected") is not None)
        d = find(ns, text="Delete") or find(ns, text="DELETE")
        if d:
            tap(d)
            ns = nodes(dump())
            shot("08_delete_confirm")
            cb = next((n for n in ns if "saved .srt" in n["text"]), None)
            step("delete asks first and offers to delete the saved .srt", cb is not None and cb["checked"], (cb or {}).get("text", screen_text(ns)[:80]))
            ok = find(ns, rid="button1") or find(ns, text="Delete") or find(ns, text="DELETE")
            if ok:
                tap(ok)
            ns = nodes(dump())
            after = [n for n in ns if n["text"].endswith(".mp4")]
            step("video removed from the Library", len(after) == len(before) - 1, "%d -> %d" % (len(before), len(after)))

    ns = nodes(dump())
    gen = find(ns, rid="nav_generate") or find(ns, text="Generate")
    if gen:
        tap(gen)
    ns = nodes(dump())
    shot("09_generate")
    step("Generate tab opens", find(ns, contains="Choose video") is not None)

    crash_file = run_as("cat files/crash.txt").strip()
    if crash_file and "No such file" not in crash_file:
        serious.append("the app's own crash record is not empty")
        say("  !! app crash record:\n" + crash_file[:2000])
    check("end of test")

    verdict = "PASSED" if not serious and not warnings else ("CRASH OR FAILURE FOUND" if serious else "PASSED WITH WARNINGS")
    head = ["VERDICT: " + verdict, "screen checks passed: %d" % steps_ok]
    head += ["SERIOUS: " + s for s in serious] + ["warning: " + w for w in warnings]
    open(os.path.join(OUT, "report.txt"), "w", encoding="utf-8").write("\n".join(head) + "\n\n" + "\n".join(report) + "\n")
    print("\n".join(head))
    sys.exit(1 if serious else 0)


if __name__ == "__main__":
    main()
